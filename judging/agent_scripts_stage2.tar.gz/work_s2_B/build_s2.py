import json, re, os
REV='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/judging/'
VR='validated_reference'; RO='run_own_code_or_data'; DD='definition_docs'; OS='own_other_statement'; LG='logs'; AU='agent_unvalidated'; NC='not_checked'
C='contradiction'; U='unsupported'
REF='experiment/scripts/independent_triviality4.py (rank A = 28/168/516 for n=1/2/3)'
G6='thm01-R-gemini36f-'; G7='thm01-R-gemini37f-'
# per-run classification of argument_issues: list of (list, kind, evidence, detail)
AIC={
G6+'b01-C':[('T',C,AU,"work_bC_gemini36f/odd_odd_bracket_check.py (b01 engine, gb=0); own statement at mathematical_proof.md:105"),
            ('T',C,DD,"docs/math/C_coboundary_definition.md:7 (f: g -> g); turn-1 report in run.json turns[0].result"),
            ('W',C,LG,"run.json outside_refs (view_file of thm01-R-agy-home/.../task-32.log)")],
G6+'b03-C':[('T',C,RO,"scratch/solve_full.py output 'WARNING: non-zero const1' (112 lines); scratch/solve_triviality.py:231-232; own statement P:56"),
            ('T',C,VR,REF+"; also equations omit pairs (i,i) (scratch/solve_full.py:95) vs docs/math/C_coboundary_definition.md:17"),
            ('T',U,NC,"mathematical_proof.md:131-135 read; no derivation shown for f=0")],
G6+'b05-C':[('T',C,AU,"work_bC_gemini36f/odd_odd_bracket_check.py (b01 engine) vs b05 table in solve_triviality.py (no Z term)"),
            ('W',C,RO,"scratch/solve_triviality.py main calls analyze_triviality(n, modulo_scalars=True) only; scratch/verification_results.json one entry per n"),
            ('T',U,NC,"stage-1: theorem claims all n>=1 (P:16); for n=1 only j=k=1 exists, so the j!=k step has no n=1 instance"),
            ('T',U,NC,"stage-1: contribution of E_sp (P:111, f(F)=c Z + E_sp) to the F_{sigma,k,t} coefficient not evaluated in the text"),
            ('W',C,RO,"scratch/solve_triviality.py main calls analyze_triviality(n, modulo_scalars=True) only (same fact as the P:97 item)")],
G6+'b07-C':[('T',C,VR,REF+"; same ranks 28/168/516 in b09, b12, b13, b16 reruns; run reports rank 32 of 32"),
            ('W',C,RO,"export_artifacts.py:64-71 writes rank_delta=num_f_vars, is_injective=True, H1_odd_dim=0; obstructions built from parameter names")],
G6+'b09-C':[('T',C,RO,"docs/issues/verification_artifacts.json: all_gb_forced_zero false, sample_gb_constraints []; rerun prints 'All gb forced to zero: False'; verify_gb_forced_zero.py prints 'No solution found.'"),
            ('W',C,RO,"verification_artifacts.json: 'triviality_condition' string beside 'all_gb_forced_zero': false; full_nullspace_analysis.py:237"),
            ('W',U,RO,"full_nullspace_analysis.py counts left-nullspace vectors with nonzero projection (len(gb_eqs)); no rank of those constraints computed"),
            ('W',C,LG,"run.json: 4 turns, denial_replies 2, one run_command denied in turn 2")],
G6+'b12-C':[('W',C,RO,"scripts/verify_cn1.py and scripts/symbolic_proof_check (symbolic_proof.py) contain no Jacobi code (grep); rerun prints none; turn1.jsonl.gz lines 47, 59 show an earlier script version"),
            ('W',C,RO,"scripts/symbolic_proof.py:4 symbolic_analysis_n1 covers n=1 only; no Jacobi code in verify_cn1.py")],
G6+'b13-C':[('T',C,DD,"docs/math/C_coboundary_definition.md:7-11 (f arbitrary odd); solve_triviality.py:217-221 f_EO symbols for every even basis element incl. Z0"),
            ('T',U,NC,"stage-1: P:101 leaves '- f([F_1, F_2]_0)' unevaluated; P:111 concludes without it"),
            None],  # replaced below
G6+'b14-C':[('T',C,AU,"work_bC_gemini36f/b01_gamma_even_even.py on b01 engine output; b14 sets even-even gamma to {} in code (scripts/verify_cn_triviality.py:155-156)"),
            ('T',C,VR,REF+"; a nonzero ad(X_0) with delta=0 requires a kernel; run reports rank 32 of 32 (P:185)")],
G6+'b15-C':[('T',C,VR,REF+"; run's table P:145 and rerun: Rank(M)=32 of 32"),
            ('T',C,AU,"work_bC_gemini36f/b01_gamma_even_even.py on b01 engine output (3/10/21 nonzero gamma(Z,B) entries for n=1,2,3)"),
            ('T',C,AU,"work_bC_gemini36f/odd_odd_bracket_check.py (b01 engine, gb=0) vs b15 bracket_odd_odd (no J0 term)")],
G6+'b16-C':[('T',U,NC,"stage-1: P:93 equation left unevaluated; P:94 'applying the Lie superalgebra Jacobi identities forces every coefficient' not carried out; claim equals the theorem content (P:19-20, P:145)")],
G7+'b01-C':[('T',U,RO,"stage-1 'Unclear': formula gives -4 gb_{-,1,+} for j=k=1, artifacts/verification_artifact_n1.json solution_f phi_4_1 = -2*gb_-_1_+ + 2*phi_2_7")],
G7+'b03-C':[('T',C,OS,"mathematical_proof.md:127 vs :129 (same run)")],
G7+'b06-C':[],
G7+'b08-C':[('T',C,AU,"checks/check_b08_b13_b06_claims.py and checks/check_b08_system.py (run's own get_algebra, n=1); checks/check_oscillator_claims.py (own explicit representation)"),
            ('W',U,RO,"verification/symbolic_proof_check.py:23-46 equations typed in from the proof, not computed from the algebra")],
G7+'b09-C':[('T',C,LG,"turn1.jsonl.gz event 64 ('2-cocycle condition for gamma_gb: FAILED', n=1 and n=2) and event 72 ('Corrected 2-cocycle check for n=1: FAILED')"),
            ('T',C,RO,"verify_cn1.py defines H_k as b_k^+ b_k^- (no +1/2); proof line 52 vs docs/math/Cn1_definition.md (normalization)")],
G7+'b11-C':[('W',C,RO,"verify_all_n.py:169 assert jac_err == 0 fails ('Jacobi check: 72 errors', exit 1) before the cocycle check at :250-280; same in Worker log turn2.jsonl.gz event 56"),
            ('W',C,RO,"verify_rigorous.py prints '72 errors (0 expected)' and crashes; verify_triviality.py crashes; verify_all_n.py reports 72 errors; test_corrected_algebra.py reports 0 errors (Worker log event 65), no Jacobi check inside run_full_analysis.py")],
G7+'b12-C':[('T',C,AU,"checks/check_oscillator_claims.py (own explicit representation); run's own export not compared"),
            ('T',U,NC,"stage-1: term -f([N_a,F]_0) = -sigma f(F) (line 131) not shown to vanish; argument at line 132 addresses only the first two terms")],
G7+'b13-C':[('T',C,AU,"checks/check_b08_b13_b06_claims.py (run engine verify_cn1.compute_supercommutator, n=1); checks/check_oscillator_claims.py"),
            ('T',C,AU,"checks/check_b08_b13_b06_claims.py (run engine, n=1)"),
            ('W',C,RO,"verification_artifacts.json per-case keys (n, algebra, superdimension, basis, deformation_parameters, cohomology_data, singular_values_K, counts); no structure constants, cocycle or matrices")],
G7+'b14-C':[('T',C,AU,"checks/check_oscillator_claims.py (own explicit representation)"),
            ('T',C,OS,"mathematical_proof.md:60 (p(kappa)=1) vs :112 (kappa moved past odd a with no sign); stage-1 marks reading-dependent"),
            ('W',C,LG,"turn1.jsonl.gz event 75 ('Total 2-cocycle violations: 156'), event 81 ('Total Jacobi violations at order kappa: 426')")],
G7+'b15-C':[('W',C,RO,"artifacts/verification_C*.json keys (algebra, n, superdimension, basis, gb_parameter_count, gb_parameters, phi_parameter_count, equation_count, triviality_result, sample_structure_constants (first 15), sample_gamma_brackets (first 15))")],
}
# extra items: (list, kind, quote, loc, contradicts, evidence, detail, source)
def X(l,k,q,loc,ctr,ev,det,src): return dict(l=l,kind=k,quote=q,loc=loc,contradicts=ctr,evidence=ev,evidence_detail=det,src=src)
EXTRA={
G6+'b01-C':[X('W',C,"Total tool calls: 20","supplementary_metrics.md:10","run.json tool_counts sum to 33",LG,"run.json tool_counts","notes"),
            X('W',U,"\"is_trivial_if_and_only_if\": \"gb == 0\",","scratch/export_artifacts.py:89","",RO,"literal in the export script, not tied to solver output (stage-1 computation.note)","computation.hardcoded")],
G6+'b03-C':[],
G6+'b05-C':[X('W',U,"\"step_6\": \"Evaluating mixed odd-odd brackets forces gb_{-, j, s} = 0 for all j, s.\"","scratch/gen_artifacts_json.py:19","",RO,"literal text written into the JSON artifact","computation.hardcoded"),
            'RANK:1'],
G6+'b07-C':['RANK:0'],
G6+'b09-C':[],
G6+'b12-C':[X('W',U,"\"coboundary_operator_rank\": 28 if n==1 else (168 if n==2 else 516),","scripts/generate_artifact.py:52","",RO,"literal in generate_artifact.py (values equal verify_cn1.py rerun output per stage-1); the script also hard-codes the triviality_conclusion string and writes to an absolute path under <home>/notebook/git/thm01-R-batch/","computation.hardcoded / notes"),
            X('W',C,"verified the super-Jacobi identity for all $512$ ($n=1$), $6,859$ ($n=2$), and $39,304$ ($n=3$) basis triplets with $0.0$ residual error","final_reflection.md:16","Committed scripts contain no Jacobi code (grep) and the rerun prints none (stage-1 issue on P:60)",RO,"scripts/verify_cn1.py, scripts/symbolic_proof.py; re-checked in the run copy: this reflection line exists","argument_issues (same fact, reflection line re-checked)")],
G6+'b13-C':[X('W',C,"print(f\"Rank([M_f | M_gb]) = {rank_aug}\")","solve_triviality.py:307","JSON 'rank_aug' (verification_results.json:9 = 4) is the rank of M_gb alone: sympy A.hstack(B) returned B only in the agent check",AU,"work_bC_gemini36f/hstack_check.py (sympy only); solve_triviality.py:303 aug_mat = M_f_mat.hstack(M_gb_mat); report column header 'Rank(P_K M_gb)' at mathematical_proof.md:126. Stage-1 quoted the Status line for this issue; re-quoted here from the run copy","argument_issues[2] (re-quoted)"),
            X('T',U,"However, for distinct even generators or by evaluating $f(Z_0) \\in \\mathfrak{g}_{\\bar{1}}$:","docs/issues/mathematical_proof.md:78","",NC,"stage-1 note: the cocycle statement at P:78 is not completed","notes")],
G6+'b14-C':['RANK:custom14',
            X('W',U,"analyzed using exact SVD decomposition","docs/issues/mathematical_proof.md:141","",RO,"stage-1 computation.note: floating-point SVD (NumPy) in scripts/verify_cn_triviality.py; not shown that the SVD is exact","computation.note")],
G6+'b15-C':['RANK:0',
            X('T',U,"The space of non-trivial inhomogeneous deformations for $C(n+1)$ is $4n$-dimensional, spanned by the $4n$ independent non-trivial 2-cocycle classes","docs/issues/mathematical_proof.md:165","",NC,"stage-1 note: the run's data only compare against the delta-image within its own cochain space","notes")],
G6+'b16-C':[],
G7+'b01-C':[X('W',U,"\"triviality_conclusion\": \"UNCONDITIONALLY_TRIVIAL\",","run_full_verification.py:374","",RO,"written into every artifact regardless of the solve result (stage-1 computation)","computation")],
G7+'b03-C':[],
G7+'b06-C':[X('T',U,"Since $\\mathcal{U}(A)$ is an associative superalgebra, the Jacobi identity holds for the deformed bracket $[ \\cdot, \\cdot ]_\\gamma$, which implies $\\delta(\\gamma_{\\mathrm{gb}}) = 0$.","docs/issues/mathematical_proof.md:86","",NC,"stage-1 note: no cocycle test in this run","notes"),
             X('W',U,"'gb_triviality_condition': \"gb = 0 (all gb parameters must be zero for triviality)\",","scripts/verify_osp.py:426","",RO,"constant string written into artifacts_verification.json","computation")],
G7+'b08-C':[],
G7+'b09-C':[X('W',C,"**Total Human Interventions (Nudges/Approvals)**: 0 (fully autonomous execution)","final_reflection.md:9","run.json denial_replies=1 (turn 2 text 'No external access is approved...')",LG,"run.json","notes")],
G7+'b11-C':[X('W',U,"\"triviality_condition\": \"gb = 0 for all parameters\",","run_full_analysis.py:304","",RO,"literal; gamma entries are typed in by hand at run_full_analysis.py:144-228 (stage-1 computation)","computation")],
G7+'b12-C':[X('W',U,"We tested the triviality condition using two independent methods: exact symbolic Gaussian elimination / substitution via SymPy and numerical singular value decomposition (SVD)","final_reflection.md:22","",RO,"stage-1 note: output of the exact SymPy method is not stored as an artifact (exists in the Worker log event 71, not rerun)","notes")],
G7+'b13-C':[X('W',C,"We performed full symbolic and high-precision rank computations for $n=1, 2, 3$.","docs/issues/mathematical_proof.md:135","verify_cn1.py main (line 421: for n in [1, 2]) covers n=1,2 only (the cited script); n=3 is in fast_verify.py/generate_artifacts.py per stage-1",RO,"verify_cn1.py:421; stage-1 notes","notes"),
           X('W',U,"\"H1_dim_odd\": 0,","generate_artifacts.py:17","",RO,"literal (with a 'conclusion' string at :16) in generate_artifacts.py","computation")],
G7+'b14-C':[],
G7+'b15-C':[X('W',U,"\"is_unconditionally_trivial\": False,","generate_artifacts.py:128","",RO,"literal in the artifact generator; gb_constraints are computed (stage-1 computation)","computation"),
            X('T',U,"By the discrete Dynkin/oscillator automorphisms of $C(n+1)$ (exchanging $\\sigma \\leftrightarrow -\\sigma$, $s \\leftrightarrow -s$, and permuting bosonic indices $j \\in \\{1, \\dots, n\\}$), an isomorphic subsystem of equations governs each parameter $\\mathrm{gb}_{\\sigma, j, s}$.","docs/issues/mathematical_proof.md:144","",NC,"stage-1 note: step 3 (generalization by automorphisms) was not checked by script","notes")],
}
RANKIDX={G6+'b03-C':0,G6+'b05-C':1,G6+'b07-C':0,G6+'b15-C':0}
# remark_readings (stage-1 declared_reading re-read)
RR={
G6+'b01-C':"single reading: K dropped ('modulo scalars', P:74), kappa no sign in code, gb commuting symbols; headline 'trivial iff gb=0' (P:145).",
G6+'b03-C':"single reading: K dropped (constants only printed as WARNING, solve_triviality.py:226-232), gb stated odd (P:15) but commuting symbols in code; headline 'trivial iff all 4n gb zero' (P:144).",
G6+'b05-C':"single reading in the report: K dropped via 'mod C.1' (P:90); code skips 'scalar' when modulo_scalars; headline 'trivial iff all gb zero' (P:193). The report also says it verified a strict-equality formulation (P:97, see issue).",
G6+'b07-C':"two variants stated: (1) f into g, K kept as a 'scalar' key in the system (solver.py:298); (2) f allowed into g + C1 ('Allowing f(O_a) to map into g + C1', P:82; test_scalar.py, allow_scalar_in_f=True). Both give gb=0 per stage-1 rerun; headline 'trivial iff gb = 0' (P:133).",
G6+'b09-C':"single reading: K not mentioned; code never produces a K component (implicit drop); headline 'trivial' iff gb=0 theorem (P:15) while the committed JSON says all_gb_forced_zero false (see issue).",
G6+'b12-C':"single reading: K identified with scalar and dropped ('evaluated modulo central scalars CK', P:96); headline 'trivial iff all parameters zero' (P:17).",
G6+'b13-C':"single reading: scalar dropped ('identity terms vanish', P:54); headline 'trivial iff gb = 0'.",
G6+'b14-C':"single reading: scalars dropped (quotient superalgebra, P:63; H0 = a+a- unshifted); even-even gamma set to {} in code; headline 'trivial iff gb = 0' (P:195).",
G6+'b15-C':"single reading: scalar dropped (b_prod_to_even drops 1/2, full_solver.py:74-75); headline 'gb = 0 necessary and sufficient' (P:164).",
G6+'b16-C':"single reading: scalars dropped (P:57); headline 'gb = 0' (P:145).",
G7+'b01-C':"single reading: kappa supercommutes (algebra_solver.py:90), K dropped (run_full_verification.py:250), f cannot map into K; headline 'unconditionally trivial for all gb' (issue_open.md:36; P:17).",
G7+'b03-C':"single reading: kappa supercommutes ('u kappa = (-1)^p(u) kappa u', P:79; bracket_solver.py:28), K dropped ('mod scalars'); headline 'unconditionally trivial for all parameter values' (P:195).",
G7+'b06-C':"single reading: kappa treated as commuting in code (verify_osp.py:132-151), K dropped; 'up to scalar' read as gamma = c*delta f (P:98-99); headline 'trivial iff gb = 0' (P:152).",
G7+'b08-C':"single reading: kappa commuting in code (verify_c_algebra.py:128-155), K dropped; 'up to scalar' read as lambda*delta f (P:78-82); headline 'trivial iff all parameters zero' (P:18).",
G7+'b09-C':"single reading: kappa commuting in code (verify_brackets.py:119-124), K dropped (verify_brackets.py:73); 'up to scalar' read as c*delta f (P:93); headline 'trivial iff parameters vanish' (P:17).",
G7+'b11-C':"single reading: gamma typed in by hand (no kappa rule in code), hand-built C has no K component; 'up to scalar' read as c*delta f (4.2); headline 'trivial iff all gb zero' (P:172).",
G7+'b12-C':"single reading: kappa commuting in code (fast_verify.py:213-240), K discarded (fast_verify.py:242); headline 'gamma ~ 0 iff gb = 0' (P:15).",
G7+'b13-C':"single reading: kappa commuting in code, scalars unused (verify_cn1.py:196-219); headline 'gb = 0' (P:172).",
G7+'b14-C':"single reading in code: kappa commuting (scripts/solve_triviality.py:171-193), K dropped; the report states p(kappa)=1 (P:60) (see issue); headline 'trivial iff gb = 0' (P:205).",
G7+'b15-C':"single reading: kappa commuting in code (algebra_engine.py:171-192), K dropped (algebra_engine.py:96); headline 'trivial iff all parameters vanish' (P:16). Note: generate_artifacts.py:128 literal is_unconditionally_trivial False.",
}
DROP_NOTE_SAME="agent observation about differences between first and final commit; not a statement of the run"
def parse_loc(q):
    return ' ; '.join(re.findall(r'(\S+?:\d+): "',q)) or ''
def build(o,drops_log):
    run=o['run']; cc=o['commit_checked']
    ai=o['argument_issues']; ai=ai if isinstance(ai,list) else [ai]
    cl=AIC[run]
    assert len(cl)==len(ai),(run,len(cl),len(ai))
    T=[];W=[];D=[]
    for i,(a,c) in enumerate(zip(ai,cl)):
        if c is None: continue
        l,k,ev,det=c
        q=a['quote']; loc=a.get('loc') or parse_loc(q)
        it=dict(quote=q,loc=loc,kind=k,contradicts=(a['contradicts'] if k==C else ''),evidence=ev,evidence_detail=det+('' if k==C else ' | stage-1 text: '+a['contradicts']))
        it['stage1_source']='argument_issues[%d]'%i
        (T if l=='T' else W).append(it)
    for x in EXTRA[run]:
        if isinstance(x,str):
            if x=='RANK:custom14':
                x=X('T',C,"For $n=1, 2, 3$, $\\mathrm{Rank}(M_f) = N_\\phi = 2 \\dim(\\mathfrak{g}_{\\bar{0}}) \\dim(\\mathfrak{g}_{\\bar{1}})$.","docs/issues/mathematical_proof.md:185","Reference rank A = 28/168/516 (kernel dim 4n); run reports rank 32/176/528 (full column rank)",VR,REF+" ; stage-1 reported_numbers.vs_reference","reported_numbers")
            else:
                idx=int(x.split(':')[1]); rep=o['reported_numbers']['reported'][idx]
                x=X('T',C,rep['quote'],rep['loc'],"Reference rank A = 28/168/516 (kernel dim 4n); run reports rank 32/176/528 ("+o['reported_numbers']['vs_reference'].split('.')[0]+")",VR,REF+" ; stage-1 reported_numbers.vs_reference","reported_numbers")
        it=dict(quote=x['quote'],loc=x['loc'],kind=x['kind'],contradicts=x['contradicts'] if x['kind']==C else '',evidence=x['evidence'],evidence_detail=x['evidence_detail']+('' if x['kind']==C else ''),stage1_source=x['src'])
        (T if x['l']=='T' else W).append(it)
    # dropped
    notes=o['notes']; nl=notes if isinstance(notes,list) else [notes]
    for j,n in enumerate(nl):
        D.append(dict(source='notes[%d]'%j,text=n[:300],reason=drop_reason_note(run,n)))
    if 'deliverable_changes_first_to_final' in o:
        D.append(dict(source='deliverable_changes_first_to_final',text=str(o['deliverable_changes_first_to_final'])[:300],reason="description of file differences between first and final commit (reflection files added); not a statement of the run"))
    D.append(dict(source='rerun',text=(o['rerun'] if isinstance(o['rerun'],str) else json.dumps(o['rerun'],ensure_ascii=False))[:300],reason="agent rerun record, not a statement of the run; "+rerun_reason(run)))
    D.append(dict(source='consistency_with_data',text=o['consistency_with_data'][:300],reason=cd_reason(run)))
    rn=o['reported_numbers']
    D.append(dict(source='reported_numbers',text=rn['vs_reference'][:300] if isinstance(rn,dict) else str(rn)[:300],reason=rn_reason(run)))
    c=o['computation']
    D.append(dict(source='computation',text=(json.dumps(c.get('hardcoded'),ensure_ascii=False)+' | '+str(c.get('note')) if isinstance(c,dict) else c)[:300],reason="code listing/notes: hard-coded literals that are quotable are placed in work_items (source 'computation...'); the rest are agent observations about code structure, not statements of the run"))
    return dict(run=run,commit_checked=cc,remark_readings=RR[run],theory_items=T,work_items=W,dropped=D)
def drop_reason_note(run,n):
    s=n.lower()
    if 'agent scripts reusing' in s: return "method note on agent computations (labels evidence as agent_unvalidated); not a statement of the run"
    if 'identical to final commit' in s or 'rewritten' in s or 'lacks' in s or 'final commit adds' in s or 'supplementary_metrics.md identical' in s or 'added in final' in s or 'conclusion is the same in both' in s or 'single commit' in s: return DROP_NOTE_SAME
    if 'tool calls' in s: return "placed in work_items (tool-call count)"
    if 'turns' in s and ('4 turns' in s or 'denied' in s) and 'b09' in s: return "duplicate of argument_issues item on final_reflection.md:9 (run.json turns/denial replies)"
    if 'worker attempted to write verify_triviality' in s: return "duplicate of argument_issues item on final_reflection.md:9 (denied command, run.json)"
    if 'uncommitted' in s and 'pycache' in s and len(s)<40: return "agent observation of uncommitted file; not a statement of the run"
    if 'issue_open.md' in s and 'modified' in s: return "agent observation of a file change; not a statement of the run (status 'resolved' is recorded in run.json turns[0].result)"
    if 'replace_file_content' in s: return "agent observation of tool use; not a statement of the run"
    if 'untouched' in s: return "agent observation; not a statement of the run"
    if 'write_to_file call errored' in s: return "agent observation from run.json (tool error, not a human denial); not a statement of the run"
    if 'not checked' in s and 'reflection p:111' in s: return "stage-1 remark that reflection claims were not checked; no specific statement quoted"
    if 'cocycle statement' in s: return "placed in theory_items (P:78)"
    if 'p:165 asserts' in s: return "placed in theory_items (P:165)"
    if 'step 3' in s: return "placed in theory_items (automorphism step, P:144) ; other part is agent observation"
    if 'proof 3.3' in s: return "placed in theory_items (P:86); the remark on other runs is an agent observation"
    if 'explicit f listed' in s: return "agent check that the proof's f matches artifacts; no discrepancy; not an issue"
    if 'turn1' in s or 'turns:' in s or 'turn1 ' in s: return "agent observation of turn structure / denied commands from run.json; not a statement of the run"+(" (final_reflection.md:22 sentence placed in work_items)" if 'final_reflection.md:22' in s else "")+(" (final_reflection.md:9 intervention count placed in work_items)" if 'human interventions' in s or 'final_reflection.md says 0' in s else "")
    if 'docs/issues/issue_open.md has no response' in s: return "parts about reflection placed in work_items (final_reflection.md:9); remaining parts are agent observations of files"
    if 'uncommitted' in s: return "agent observation of uncommitted files; the n=1,2 vs 1,2,3 remark placed in work_items" if 'verify_cn1.py main covers' in s else "agent observation of uncommitted files; the remark on step 3 placed in theory_items" if 'step 3' in s else "agent observation of uncommitted files"
    return "agent observation; not a statement of the run"
def rerun_reason(run):
    return {G6+'b03-C':"printed/JSON numbers equal the report; the 112 'WARNING: non-zero const1' output lines are in the issue on P:72",
            G7+'b11-C':"exit codes 1 for verify_all_n.py, verify_rigorous.py, verify_triviality.py are in the work_items on P:155/P:160",
            G6+'b09-C':"printed 'All gb forced to zero: False' is in the issue on P:140"}.get(run,"stage-1 records that outputs reproduce the report/committed files; no discrepancy to sort")
def cd_reason(run):
    return {G6+'b09-C':"mismatch (JSON all_gb_forced_zero false vs stated 'iff gb=0') duplicates the issue on P:140",
            G7+'b08-C':"match for the full-system conclusion; the derivation mismatch duplicates argument_issues[0]/[1]",
            G7+'b11-C':"match; 'gamma is hand-entered' remark is in work_items (computation literal item)"}.get(run,"stated class agrees with the data/reference combination recorded in stage-1 (or only the rank-A mismatch, which is placed as a rank item); no separate issue")
def rn_reason(run):
    if run in RANKIDX or run==G6+'b14-C': return "rank mismatch placed in theory_items (reported_numbers)"
    return "reported numbers equal the reference or are counts only (no rank claim contradicted); no issue"
for g in ['bC_gemini36f','bC_gemini37f']:
    out=[]
    for l in open(REV+'facts/'+g+'.jsonl'):
        o=json.loads(l); out.append(build(o,None))
    os.makedirs(REV+'facts2',exist_ok=True)
    with open(REV+'facts2/'+g+'.jsonl','w') as f:
        for r in out: f.write(json.dumps(r,ensure_ascii=False)+'\n')
    print(g,len(out))
