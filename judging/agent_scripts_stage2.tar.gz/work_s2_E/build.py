import json,re,os,sys
sys.path.insert(0,os.path.dirname(__file__))
from s2_spec import S
REV="<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/"
JR="/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/"
rows=[json.loads(l) for l in open(REV+"judging/facts/bG_gemini.jsonl")]
out=[];bad=[]
def norm(s): return re.sub(r'\s+',' ',s).strip()
def verify(run,q,loc):
    m=re.match(r'^((?:docs|src|tests|data)/[^:\s]+)',loc or '')
    if not m: return None
    p=JR+run.split('-',0)[0]+"/"+m.group(1) if False else JR+run+"/"+m.group(1)
    if not os.path.exists(p): return "nofile"
    t=norm(open(p,errors='replace').read())
    parts=[norm(x) for x in re.split(r'\.\.\.',q) if norm(x)]
    return all(x in t for x in parts)
for i,r in enumerate(rows):
    sp=S[i]; o={"run":r["run"],"commit_checked":r["commit_checked"]}
    if sp.get("aborted"):
        o.update(status=r.get("status"),remark_readings=sp["readings"],theory_items=[],work_items=[],dropped=[{"ref":"all","reason":"run excluded (aborted); stage 1 reports only status and deliverables"}])
        out.append(o);continue
    th=[];wk=[];dr=[];covered=set()
    for it in sp["items"]:
        if it[0]=='d': dr.append({"ref":it[1],"reason":it[2]});continue
        if it[0]=='a':
            _,idx,tw,k,ev,det=it; ai=r["argument_issues"][idx]; covered.add(idx)
            q,loc,con=ai["quote"],ai["loc"],ai["contradicts"]
            kind="contradiction" if k=='C' else "unsupported"
            if kind=="unsupported": det=det+" | stage-1 text: "+con
            obj=dict(quote=q,loc=loc,kind=kind,contradicts=con if kind=="contradiction" else "",evidence=ev,evidence_detail=det)
        else:
            _,q,loc,tw,k,con,ev,det=it
            kind="contradiction" if k=='C' else "unsupported"
            obj=dict(quote=q,loc=loc,kind=kind,contradicts=con if kind=="contradiction" else "",evidence=ev,evidence_detail=det)
        v=verify(r["run"],obj["quote"],obj["loc"])
        if v is False or v=="nofile": bad.append((i,r["run"],obj["loc"],obj["quote"][:60],v))
        (th if tw=='T' else wk).append(obj)
    missing=set(range(len(r.get("argument_issues",[]))))-covered
    if missing: print("MISSING arg issues",i,missing)
    o.update(remark_readings=sp["readings"],theory_items=th,work_items=wk,dropped=dr)
    out.append(o)
os.makedirs(REV+"judging/facts2",exist_ok=True)
with open(REV+"judging/facts2/bG_gemini.jsonl","w") as f:
    for o in out: f.write(json.dumps(o,ensure_ascii=False)+"\n")
for b in bad: print("UNVERIFIED",b)
from collections import Counter
c=Counter()
for o in out:
    for n,l in(("theory",o["theory_items"]),("work",o["work_items"])):
        for it in l: c[(n,it["kind"],it["evidence"])]+=1
    c["dropped"]+=len(o["dropped"])
print(len(out)); 
for k,v in sorted(c.items(),key=str): print(k,v)
