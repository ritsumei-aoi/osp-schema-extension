import json, re, os
REV='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/judging/'
T,W='T','W'
C,U='contradiction','unsupported'
RO='run_own_code_or_data'; DD='definition_docs'; OS='own_other_statement'; LG='logs'; AU='agent_unvalidated'; NC='not_checked'; VR='validated_reference'
def D(src,reason): return {"source":src,"reason":reason}
D_CAL=D("notes / consistency_with_data","extractor remark (calibration agreement, K-dependence or definition-file hash listing), not a statement of the run; K/gb readings are recorded in remark_readings")
D_TASKREQ=lambda s: D(s,"the quote is the task's requirement, not a statement of the run; the absence of the deliverable is recorded in stage-1 computation")

# per-run spec: readings, ai (per argument_issue index), extras, dropped
S={}
# ---------------- MAY ----------------
S['thm01-01']=dict(
 rr="single reading: gb odd (parity 1; issue_260518_05.md:42), K kept as basis element and target, f may map into K and K into g (src/C_coboundary_generators.py:15-18); headline 'trivial iff gb=0' (issue_260518_08.md:52-53).",
 ai=[(W,C,RO,"src/C_coboundary_generators.py:34-40; data/C_1_coboundary.json (40 phi symbols, not Cartan-restricted)","issue_260518_07.md:52"),
     (T,C,RO,"rerun output of src/check_triviality.py (three brackets listed for the left-nullspace vector; middle term gamma 0, nonzero coboundary row)","issue_260518_08.md:41"),
     (W,U,DD,"cited docs/math/C_inhomogeneous_definition.md absent from public copy; stage-1 notes: present in the workspace (sha1 afb057347762), so the citation is not shown false","issue_260518_05.md:42; final_reflection.md:30"),
     (T,C,DD,"docs/math/Cn1_definition.md:141","data/C_1_gamma.json (Z=K entries); src/C_coboundary_generators.py:15-18")],
 extra=[], drop=[D("notes: I07 text says Cartan-restricted f approved while I08 uses full f","duplicate of argument_issues[0]"),
   D("notes: issue_correction.md / issue_rework.md.completed exist","extractor observation, not a statement of the run"),D_CAL])
S['thm01-02']=dict(
 rr="single reading: gb parity 1 (issue_260518_05.md:45), K kept (all_basis includes K; f maps full odd space incl. K), kappa central; headline 'NON-TRIVIAL for all gb != 0' (issue_260519_08.md:54).",
 ai=[(W,C,RO,"src/C_triviality_solver.py (no Jacobi check; only rank(A), rank([A|gamma]) for gb=1)",None),
     (W,C,RO,"src/C_triviality_solver.py:71-73 skips n>1 ('Skipping solver for n=...')",None),
     (T,U,RO,"no script computes span of gamma_k modulo coboundaries; only rank test is gb=(1,1,1,1), n=1",None),
     (T,U,RO,"test covers only gb=(1,1,1,1) (data/C_1_evaluated_pos.json evaluation_metadata); g_summary data_implies 'trivial iff gb=0' for both n (K dropped/kept), so the stated class matches the data but the run's test does not show it",None),
     (W,C,OS,"done/issue_260519_07.md:43-57 (superseded text) vs issue_260519_07R.md; solver uses full odd map","issue_260519_07.md:43-57")],
 extra=[dict(list=T,quote="Rank of Image(delta): 36 / Rank of [Image(delta) | gamma]: 37 (solver output; reported 36 -> 37 at issue_260519_08.md:40-41)",loc="docs/issues/done/issue_260519_08.md:40-41",kind=C,contradicts="validated reference rank A = 28 (n=1); g_summary rank_nonK/rank_K 28->32 for the run's own realization. The 36 arises because K is in the basis for f (all_basis includes K).",evidence=VR,detail="judging/g_summary.csv columns rank_nonK_n1, rank_K_n1 (thm01-02); src/C_triviality_solver.py:18"),
        dict(list=W,quote="gamma data produced by src/C_gamma_generators.py (data/C_n_gamma.json)",loc="data/C_1_gamma.json",kind=C,contradicts="g_summary gamma_n1 '~none 45/50 (miss 0, extra 1, diff 5 of which neg 5)'; gamma_n2 '~none 272/292 (extra 2, diff 20 neg)': the run's gamma differs from the reference in signs and extra entries",evidence=VR,detail="judging/g_summary.csv gamma_n1, gamma_n2 (thm01-02)")],
 drop=[D_CAL])
S['thm01-03']=dict(
 rr="no reading stated (gb parity, kappa signs, K not stated); only non-triviality for gb all +1 under a 'Cartan-focused' f (issue_260518_08.md:43).",
 ai=[(W,C,RO,"WORKSPACE-ONLY data/C_n_coboundary.json have 'coboundary_coefficients': [] ; src/C_coboundary_generator.py:33-43 returns empty list","issue_260518_08.md:35-38"),
     (W,C,RO,"WORKSPACE-ONLY src/C_gamma_generators.py:14-22 writes literal '-2*gb_a1p_b{k}p'; src/C_coboundary_generator.py:34-37 has no loop over pairs","final_reflection.md:15-16"),
     (T,U,RO,"WORKSPACE-ONLY: only compared quantity is one placeholder gamma entry per direction vs an empty list; structure_constants [] (C_generators.py:26); no rank test","issue_260518_08.md:43"),
     (W,C,OS,"issue_260518_08.md:43 states non-triviality only for gb all +1 under the chosen f","final_reflection.md:24")],
 extra=[dict(list=W,quote="# Simplified placeholder for brevity (src/C_generators.py:16); # Simplified loop for demonstration of logic (src/C_coboundary_generator.py:34); data/C_1_evaluated.json 'evaluated_coeff': '-2.0'",loc="WORKSPACE-ONLY src/C_generators.py:16; src/C_coboundary_generator.py:34",kind=C,contradicts="final_reflection.md:15-16 describes a symbolic gamma computation and application of delta f; the placeholder code computes neither (agent computation: scratch work_may_facts/ws03 run of the checker prints one DISCREPANCY per direction).",evidence=RO,detail="stage-1 computation field; workspaces/osp-schema-extension/thm01-03 (untracked)")],
 drop=[D("notes: public branch lacks data and code","extractor remark about the public copy"),D_CAL])
S['thm01-04']=dict(
 rr="single reading: K dropped (stated only in data/C_1_gamma.json:524 gamma_projection_note), kappa odd central without sign, gb parity not stated, f: g->g; headline 'coboundary iff gb = 0' (issue_260520_08.md:80-84).",
 ai=[(T,C,DD,"docs/math/Cn1_definition.md (odd roots +-eps +- delta_k, 4n of them; E_{+-2delta_k} even); the run's own table issue_260520_07.md:62-70 has 4n odd generators",None),
     (T,C,OS,"same document: ':96 dimension >= 4n' vs ':119 dimension exactly 4n'; no H^2 dimension computation in code",None),
     (T,C,RO,"script output: rows -> H_2 (n=1), H_2 and H_3 (n=2); list 'H_2..H_n' does not match",None),
     (W,C,RO,"copy has src/C_evaluated.py, no src/C_evaluator.py","final_reflection.md:72"),
     (W,U,DD,"cited C_inhomogeneous_definition.md / C_coboundary_definition.md absent from public copy; stage-1 notes: both present in the workspace (sha1 afb057347762, 49a9ebcf7785)",None)],
 extra=[dict(list=W,quote="'Rubber Duck' sub-agent (and an I06 protocol violation reported)",loc="final_reflection.md:74",kind=U,contradicts="",evidence=NC,detail="self-report; no logs/ in workspace or copy"),
        dict(list=W,quote="All numbers equal the report (rerun, exit 0, ~80 s)",loc="src/C_triviality_analysis.py (rerun)",kind=U,contradicts="",evidence=RO,detail="not an issue; kept only to record that find_obstruction_witnesses is a heuristic ('We approximate') and not a nullspace witness (stage-1 computation)")][:1],
 drop=[D("computation: find_obstruction_witnesses heuristic ('We approximate')","no report statement relying on it identified in stage 1"),D_CAL])
S['thm01-05']=dict(
 rr="two variants stated: (1) K kept as gamma target with f: g->g, so K-valued gamma entries force non-triviality (issue_260520_08.md:145,246-254; headline 'trivial iff all gb zero', :287); (2) basis-only residual test with K removed (:175-177, gb_one only, 28->29, 168->169, 516->517) - same conclusion for that profile. gb parity 1 (issue_260520_05.md:259).",
 ai=[(T,C,DD,"docs/math/Cn1_definition.md:141 (K does not contribute to structure constants); basis-only test (:175-177) is for gb_one only; stage-1: K-only argument is K-dependent by test (b) though g_summary K-dropped data also give 28->32",None),
     (T,C,DD,"data/C_1_gamma.json lists K as target 'when constant terms appear' vs Cn1_definition.md:141 and central_elements.K 'excluded from basis lists'",None),
     (T,C,DD,"docs/math/B0n_definition.md:103 'p(kappa) = 1' vs :122-123 (parity 0 in the JSON); the task docs are themselves inconsistent",
      "data/C_1_gamma.json (kappa_parity 0)")],
 extra=[dict(list=W,quote="'Rubber Duck' sub-agent",loc="final_reflection.md:38",kind=U,contradicts="",evidence=NC,detail="self-report; no logs")],
 drop=[D("computation: not rerun (generation script writes into data/)","extractor remark"),D_CAL])
S['thm01-X-01']=dict(
 rr="single reading: gb*kappa treated as an even commuting scalar G (final_reflection.md:17), K dropped 'up to scalar' (mathematical_proof.md:43,45); headline 'trivial iff all gb zero' (mathematical_proof.md:13). (Text at :7 calls gb parity-1.)",
 ai=[(T,U,OS,"computation covers n=1,2 only (final_reflection.md:19 'multiple ranks (n=1, 2)'); issue_open.md Requirement 1 asks n=1,2,3; no general-n argument in the files","mathematical_proof.md:13"),
     (W,C,OS,"final_reflection.md:9 'Total Human Interventions: 0'; the audit text is not in the copy",None),
     (T,C,RO,"code and final_reflection.md:17 treat G = gb*kappa as even commuting scalar; nullspace_n*.py track no sign",None),
     (W,C,OS,"supplementary_metrics.md:8 '~3 minutes'",None),
     (W,C,RO,"only triviality_n2.json is committed; structure constants, gamma, A, B are not saved by any script",None)],
 extra=[dict(list=W,quote="<<<<<<< HEAD (line 1) ... ======= (line 64) ... >>>>>>> f8c5934 (line 357): workspace docs/issues/mathematical_proof.md in unresolved merge state containing the X-06 text after the marker",loc="WORKSPACE-ONLY workspaces/.../thm01-X-01/docs/issues/mathematical_proof.md",kind=U,contradicts="",evidence=RO,detail="stage-1 notes; the committed public copy does not contain it; verification/osp_algebra.py and triviality_data.json staged in the workspace")],
 drop=[D_CAL])
S['thm01-X-02']=dict(
 rr="single reading: gb parity and kappa signs not stated; K not stated (scalars enter the lstsq fit as monomial ()); headline 'trivial iff all gb zero' (docs/math/triviality_report.md:42).",
 ai=[(W,C,RO,"research/analysis.py:272-308 prints n=1 data to stdout; no data file committed",None),
     (T,U,RO,"research/analysis.py ignores lstsq residuals (:152), has no a+a+=0 rule (:54-66), float SVD with 1e-10 threshold; computes rank of projected gamma columns, not cohomology classes","triviality_report.md:44; final_reflection_template.md:17"),
     (W,C,RO,"research/analysis.py:174, :292 brackets only for i<j; diagonal pairs (X,X) not used","triviality_report.md:21,25-26")],
 extra=[], drop=[D("notes: reflection template overwritten; written report is docs/math/triviality_report.md","extractor remark"),D_CAL])
S['thm01-X-03']=dict(
 rr="no reading stated; code only prints 'Result: Deformation is non-trivial.' (proof_non_triviality.py:31).",
 ai=[(W,C,RO,"proof_non_triviality.py:18-31 contain print statements only (no matrix, no rank)",None),
     (W,C,DD,"docs/issues/issue_open.md has no stages (one-shot run X-03); reflection names 'Run ID: study/thm01-03', 'Workflow Type: Iterative', 'Interventions: 3'",None),
     (W,U,NC,"the earlier submission with the claimed computation is not in the copy (single commit ce0e21d); only the admission appears","final_reflection.md:19")],
 extra=[dict(list=W,quote="Placeholder symbols for f coefficients ... prints 'Rank analysis of the coboundary operator image is ongoing.' (sympy_proof.py:10-17)",loc="sympy_proof.py:10-17",kind=C,contradicts="proof_non_triviality.py:30 'Rank analysis shows that the inhomogeneous cocycle lies outside the image of the coboundary operator.' (same run, opposite status)",evidence=OS,detail="sympy_proof.py:10-17 vs proof_non_triviality.py:30")],
 drop=[D_CAL])
S['thm01-X-04']=dict(
 rr="single reading: kappa odd central, anticommutes with a_1 (mathematical_proof.md:46), K dropped 'up to scalar' (:26); headline 'trivial iff all gb = 0' for all n (:5,:454). The rebuttal retracts an earlier H_1 argument (rebuttal_report.md:56-57) without changing the conclusion.",
 ai=[(T,C,OS,"same file :53 boxed formula (F++,F--) -> c F+- + b F-+ ; (F+-,F-+) -> d F++ + a F--; verification_artifacts.py:90,92 uses the boxed formula",None),
     (T,C,OS,"rebuttal_report.md:56-57 'is incorrect and is hereby retracted', :92-93 'consistent for any b'; verification_artifacts.py:288-298, :586-590 still use the retracted argument","mathematical_proof.md:57,229"),
     (W,C,RO,"verification_artifacts.py has no coboundary linear system; obstruction functions return the parameter itself (:165-177); test cases cover n=1 (:414-450) and n=2 (:457-490) only",None),
     (T,C,AU,"agent computation scratch work_may_facts/s_x04.py (sympy gives -a/2, not +a/2 from :108-109)","rebuttal_report.md:115"),
     (T,C,OS,"rebuttal_report.md:21-40 states the fermionic part of H_1 gives non-zero contributions and retracts the earlier claim","final_reflection_template.md:22"),
     (W,C,RO,"verification_artifacts.py contains no bracket computation (hard-coded dicts); the seven test cases only exercise 'parameter != 0' rules",None)],
 extra=[dict(list=W,quote="12 PASS, 0 FAIL, 'All tests passed: True' (rerun stdout of docs/issues/verification_artifacts.py)",loc="docs/issues/verification_artifacts.py (run_all_tests)",kind=U,contradicts="",evidence=RO,detail="tests assert the code's own hard-coded rule (verify_triviality_n1 'solvable' iff all parameters 0, :279-326); gamma_gb_n1 returns hard-coded literal entries (e.g. :103 ('H1','Fpp'): {'H1': -a, ...}); no independent computation"),
        dict(list=W,quote="Total human interventions '~3' (final_reflection) while rebuttal_report.md responds to a 'reviewer'",loc="rebuttal_report.md:11,233",kind=U,contradicts="",evidence=NC,detail="self-reports; no logs")],
 drop=[D("notes: hand-written gamma entry count 30/25/40 vs calibration 28","counting convention not checked; extractor remark"),D_CAL])
S['thm01-X-05']=dict(
 rr="single reading: gauge argument, kappa called odd (:43) while f is 'even first-order change' (:70) and no sign for a_1^+ kappa; scalars dropped 'up to scalar' (:111-119,:153-170); headline 'every gb-configuration is trivial' (mathematical_proof.md:30-37). Corresponds to the 'even gb, K dropped' reading (reference rank 28 -> 28).",
 ai=[(W,C,RO,"no computational checks exist in the copy (no code; verification_artifacts.json lists them only as 'verification_targets')",None),
     (T,C,DD,"C_inhomogeneous_definition.md Parity Note (kappa odd, gb parity 1): moving kappa past odd a_1^+ gives a sign not tracked; reading-dependent since gb parity not stated by the run",None),None],
 extra=[], drop=[D_TASKREQ("argument_issues[2]: issue_open.md Deliverables 'Reusable verification code or data artifacts committed'"),D_CAL])
S['thm01-X-06']=dict(
 rr="two treatments mentioned: scalar rows excluded (mathematical_proof.md:60,64,181; code valid_targets) and a claim of robustness 'regardless of how one treats the scalar components' (:183); both give 'trivial iff gb=0'; headline = scalar rows excluded (:281).",
 ai=[(T,C,OS,"same document :263-267 'we conjecture' for n >= 1 and :135 theorem 'For n = 1, 2, 3'; no general argument beyond :121-129 prose","mathematical_proof.md:13"),
     (W,C,RO,"osp_algebra.py:194,303,363 skip j <= i: diagonal pairs (a,a) not computed",None),
     (T,U,RO,"the code runs only the variant excluding SCALAR rows (analyze_triviality, valid_targets); no run with scalar rows kept","mathematical_proof.md:183"),
     (T,C,DD,"docs/math/C_coboundary_definition.md: f is an odd linear map g -> g; no scalar-valued f in the code (note: reading 'f into g + CK' is an admissible reading per spec)",None),
     (T,C,RO,"osp_algebra.py treats gb*kappa terms as plain coefficients (no sign when kappa passes odd oscillators)",None)],
 extra=[dict(list=W,quote="Initial run with Grassmann bug",loc="final_reflection_template.md:10",kind=U,contradicts="",evidence=NC,detail="self-report; not in the copy")],
 drop=[D("notes: calibration says gamma differs (12 'none', 16 'super'); not recomputed by stage 1","not checked at stage 1; X-06 not in g_summary"),D_CAL])
# ---------------- INTERACTIVE ----------------
S['thm01-R-luna-A']=dict(
 rr="single reading: gb even scalar (human decision per issue_261003_05.md:117; final_reflection.md:57), kappa supercommutes (graded signs), K quotiented out (issue_261003_05.md:163); headline 'every assignment is trivial' (issue_261003_08.md:96). I08 itself never mentions K; K-kept reference ranks would give 28->32.",
 ai=[(W,C,RO,"src/ contains C_gamma_generator.py and C_generators.py; build_C_gamma_schema.py and build_C_structure_constants.py do not exist in the copy","data/C_1_gamma.json:732; data/C_1_structure.json:510")],
 extra=[dict(list=W,quote="The I08 sparse rank comparison was run as an exact one-off analysis rather than saved as a reusable repository script",loc="docs/issues/done/final_reflection.md:109",kind=U,contradicts="",evidence=RO,detail="no committed script produces the I08 ranks (rank A 28/168/516 equal the validated reference; g_summary 28->28, 168->168)"),
        dict(list=W,quote="the human clarified that `gb` is even while kappa is odd",loc="docs/issues/done/final_reflection.md:57",kind=U,contradicts="",evidence=NC,detail="human decision itself is not in the committed files (only the Worker's question at issue_261003_05.md:117 and the retelling)")],
 drop=[D("notes: K-independence remark","extractor remark; covered in remark_readings"),D_CAL])
S['thm01-R-sonnet46-A']=dict(
 rr="two obstructions stated, both leading to 'trivial iff gb=0' (issue_261006_08.md:160): K-component obstruction (K kept as separate central element; coboundary has zero K-component, :50) and a g-component rank test rank(U_perp^T B)=4n (:139); headline: both presented as independent confirmations.",
 ai=[(T,C,RO,"data/C_1_gamma.json has (E_eps1_del1_pm,H_1,H_2) with gb_pm_1 and (E_eps1_del1_mp,..) with gb_mp_1; same report line 62 pairs E^-_{eps-delta_1} (= E_pm) with gb_{+,1,-}; the third (E_pp,H_1,H_2)=-2 gb_pp entry is not listed",None),
     (T,U,DD,"M is not defined in docs/math; no cohomology computation exists in the run (no cocycle check, no code)",None),
     (T,U,RO,"asserted without derivation; only computation is the rank statement in section 4",None),
     (W,C,RO,"coefficients in data/C_n_gamma.json are rationals (e.g. '-1/2'), scripts use Fraction, and no script computes the I08 ranks (src/ list)",None)],
 extra=[dict(list=T,quote="map f: g -> g + CK produces zero K-component (earlier flawed K argument quoted in the Manager correction cycle)",loc="docs/issues/done/issue_261006_08.md:164-185",kind=C,contradicts="current report text :52-54 restricts f to g -> g",evidence=OS,detail="stage-1 notes: the sentence is no longer in the report body; the correction cycle is history"),
        dict(list=T,quote="gb=1: rank A 28 < rank [A|b] 29",loc="docs/issues/done/issue_261006_08.md (sections 4-5)",kind=U,contradicts="",evidence=NC,detail="single-profile rank [A|b]=29 is not in g_summary (not checked); rank(A)=28 equals validated reference")],
 drop=[D("notes: issue_correction.md.completed lists four factual errors of the first reflection; committed reflection is the corrected version","history, judged as is per spec; not a statement of the committed run"),D_CAL])
S['thm01-R-sonnet46-A1']=dict(
 rr="K kept as a separate unknown (issue_261007_08.md:52; final_reflection.md:29) and presented as the primary obstruction, with the non-K augmented system [M|N] as confirmation (13/26/39 extra gb constraints per stage-1 script run); both give 'trivial iff all gb = 0' (issue_261007_08.md:141).",
 ai=[(T,C,RO,"data/C_1_structure.json oscillator_relations 'conjugate_pair' [b_i^-,b_j^+] = delta_ij and :77 'K ... identified with scalar 1'; final_reflection.md:41 'b^- b^+ = 1 + b^+ b^-'; I08 line :131 identifies K with a number operator plus 1/2","issue_261007_08.md:129"),
     (T,C,OS,"same document's table defines deficit as phi_count - rank(M) (32-28, 176-168, 528-516); left null space has dimension rows - rank (e.g. 214 - 28 for n=1, script output of src/C_triviality.py); repeated at :148 and final_reflection.md:27","issue_261007_08.md:96"),
     (T,C,RO,"data/C_1_gamma.json K entries with H_1 exist only for gb_p_1_m and gb_m_1_m; gb_p_1_p and gb_m_1_p occur in K entries with H_2, E_2del (report's own table :63-66)",None),
     (W,C,RO,"tests/ contains 4 files; pytest --collect-only in a scratch copy collects 30 tests",None),
     (W,C,OS,"I08 section 4 (:106) presents profiles all_plus, diagonal, anti_diagonal as concrete non-trivial evidence",None)],
 extra=[], drop=[D("notes: run still in I09; issue_open.md empty template while final_reflection.md exists","state of the run (extractor remark), judged as is"),D("notes: calibration items ('redundant' not found; K = sum b+b- + 1/2 in I08)","covered by argument_issues[0]; extractor remark"),D_CAL])
S['thm01-R-luna-F']=dict(
 rr="two readings in one reply: K treated as scalar ('up to scalars', adjoint) -> every gb trivial; K matched literally -> all gb must vanish (transcript.md#2026-10-03T09:25:06.324Z, lines 771-773). Headline adopted: the first, as the answer under the documented 'up to scalar' criterion.",
 ai=[], extra=[], drop=[D("argument_checks_passed (witness f for C(2) reproduces 212 non-K rows; K entry present; gamma(E,E)=2E present)","checks passed (agent computation check_lunaF.py, check_lunaF2.py), not issues"),D("notes: reflection restates K distinction; calibration says Worker 'dropped K'","extractor remark"),D("stage-1 issues","none listed; argument_issues is empty")])
S['thm01-R-sonnet46-F']=dict(
 rr="first report (transcript.md#2026-10-06T04:35:30.334Z, line 2291) used a K = identity mechanism (coboundary cannot produce K) with factual errors; after the human correction (#04:57:26.274Z) the approved revised report drops K and states a structural obstruction in H_k components (#05:02:59.761Z, line 2608). Both conclude 'iff gb = 0'; headline = revised report (line 2761).",
 ai=[(T,C,AU,"cross-run: gamma(H_1,E_eps1_del1_pm) in thm01-R-luna-r2-G data (g_summary '=none') has H_{n+1} coefficient 2 and a K entry 1 (agent computation check_ref_H1Epm.py); the run's Schema 2 omits them (g_summary: run's gamma misses 5/50 entries n=1, 21/292 n=2)",None),
     (T,U,AU,"no joint rank in the log; agent computation check_s46F.py: joint rank [A|G] 32 > 28 (n=1), 176 > 168 (n=2) supports the claim for those n; a nonzero subspace can contain no coordinate direction",None),
     (T,U,RO,"null_dim = phi columns - rank(A) (kernel on phi-space); 'complementary pairing' asserted without derivation; first report's 'outer derivations' sentence removed in the revision",None),
     (T,C,RO,"data/C_1_structure.json lists H_1 and H_2; C_3 has H_1..H_4 (check_s46F.py). Human flagged at #2026-10-06T04:57:26.274Z; the revised report corrects it (history)",None)],
 extra=[dict(list=W,quote="gamma data in data/C_n_gamma.json (Schema 2)",loc="data/C_1_gamma.json",kind=C,contradicts="g_summary gamma: run's data differ from the no-sign reference (miss 5/50 at n=1, 21/292 at n=2, extra 1)",evidence=VR,detail="judging/g_summary.csv gamma_n1, gamma_n2 (thm01-R-sonnet46-F)")],
 drop=[D("notes: two step-8 reports; human correction; final_reflection.md:32 acknowledges two corrected errors","history; covered by argument_issues[3] and remark_readings"),D("consistency_with_data","merged into argument_issues[0] and the gamma data item")])
S['thm01-R-luna-G']=dict(
 rr="single reading: gb odd per source but treated as formal coefficient labels with no parity-derived signs (I05.md:39,44), K kept as target K (I05.md:48); headline 'trivial only for the zero gb matrix', stated as conditional on the literal formal-coefficient convention (I08.md:49,60). Test range: only the K components were tested; the non-K part was not compared with delta f.",
 ai=[], extra=[], drop=[D("stage-1 issues","none listed; argument_issues is empty"),D("notes: conditional on literal convention; calibration agrees","extractor remark; recorded in remark_readings")])
S['thm01-R-luna-r2-G']=dict(
 rr="single reading: gb treated as formal coefficient, parity inconsistency declared (I05.md:47,51), K included where scalar (I05.md:43); headline 'trivial iff every gb is zero' (I08.md:77). Test range: only isolated K witnesses (4n) and an all-plus K count; no non-K comparison.",
 ai=[], extra=[dict(list=T,quote="b_j^+b_j^- = sum_{k>j} H_k - H_{n+1} - K/2",loc="docs/issues/I08.md (derived identity; line not recorded at stage 1)",kind=U,contradicts="",evidence=AU,detail="n=1 case b^+b^- = -H_2 - 1/2 verified by agent computation check_osc.py; general n not checked")],
 drop=[D("stage-1 issues","none listed; argument_issues is empty"),D_CAL])
S['thm01-R-luna-r3-G']=dict(
 rr="single reading: kappa factored left 'using supercentral signs' (I05.md:51), gb odd per source with ambiguity (I05.md:48), K recorded as Z='K' (I05.md:53); headline 'iff gb = 0', joint symbolic system with K rows included (I08.md:68). The stated rule matches the K-kept data but g_summary K-dropped gives 'partial'.",
 ai=[],
 extra=[dict(list=T,quote="gb_{a1^sigma,bj^s} = 0 for every sigma,s ... every nonzero parameter profile is non-trivial.",loc="docs/issues/I08.md:68",kind=U,contradicts="",evidence=VR,detail="judging/g_summary.csv: K kept 28->32 (0/4 dirs trivial) matches; K dropped 28->30 (2/4 dirs trivial), n=2 168->172 (4/8) vs 168->176; the conclusion is K-dependent (test b); I08 does not report the non-K result"),
        dict(list=W,quote="own data (data/C_n_gamma.json)",loc="data/C_1_gamma.json",kind=C,contradicts="g_summary gamma: run's non-K data differ from the no-sign reference by negation in 26/50 entries ('diff neg 26'); declared convention is supercentral signs (I05.md:51), so a sign difference is expected under that reading; not compared with the 'super' reference at stage 1",evidence=VR,detail="judging/g_summary.csv gamma_n1 (thm01-R-luna-r3-G)")],
 drop=[D("stage-1 issues","none listed; argument_issues is empty"),D_CAL])
S['thm01-R-sonnet46-G']=dict(
 rr="single reading: no gb parity, sign or K statement in I08; K absent from the data; headline 'trivial iff gb = 0' (I08.md:95), tested per direction and all-plus only.",
 ai=[(T,U,RO,"n_phi - rank(A) is the kernel of A on phi-space; the number of gamma directions outside Image(A) is rank[A|G]-rank(A) (g_summary +4/+8, equal numerically); 'not a coincidence ... deep symmetry' asserted without derivation",None),
     (T,U,DD,"docs/drafts/aoi2026_triviality_osp1_2n.tex not in the copy (docs/ has issues, math, json_schema_specification.md); named only at docs/math/B0n_definition.md:8; no file states a B(0,n) triviality conjecture",None),
     (T,U,RO,"no code or data computes 'effective degrees of freedom of f after the Jacobi conditions'; script does per-direction solvability only",None)],
 extra=[], drop=[D_CAL])
S['thm01-R-sonnet46-r2-G']=dict(
 rr="single reading: no gb parity, sign or K statement; K absent from the data; headline 'trivial iff all gb parameters are zero' (I08.md:97), tested all-plus and per direction.",
 ai=[(T,C,RO,"own table I08.md:57 and script give rank 28/168/516; the formula evaluates to 12 (n=1), 80 (n=2), 252 (n=3)",None),
     (T,C,DD,"docs/math/C_coboundary_definition.md (delta f)(X,Y) = (-1)^{p(X)}[X,f(Y)] - (-1)^{(p(X)+1)p(Y)}[Y,f(X)] - f([X,Y]); for odd X=Y first two terms give -2[X,f(X)]",None),
     (T,C,RO,"data/C_1_evaluated.json has no entry with X=E_2del1_p and Y in {E_eps1_del1_mm, E_eps1_del1_pm}; entries are Y in {E_eps1_del1_pp, E_eps1_del1_mp, H_1} (checked by script)",None),
     (T,U,RO,"null dim = phi columns - rank(A) (kernel on phi-space), not a count of obstructions; obstruction count is rank[A|G]-rank(A) (g_summary +4/+8); no derivation of 'isomorphic'",None),
     (T,U,DD,"docs/math/B0n_definition.md:114-120 states nothing about triviality or redefinitions; no file in the copy supports the statement",None)],
 extra=[dict(list=W,quote="gamma data in data/C_n_gamma.json",loc="data/C_1_gamma.json",kind=C,contradicts="g_summary gamma: run's gamma misses 11/50 (n=1) and 68/292 (n=2) entries of the no-sign reference (stage 1 did not check which Z are missing)",evidence=VR,detail="judging/g_summary.csv gamma_n1, gamma_n2 (thm01-R-sonnet46-r2-G)")],
 drop=[D("notes: calibration ('wrong image dimension and delta f formula')","duplicate of argument_issues[0],[1]"),D("consistency_with_data","merged into the gamma data item")])
S['thm01-R-sonnet46-r3-G']=dict(
 rr="single reading: gb parity 1 consistent with kappa odd (I05.md:57), K=1 'cancels in valid Lie algebra brackets' (final_reflection.md:24); headline 'trivial iff all gb zero' (I08.md:106), tested per direction and four profiles.",
 ai=[(T,U,RO,"script's null_dim is n_phi - rank (src/C_triviality.py:161); 'Im(gamma)/Im(delta o gamma)' is not defined or computed; cocycle condition never checked",None),
     (T,U,RO,"script tests Gamma_l in Im(delta) one l at a time, not the rank of the Gamma_l modulo Im(delta); g_summary rank[A|G]-rank(A)=4n shows independence holds for the run's data",None),
     (T,U,DD,"no file in the copy states this B(0,n) result; B0n_definition.md:8 only names the .tex (absent) and Bakalov-Sullivan",None),
     (T,U,RO,"no computation of H^2 in the run (no cocycle space computed)",None),
     (T,U,NC,"displayed equation by itself is solvable per stage 1; inconsistency lies only in the unexhibited full system",None)],
 extra=[dict(list=T,quote="correctly handling the scalar K=1 term (which cancels in valid Lie algebra brackets)",loc="docs/issues/final_reflection.md:24",kind=U,contradicts="",evidence=AU,detail="reflection :22 states N_k = sum H_j - H_{n+1} - K/2; n=1 case verified by agent computation check_osc.py, general n not checked; the run's gamma data do not record K (g_summary) while other runs' gamma data contain K terms")],
 drop=[D_CAL])
S['thm01-R-luna-C']=dict(
 rr="several readings discussed, none adopted: gb odd vs even over field C (mathematical_proof.md:47) and 'up to scalar' read as one global scalar (:54); K not discussed. Headline: the supplied definitions do not determine the condition (:5).",
 ai=[(T,C,DD,"docs/math/Cn1_definition.md section 2 'All root generators' (lines 36-44) writes every generator as an oscillator monomial with CAR/CCR relations; other runs generate the full structure constants from these documents",None),None],
 extra=[], drop=[D_TASKREQ("argument_issues[1]: issue_open.md:23 'Generate structured data ...'"),D("computation: artifact marks structure-constant and gamma matrices as unavailable (mathematical_proof.md:60)","statement describes the artifact honestly; absence of data recorded by stage 1, not an issue"),D_CAL])
S['thm01-R-luna-r2-C']=dict(
 rr="two readings: literal central-extension reading (deformation term central-valued, delta f g-valued) -> every gb = 0 (mathematical_proof.md:5); adjoint reading -> undetermined by the supplied definitions. Headline: undetermined for the intended adjoint reading, conditional 'gb=0' for the literal reading; the literal conclusion depends on keeping the central component.",
 ai=[(T,C,DD,"docs/math/Cn1_definition.md section 2 (lines 36-44) writes every generator as an oscillator monomial with CAR/CCR relations; other runs derived all three from these documents","mathematical_proof.md:76")],
 extra=[], drop=[D("computation: cn1_triviality_verification.json counts, tensors null","statement describes the artifact honestly (mathematical_proof.md:76); not an issue"),D_CAL])
S['thm01-R-luna-r3-C']=dict(
 rr="three readings of 'up to scalar' listed and no choice made (mathematical_proof.md:86-108); literal direct-sum reading (gamma C kappa-valued, delta f g-valued) gives gb = 0 (:5); gb even vs odd discussed (:80). Headline: undetermined for the adjoint-valued problem.",
 ai=[(T,C,DD,"docs/math/Cn1_definition.md section 2 (lines 36-44) writes every generator as an oscillator monomial with CAR/CCR relations",None)],
 extra=[dict(list=W,quote="assert data[\"status\"] == (\"adjoint_valued_problem_underdetermined_and_definitions_inconsistent\")",loc="docs/issues/verify_cn1_artifacts.py:15",kind=U,contradicts="",evidence=RO,detail="conclusion flags are stored in the JSON and re-asserted by the script; no gamma, delta f or rank computed (rerun exit 0, no files regenerated)")],
 drop=[D_CAL])
S['thm01-R-sonnet46-C']=dict(
 rr="single reading: K dropped 'up to scalar K-terms' (mathematical_proof.md:89), no sign for moving kappa (Lemma 2.1, :33), gb parity not stated; headline 'trivial iff gb = 0' (:174).",
 ai=[(T,C,OS,"same Step 2 derives a solvable equation for the H_2 component (:125) yet the summary (:176) says H_2 'cannot be produced by any delta f'; Step 4 (:150) asserts 'self-consistent only if gb = 0' without derivation",None),
     (T,C,OS,"line :130 gives the target as 2 gb_{+,j,-} E_{2 delta_j} while this step analyses H_1/H_2 components and gb_{+,j,+}; stage-1 agent computation check_osc.py (n=1): {a^+b^+,a^-b^-} = -H_1-2H_2 exactly, the '+K' version fails (agent_unvalidated)",None),
     (T,C,OS,"stated gamma entries use gb_pm / gb_mm while the conclusion drawn for the same pair names gb_pp / gb_mp; report Step 3 (:138) names gb_{+,j,+}",None),
     (W,C,RO,"scripts/verify_triviality.py contains the gamma values as literals (GAMMA_GB_N1) and no code computing them; reflection (:40) says a verification script was run: it only prints those literals","final_reflection.md:17")],
 extra=[dict(list=W,quote="# Computed from deformed oscillator algebra: b^s a^sigma = a^sigma b^s - gb*kappa  (followed by hard-coded GAMMA_GB_N1 dict)",loc="scripts/verify_triviality.py:38",kind=C,contradicts="comment says 'Computed' but the dict is typed literals; no computation code",evidence=RO,detail="scripts/verify_triviality.py:38 (rerun: prints the literals only)"),
        dict(list=W,quote="OBSTRUCTIONS list with the conclusions written as literals; triviality_theorem(n): 'triviality_conditions' = a dict of zeros",loc="scripts/verify_triviality.py:86,113",kind=U,contradicts="",evidence=RO,detail="no linear algebra in the script; JSON table lists 'trivial iff all gb=0' for n=1,2,3"),
        dict(list=W,quote="JSON table lists 'trivial iff all gb=0' for n=1,2,3, but only n=1 formulas (Props 2.2, 2.3) are derived in the text",loc="docs/issues/mathematical_proof.md:184",kind=U,contradicts="",evidence=OS,detail="self-statement of limited scope for n=2,3")],
 drop=[D("notes: parity note corrected in reflection (final_reflection.md:24)","history; extractor remark"),D_CAL])
S['thm01-R-sonnet46-r2-C']=dict(
 rr="single reading: scalars dropped ('up to scalar' = identification modulo identity / dropping scalar 1/2; mathematical_proof.md:112; verification_artifacts.py:159); headline 'every gamma_gb is trivial for all gb' (:118). Corresponds to the 'even gb, K dropped' reading.",
 ai=[(T,U,DD,"no document in the copy states or sources this vanishing lemma (docs/math has none); reflection names it 'Whitehead/Kostant vanishing theorem' (final_reflection.md:17); gamma_gb never checked to be a 2-cocycle","mathematical_proof.md:59"),
     (T,C,DD,"[E_{eps+delta_1}, f(H_2)] is a bracket of two odd elements (f odd), hence even and may have an E_{2delta_1} component, but is labelled '[odd terms]' and dropped; f(H_2) never defined (report :88)",None),
     (T,C,OS,"three different expressions for f(E_{eps+delta_1}): report :83 (with gb_{+,j,+}[b_j^- b_k^+]), :102 (without), verification_artifacts.py:163 ({'E_2d1': 2*alpha_pp, 'H2': -alpha_pm})",None),
     (W,C,OS,"the comment two lines above gives -gpp*H2; code writes +gpp (verification_artifacts.py:230)",None),
     (T,C,AU,"agent computation check_osc.py (n=1) from Cn1_definition.md oscillator realization: [H_1,a^+b^+] = 2a^+b^+, [H_1,a^+b^-]=0, {a^+b^-,a^-b^+}=H_1, {a^+b^+,a^-b^-}=-H_1-2H_2; the script's values {H1:1,H2:1} and {H1:1,H2:-1} fail; dictionaries are not used by the check but are given as 'structure constants of osp(2|2)' (report :137)",None),
     (W,C,RO,"both sides of the comparison are the same literal -2*gb['gb_+_1_-'] (alpha_pp and gpm read the same key; rerun output computed=-0.6000, expected=-0.6000); gamma is hard-coded (verification_artifacts.py:222)","final_reflection.md:19")],
 extra=[dict(list=W,quote="gamma(H2,E_epd1) written as the literal {'E_2d1': -2*gpm}; delta f coefficient written as the literal -4*alpha_pp + 2*alpha_pp",loc="docs/issues/verification_artifacts.py:222,261",kind=U,contradicts="",evidence=RO,detail="values typed into code, not computed from the algebra"),
        dict(list=W,quote="JSON field delta_f_matches written as the literal True; unconditional conclusion print",loc="docs/issues/verification_artifacts.py:319,303",kind=U,contradicts="",evidence=RO,detail="rerun exit 0; match is by construction")],
 drop=[D_CAL])
S['thm01-R-sonnet46-r3-C']=dict(
 rr="single reading: 'up to scalar' = quotient by C.Id (K dropped; mathematical_proof.md:129), kappa odd central (:30), no sign convention stated; headline 'trivial iff all gb vanish, all n >= 1' (:245).",
 ai=[(T,C,AU,"agent computation check_osc.py (n=1): a^+b^- a^-b^+ + a^-b^+ a^+b^- = N_f + N_b = H_1 exactly (H_1-2H_2 fails); the script line carries the comment 'mod scalar +1 in H1? adjust'","verify_triviality.py:63"),
     (T,C,OS,"F1 = a^+b^+ and E2d = (b^+)^2/2 both carry b^+; with [H2,E2d] = -2E2d (line :39) F1 has eigenvalue -1, not +1; report :88 uses [H_2,E_{+2delta}] = -2E (agent computation check_osc.py: [H_2,a^+b^+] = -a^+b^+)",None),
     (T,C,AU,"agent computation check_osc.py (n=1): with [b^-,b^+]=1, [(b^+)^2/2, a^+b^-] = -a^+b^+ and [(b^-)^2/2, a^+b^+] = +a^+b^-",None),
     (T,U,RO,"derivation of gamma-tilde(F1,H1) not shown ('Similarly', :69); the contradiction '-2 = -1' (:115) depends on it; cross-run: thm01-R-luna-A data has gamma(E_{eps+delta_1},H_1) = gb_{a+,b+} H_1 + 2 gb_{a+,b-} E_{2delta_1} (no H_2 term)",None),
     (T,U,RO,"no code or derivation checks the cocycle condition",None),
     (W,C,RO,"structure constants are typed by hand as set_bracket literals; no oscillator code",None)],
 extra=[dict(list=W,quote="gamma_tilde(F1,H1) = -H2; gamma_tilde(F1,H2) = H2; gamma_tilde(F1,F1) = -2 F1 written as literals; docstring says 'symbolically' while the code uses numpy float lstsq (line 146)",loc="verify_triviality.py:97,99,101,5",kind=C,contradicts="docstring 'symbolically' (:5) vs numpy float least squares (:146); gamma-tilde values typed as literals",evidence=RO,detail="rerun reproduces rank 6, residual 0.6 (numerically identical to final_reflection.md:19)"),
        dict(list=W,quote="Section 5 table lists n=1,2,3 as 'gb = 0'; only n=1 has any computation",loc="docs/issues/mathematical_proof.md:143",kind=U,contradicts="",evidence=RO,detail="n=2,3 rows are a table without computation; test covers one direction (gb_{+,1,+}=1) at n=1")],
 drop=[D_CAL])

def build_loc(q,l):
    m=re.search(r'([A-Za-z0-9_./{}\-]+\.(?:md|py|json|txt|tex)):?(\d+)?',q if isinstance(q,str) else '')
    return m.group(0).rstrip(':') if m else ''

def ensure_str(x): return x if isinstance(x,str) else json.dumps(x,ensure_ascii=False)

def make(o):
    r=o['run']; s=S[r]
    ai=o.get('argument_issues',[])
    assert len(ai)==len(s['ai']),(r,len(ai),len(s['ai']))
    th=[];wk=[]
    for it,spec in zip(ai,s['ai']):
        if spec is None: continue
        lst,kind,ev,det=spec[:4]; locov=spec[4] if len(spec)>4 else None
        q=it['quote']; loc=locov or it.get('loc') or build_loc(q,None)
        c=it.get('contradicts','')
        d={"quote":q,"loc":loc,"kind":kind}
        if kind==C:
            d["contradicts"]=c
            d["evidence"]=ev; d["evidence_detail"]=det
        else:
            d["contradicts"]=""
            d["evidence"]=ev; d["evidence_detail"]=det+" | stage-1 note: "+c
        (th if lst==T else wk).append(d)
    for e in s['extra']:
        d={"quote":e['quote'],"loc":e['loc'],"kind":e['kind'],"contradicts":e['contradicts'] if e['kind']==C else "","evidence":e['evidence'],"evidence_detail":e['detail']}
        if e['kind']==U and e['contradicts']: raise Exception
        (th if e['list']==T else wk).append(d)
    return {"run":r,"commit_checked":o['commit_checked'],"remark_readings":s['rr'],"theory_items":th,"work_items":wk,"dropped":s['drop']}

os.makedirs(REV+'facts2',exist_ok=True)
rep={}
for g in ['may','interactive']:
    out=[]
    for l in open(REV+f'facts/{g}.jsonl'):
        out.append(make(json.loads(l)))
    with open(REV+f'facts2/{g}.jsonl','w') as f:
        for o in out: f.write(json.dumps(o,ensure_ascii=False)+'\n')
    from collections import Counter
    c=Counter()
    for o in out:
        for k in ('theory_items','work_items'):
            for i in o[k]: c[(k,i['kind'],i['evidence'])]+=1
        c['dropped']+=len(o['dropped'])
    rep[g]=(len(out),c)
    print(g,len(out))
    tk=Counter(); 
    for o in out:
        tk['theory']+=len(o['theory_items']); tk['work']+=len(o['work_items']); tk['dropped']+=len(o['dropped'])
        for k in ('theory_items','work_items'):
            for i in o[k]: tk[i['kind']]+=1; tk['ev:'+i['evidence']]+=1
    print(dict(tk))
