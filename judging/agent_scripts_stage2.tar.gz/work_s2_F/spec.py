# per-run sorting decisions (hand-made from stage-1 text). T=theory W=work; C=contradiction U=unsupported
OWN='own_other_statement'; CODE='run_own_code_or_data'; DEF='definition_docs'; LOG='logs'; VAL='validated_reference'; AG='agent_unvalidated'; NC='not_checked'
K25='docs/math/C_coboundary_definition.md:25 ("up to scalar")'
B0n='docs/math/B0n_definition.md:8 cites docs/drafts/aoi2026_triviality_osp1_2n.tex (absent from the copy)'
S={}
def run(name, remark, ai, extra=(), drop=()):
    S[name]=dict(remark=remark, ai=ai, extra=list(extra), drop=list(drop))

run('thm01-R-haiku45-b02-G',
 'single reading: gb odd (parity 1, I05.md:61); only gb=0 evaluated; K not treated (no gamma computed).',
 [('T','C',OWN,'I08.md:123,126-127'),('T','C',OWN,'I08.md:153,163'),('T','C',OWN,'I08.md:41,155-175'),
  ('W','C',CODE,'data/C_1_structure.json structure_constants has 0 entries; src/C_evaluated_generator.py:60 placeholder; agent computation count_sc.py'),
  ('W','C',OWN,'I08.md:129')],
 drop=[('computation.hardcoded: gb_values[label]=0.0, placeholder formatter, unformatted f-string text in C_1_structure.json, "result": "to be determined"','evidence for work_items[0] (AI[3]); not separate statements')])
run('thm01-R-haiku45-b04-G',
 'single reading: gb odd (parity 1, I05.md:126); K not treated; only all_positive profile with one fixed f.',
 [('T','C',CODE,'src/coboundary_generator.py:37-39; I08.md:191'),('T','C',OWN,'I08.md:106,127'),('W','C',OWN,'I08.md:226; test_range = all_positive only'),
  ('T','U',CODE,'I08.md:171; no profile other than all_positive computed')],
 drop=[('computation.hardcoded: "f(even roots) = 0 (simplified)", coeff=Fraction(1, eps_per_cartan), structure_constants 0 entries','evidence for theory_items[0]; facts about code/data, not run statements')])
run('thm01-R-haiku45-b06-G',
 'single reading: gb odd (parity 1, I05.md:48); K not stated; non-triviality shown with f=0 only.',
 [('T','C',OWN,'I08.md:51,62,73,182,186-187'),('T','C',CODE,'data/C_1_gamma.json gamma_terms; agent computation count_gamma_terms.py'),('T','C',OWN,'final_reflection.md:215,217')],
 drop=[('consistency_with_data / notes: run structure constants differ from reference (g_summary sc "different"); gamma_terms with Z==Y; structure_constants 4/16/28 entries','recorded in g_summary.csv (sc_n1/sc_n2, gamma columns); not a run statement')])
run('thm01-R-haiku45-b08-G',
 'single reading: gb odd (parity 1, I05.md:85); conditional conjecture "trivial when all gb = +-1"; no K treatment.',
 [('T','C',CODE,'I08.md:67,84,101; src/triviality_analysis.py:100-126'),('T','C',CODE,'src/C_coboundary_generator.py:92-99'),('T','C',CODE,'src/C_coboundary_generator.py:60-77'),
  ('T','U',CODE,'I08.md:110-114; only gb=+1 evaluated'),('T','C',CODE,'I08.md:110; src/C_coboundary_generator.py:137-138'),('W','C',OWN,'I08.md:67,84,101')],
 extra=[('T','The inhomogeneous deformation of C(n+1) is **TRIVIAL** when: 1. All gb parameters equal ±1 (uniform sign)','docs/issues/I08.md:174-175','C',
   'Reference ranks n=1 28->32, n=2 168->176 (extract_spec, odd-gb reading / K kept): gb=+1 is non-trivial; run declares gb parity 1 (I05.md:85)',VAL,'extract_spec.md reference ranks; g_summary.csv data_implies "trivial iff gb=0" (other runs\' rows); this run\'s gamma unreadable')],
 drop=[('computation.hardcoded: "# This is a simplified implementation", "# For now, return a symbolic entry", 3x3 subset loop','evidence for theory_items[1], [4]; not separate statements')])
run('thm01-R-haiku45-b10-G',
 'single reading: gb odd (parity 1, data/C_1_gamma.json); K not discussed; conditional conjecture with four qualitative conditions.',
 [('W','C',CODE,'src/triviality_search.py:110,117'),('T','C',OWN,'I08.md:55,63,71,132'),('T','C',DEF,'docs/math/C_inhomogeneous_definition.md:25 (kappa central)'),
  ('T','U',DEF,B0n),('T','C',CODE,'data/C_1_gamma.json single gamma row, quadratic coefficient; docs/math/C_inhomogeneous_definition.md (linear in gb)')],
 drop=[('computation.hardcoded: single gamma row {"Z": "K", "coeff": "gb_a1_p_b1_p * gb_a1_m_b1_m"}','evidence for theory_items[3]; fact about data')])
run('thm01-R-luna-b02-G',
 'single reading: gb even (parity 0; run rewrote the Parity Note), kappa odd, K kept in gamma and excluded from f (I08.md:53-55); conclusion trivial iff gb=0.',
 [('T','C',DEF,K25+'; g_summary rank_nonK 28->28 (4/4 dirs trivial)'),('T','C',OWN,'I02.md:48; I07.md:40-41; src/C_gamma.py:150'),
  ('T','C',DEF,'docs/math/C_inhomogeneous_definition.md "Parity Note" in other copies, e.g. thm01-R-haiku45-b02-G/docs/math/C_inhomogeneous_definition.md')],
 drop=[('notes: Worker edited docs/math/C_inhomogeneous_definition.md; final chat "I also corrected the gb parity note"','duplicate of theory_items[2]'),
       ('k_dependence / consistency_with_data: K-dependent; matches K-kept column, mismatches K-dropped column','comparison, not a run statement; covered by theory_items[0] and remark_readings')])
run('thm01-R-luna-b04-G',
 'readings: adopts odd gb (I05.md:41), K kept in gamma and excluded from f/delta f; I08.md:55 says the result is "formal, not a parity-consistent superalgebra result" and a parity-consistent reformulation is unresolved (no conclusion given for it). Headline: trivial iff gb=0 (I08.md:53).',
 [('T','C',DEF,K25),('W','C',CODE,'src/C_triviality.py:63-122 (len(isolating_rows))'),('T','C',OWN,'I08.md:55')],
 extra=[('W','status = "non-trivial" if central_terms else "trivial"','src/C_triviality.py:103','U','',CODE,'status string chosen by presence of central terms, no rank comparison (stage-1 computation.hardcoded)'),
        ('W','Fraction(term["coeff"]) * 0','src/C_triviality.py:105','U','',CODE,'zero assignment "verified" by multiplying coefficients by 0 (stage-1 computation.hardcoded)')],
 drop=[('notes: run flags parity conflict and calls result formal; "Total Wall Time: Not available"','parity flag used in remark_readings; wall-time statement not contradicted')])
run('thm01-R-luna-b06-G',
 'readings: odd gb ("formal"); I08.md:40 states a parity-consistent reformulation could change the triviality result (no conclusion given); K kept in gamma, any K component counted as obstruction. Headline: trivial iff gb=0 (I08.md:39). Run appended a "Consistency caveat" paragraph to docs/math/C_inhomogeneous_definition.md.',
 [('T','C',DEF,K25),('T','C',CODE,'src/analyze_C_triviality.py:88 (rank of K-coefficient matrix only); I08.md:40')],
 drop=[('notes: Worker edited docs/math/C_inhomogeneous_definition.md (appended caveat)','workspace edit, no statement contradicted; recorded in remark_readings'),
       ('k_dependence: K-dependent argument','comparison, not a run statement')])
run('thm01-R-luna-b08-G',
 'single reading: gb even (parity 0; run rewrote the Parity Note, I05.md:49-51), kappa odd with signs, K kept in gamma and excluded from f; conclusion trivial iff gb=0.',
 [('T','C',DEF,K25+'; g_summary rank_nonK 28->28 (4/4 dirs trivial)'),('T','C',DEF,K25+'; I08.md:53-54')],
 extra=[('T','Homogeneity therefore requires gb parity 0. I chose parity 0 rather than preserve the conflicting parity-1 note, corrected the reference note','docs/issues/I05.md:49-51','C',
   'task document Parity Note in other copies: "gb must have parity 1" (e.g. thm01-R-haiku45-b02-G/docs/math/C_inhomogeneous_definition.md)',DEF,'Worker edited docs/math/C_inhomogeneous_definition.md (stage-1 notes)')],
 drop=[('notes: edited definition doc; added all-zero evaluated profiles','edit covered by work/theory item above; extra data files not a statement')])
run('thm01-R-luna-b10-G',
 'single reading: gb even (parity 0; run rewrote the parity statement, I05.md:48-50), supercommutation signs, K kept in gamma and excluded from f; conclusion trivial iff gb=0.',
 [('T','C',DEF,K25+'; g_summary rank_nonK 28->28 (4/4 dirs trivial)'),('T','U',CODE,'I08.md:71-72 n=1,2,3 only; no general-n argument in the report'),
  ('W','U',CODE,'src/analyze_C_triviality.py:136 defaults to ranks 1 2 3; no n=4 data under data/ (agent check: ls data)')],
 extra=[('T','Chose parity 0, which makes the relation homogeneous and preserves the CAR with odd central `kappa`; corrected the parity statement in `docs/math/C_inhomogeneous_definition.md`','docs/issues/I05.md:48-50','C',
   'task document Parity Note in other copies: "gb must have parity 1"',DEF,'Worker edited docs/math/C_inhomogeneous_definition.md (stage-1 notes)')])
run('thm01-R-opus46-b06-G',
 'single reading: gb odd (parity 1, I05.md:63), gamma and delta f without K; conclusion trivial iff gb=0.',
 [('T','U',DEF,B0n+'; no B(0,n) computation in the run'),('T','U',CODE,'I08.md:67 computed fact is null space of delta; so(2) mechanism not computed'),('T','C',OWN,'I08.md:88-91')],
 drop=[('notes / consistency_with_data: run gamma differs from reference (g_summary gamma "~super 18/48", miss 4, extra 3, diff 26 of which neg 22); ranks 28/168/516 equal reference','recorded in g_summary.csv gamma column; not a statement of the run; conclusion unchanged per g_summary')])
run('thm01-R-opus46-b08-G',
 'single reading: gb parity not stated; gamma and delta f without K; conclusion trivial iff gb=0 (I08.md:89), tested on +-1 sign profiles only.',
 [('T','C',VAL,'g_summary ownA 32->36 (n=1), 176->184 (n=2) and reference rank A 28/168/516 (extract_spec)'),
  ('T','C',VAL,'g_summary rank 28->32 (0/4 dirs trivial), 168->176 (0/8): appending gb columns raises rank by 4n'),
  ('T','U',DEF,B0n+'; no B(0,n) computation in the run'),
  ('T','U',CODE,'I08.md:61,89; gb=0 not evaluated in I08, only +-1 sign profiles'),
  ('T','U',CODE,'src/C_triviality_extended.py:149-155 (unnormalised float norm of one fixed profile)')],
 drop=[('notes: run rank(A) = number of phi (32/176/528) differs from reference rank A; ranks floating-point numpy','covered by theory_items[0]; float arithmetic is a fact about code')])
run('thm01-R-opus46-b10-G',
 'single reading: gb parity not stated; K kept in gamma, excluded from delta f (I08.md:77); conclusion: non-trivial for any non-zero gb (trivial iff gb=0).',
 [('T','C',DEF,K25+'; I08.md:77 calls gamma a 2-cocycle, no cocycle check in src/C_triviality.py'),('T','C',OWN,'I08.md:89,96; final_reflection.md:19'),
  ('T','U',DEF,B0n),('T','U',CODE,'src/C_triviality.py main ranks n=1,2,3 only')],
 drop=[('notes: gamma lacks 4/8 reference entries (g_summary "miss 4/8"), K rows match','recorded in g_summary.csv; not a run statement')])
run('thm01-R-opus46-b12-G',
 'single reading: gb parity not stated; no K in gamma; conclusion: never trivial for non-zero gb (trivial iff gb=0), uncommitted debug scripts present.',
 [('T','C',OWN,'I08.md:70,74; src/C_triviality.py:141-181 (generic symbolic rank)'),('T','U',CODE,'src/C_triviality_numerical.py:17; no alternating profile or linear combination evaluated'),
  ('T','U',DEF,B0n+'; no B(0,n) computation in the run'),('W','C',OWN,'final_reflection.md:41')],
 drop=[('notes: uncommitted src/debug_bracket.py, src/debug_jacobi.py; gamma lacks 4/8 reference entries','uncommitted files listed in inventory.csv/run.json; not a statement; g_summary covers gamma')])
run('thm01-R-opus46-b13-G',
 'single reading: gb parity not stated for gb; no K in gamma; conclusion: non-trivial for all non-zero gb (trivial subspace {0}).',
 [('W','C',CODE,'src/C_triviality.py:57-69,92-138 float arrays, np.linalg.matrix_rank(tol=1e-10)'),('T','U',DEF,B0n+'; no B(0,n) computation in the run'),
  ('T','U',CODE,'src/C_triviality.py computes only rank(A|B) vs im delta; no cocycle or cohomology computation')],
 drop=[('notes / consistency_with_data: joint and per-direction tests present; gamma differs from reference (miss 9, extra 1, diff 4) but ranks equal reference','recorded in g_summary.csv; not a run statement')])
run('thm01-R-opus47-b02-G',
 'single reading: gb odd (parity 1, I05.md:50-51), kappa odd; no K in gamma; conclusion trivial iff gb=0 (n=1,2 computed; n=3 not).',
 [('T','C',OWN,'I08.md:55-56 numbers; agent computation work_bG_haiku_luna_opus4x/arith.py (n_eqs - rank = 184 / 2580)'),
  ('T','C',OWN,'I08.md:145-147'),('T','U',CODE,'src/C_triviality.py computes ranks of Delta and [Delta|Gamma] only; final_reflection.md:77'),
  ('T','U',NC,'no reference or derivation in docs/math or handover')],
 drop=[('notes: n=3 not computed; gamma lacks 5 (n=1) / 32 (n=2) reference entries','n=3 point covered by theory_items[1]; gamma coverage recorded in g_summary.csv')])
run('thm01-R-opus48-b02-G',
 'single reading: gb odd (parity 1, I05.md:47-48), kappa odd; K kept in gamma and in the codomain of f (I07.md:39-47); conclusion trivial iff gb=0.',
 [('W','U',CODE,'agent check: grep all_plus/single/profile in src/C_triviality.py, C_triviality_witness.py finds only a comment at :55'),
  ('W','U',CODE,'agent check: grep -rn random|genuine|validate src tests returns nothing'),
  ('T','U',DEF,'agent check: grep -rn Aoi handover returns nothing; '+B0n),
  ('T','U',CODE,'src/C_triviality.py compares gamma with im delta only; no cocycle/H^2 computation')],
 drop=[('reported_numbers / consistency_with_data: rank M with K-kept f = 32 differs from K-dropped reference rank A 28; gamma "~none 45/50 ... diff 5 of which neg 5"','rank 32 is the declared K-kept reading (g_summary ownA_K 32->36); recorded in g_summary.csv; not a contradiction of a run statement'),
       ('notes: committed data/C_triviality_summary.json; witness checked','not a statement; supports the run')])
run('thm01-R-opus5-b02-G',
 'multiple readings: (1) f: g -> g(+)CK (K target allowed): "Every inhomogeneous deformation of C(n+1) is trivial" (I08.md:38-42), adopted as primary/headline (I08.md:251-252); (2) restricted f: g -> g: obstructions 12/40/84, "iff gb = 0" (I08.md:196-200, 284-287). gb even (I05.md:93-94); K-dropped option (b) explicitly rejected (I07.md:53-54).',
 [('T','C',OWN,'I08.md:191-192,198-200; docs/math/C_coboundary_definition.md:7 "f: g -> g"'),('T','C',DEF,K25),('T','C',OWN,'I08.md:240-241,286-287; I07.md:57-58')],
 drop=[('notes: run reports both readings and states which is primary; docs/math files unchanged; drafts/github referenced in README absent (final_reflection.md:138-146); B(0,n) comparison labelled a prediction (I08.md:289-301)','recorded in remark_readings; no discrepancy flagged')])
run('thm01-R-opus55-b02-G',
 'multiple readings: mod_K ("up to scalar" = modulo central terms, "main reading", I08.md:44): all gb trivial (I08.md:129 "empty (all gb)"); strict_cent (f: g -> g(+)CK): all gb trivial; strict (f: g -> g, kappa*1 term must match): trivial iff gb=0 (I08.md:129, final_reflection.md:31). Headline: all gb trivial. gb commuting scalars (I05.md:77).',
 [('W','C',LOG,'run.json / runs/batch/thm01-R-opus55-b02-G/turn1.jsonl.gz: 4 permission_denials (agent computation pd.py)')],
 extra=[('W','Every checker has a negative control','docs/issues/final_reflection.md:33','U','',NC,'stage-1 notes: "not checked by me"')],
 drop=[('notes: Writes /tmp/i05.log inside a denied command (outside_refs empty)','fact about a denied command in the log, not a run statement'),
       ('consistency_with_data: headline K-dependent (strict reading with K kept flips it)','comparison; recorded in remark_readings')])
run('thm01-R-opus55-b04-G',
 'multiple readings: g-valued / L = g (+) kappa g: all gb trivial (I08.md:144, headline); strict (generators change only by g-valued kappa terms): trivial iff gb=0 (I08.md:147); T1/T2/T3 notions (I08.md:56-57); "Which answer ... depends on which notion is meant" (I08.md:41).',
 [],
 drop=[('notes: permission_denials count 6 (pd.py); reflection states no count','no run statement to compare'),
       ('consistency_with_data: headline K-dependent','comparison; recorded in remark_readings')])
run('thm01-R-opus55-b06-G',
 'multiple readings: A (main; f: g -> g(+)CK, trivial up to central scalars K=1): always trivial (I08.md:115, headline); Strict (f: g -> g): trivial iff gb=0 (I08.md:116, final_reflection.md:17); mode B symbolic conditions rank 4n. gb even (I05.md:46).',
 [('W','C',LOG,'run.json / turn1.jsonl.gz: 4 permission_denials: cat loop on handover docs; three python heredocs (src/C_evaluate.py, src/C_coboundary.py, docs/issues/I08.md); no awk pipe, no heredoc into tests/ (agent computation pd.py)')],
 drop=[('notes: "Run has 70 passed tests (I08 last line)"','test count self-report (docs/issues/I08.md:134 "70 passed"); no discrepancy flagged'),
       ('consistency_with_data: headline K-dependent','comparison; recorded in remark_readings')])
run('thm01-R-opus55-b08-G',
 'multiple readings: mod-K ("adopted reading"): every gb trivial (I08.md:109, headline); strict-g: trivial iff gb=0 (I08.md:106); strict-gK reported too. gb commuting scalars (I05.md:74).',
 [('W','C',LOG,'run.json / turn1.jsonl.gz: 4 permission_denials: cat loop; cat >> docs/json_schema_specification.md heredoc; python heredoc editing I07.md; time python3 src/C_triviality.py | tee (agent computation pd.py)')],
 drop=[('notes: per-direction tests combined with linearity; no joint rank test of [A|G] reported','test_range fact; no flagged claim contradicted or unsupported'),
       ('consistency_with_data: headline K-dependent','comparison; recorded in remark_readings')])
run('thm01-R-opus55-b10-G',
 'multiple readings: mod_K (doc\'s "up to scalar") and exact (f into g+CK): trivial for all gb (I08.md:46, headline); strict (f: g -> g, K-part exact): iff gb=0 (I08.md:153, final_reflection.md:47). gb commuting scalars (I05.md:50).',
 [],
 drop=[('notes: permission_denials count 5 (pd.py); reflection states "The only input was the initial instruction."','no discrepancy shown with a run statement'),
       ('notes: extra data files data/C_{1,2,3}_triviality.json','not a statement'),
       ('consistency_with_data: headline K-dependent','comparison; recorded in remark_readings')])
run('thm01-R-sonnet46-b01-G',
 'single reading: gb parity 1 (I05.md:51); K absent from gamma (agent computation check_K_absent.py); conclusion trivial iff gb=0.',
 [('T','C',OWN,'I08.md:61; I08 table phi params 32, M rank 28; src/C_triviality.py solve_system_fraction returns empty lists for inconsistent systems'),
  ('T','C',DEF,'docs/math/C_inhomogeneous_definition.md:31 (gamma is a 2-cocycle; f is the 1-cochain)')],
 drop=[('notes: runs/batch dir contains check.json and review.md (author-side); final_reflection says two context windows, log has one compact boundary','not a statement contradicted; scribe files not used')])
run('thm01-R-sonnet46-b02-G',
 'single reading: gb even scalars (I05.md:51); K excluded from basis (I02.md:50), no K in gamma; conclusion trivial iff gb=0.',
 [('T','C',DEF,'docs/math/B0n_definition.md:93,103 (B(0,n) also has central kappa, p(kappa)=1)')],
 extra=[('T','is trivial if and only if all gb parameters vanish.','docs/issues/I08.md:71','U','',CODE,'test_range per-direction (n=1,2 only): rank([A|gamma^(gb)]) > rank(A) for each gb separately; no joint test of combinations (stage-1 notes)'),
        ('W','confirms rank([A|γ^{(gb)}]) > rank(A) for every gb parameter and every n ∈ {1, 2}.','docs/issues/I08.md:76','U','',LOG,'no triviality code committed (src/ has none); computation is inline python3 heredocs in turn1.jsonl.gz messages 1532, 1600, 1603')],
 drop=[('notes: witness (H_1,E_eps1_del1_pm,H_2) confirmed in data; runs/batch contains check.json, review.md','supports the run; not a statement'),
       ('reported_numbers/consistency: gamma "~none 46/50 (miss 4)"','recorded in g_summary.csv')])
run('thm01-R-sonnet46-b04-G',
 'single reading: gb parity not stated; K identified with scalar 1 and not in basis (I02.md:48), no K in gamma; conclusion trivial iff gb=0.',
 [('T','C',OWN,'I08.md:68-69 lists 4 conditions for n=1; src/C_triviality_full.py unique_constraints counts distinct rows, no rank'),
  ('T','C',OWN,'final_reflection.md:78 "H^1_odd = 4n"; docs/math/C_inhomogeneous_definition.md:31'),
  ('W','C',LOG,'run.json turns[0].seconds = 2433 (about 41 min), timed_out false')],
 drop=[('notes: one "Output token limit hit" message; reflection counts 1 human intervention; three triviality scripts committed','no discrepancy shown'),
       ('consistency_with_data: gamma covers 16 of 50 reference entries at n=1 (34 missing)','recorded in g_summary.csv')])
run('thm01-R-sonnet46-b07-G',
 'single reading: gb parity not stated; K absent from gamma; conclusion trivial iff gb=0, tested with one fixed f (f(H_1) only).',
 [('T','C',OWN,'I08.md:89,91 "Our specific f (H_1 only) is insufficient."'),('T','C',OWN,'I08.md:36,91'),
  ('T','C',VAL,'g_summary gamma n=1 "~none 16/50 (miss 26, extra 0, diff 8 of which neg 8)"'),('W','C',LOG,'turn1.jsonl.gz: 4 "Output token limit hit" and 1 "continued from a previous conversation" messages (agent computation)')],
 drop=[('notes: compaction and 3 token-limit resumes in the log','covered by work_items[0]'),
       ('consistency_with_data: run did not solve for f; own-A ranks blank','test_range fact, covered by theory_items[0..1]')])
run('thm01-R-sonnet46-b11-G',
 'single reading: gb parity not stated; K absent from gamma; conclusion trivial iff gb=0.',
 [('W','C',LOG,'run.json uncommitted: ?? src/_triviality_conditions_v3.py and ?? src/_individual_gb_test.py; neither file is in the committed copy'),
  ('T','U',DEF,B0n),('T','C',DEF,'docs/math/C_inhomogeneous_definition.md:31 (gamma is a 2-cocycle)'),
  ('T','C',CODE,'agent computation check_K_absent.py: no K-labelled entry in C_n_gamma.json')],
 extra=[('T','is trivial if and only if all $4n$ deformation parameters are zero**','docs/issues/I08.md:85','U','',CODE,'test_range per-direction + all gb=+1 in committed code; joint row reduction for n=1 only in uncommitted script (stage-1 test_range)'),
        ('W','I launched a background computation (`_triviality_conditions_v2.py`) that timed out','docs/issues/final_reflection.md:57','C',
         'log message 572: invoked via Bash with a 300000 ms timeout and no run_in_background field (stage-1 notes)',LOG,'runs/batch/thm01-R-sonnet46-b11-G/turn1.jsonl.gz message 572')],
 drop=[('notes: 12 uncommitted files (all src/_*.py)','covered by work_items[0]')])
run('thm01-R-sonnet55-b02-G',
 'multiple readings: A/B (f may take K values / K ignored): trivial for every gb (I08.md:75, headline; final_reflection.md:18); C (strict f: g -> g, K-part compared): trivial iff gb=0 (I08.md:76). "My reading A is the one forced by the oscillator realization" (I08.md:35). gb numeric scalars; kappa anticommutes with odd a_1 (I05.md:43-44).',
 [],
 extra=[('W','the harness twice only asked me to state what I was doing','docs/issues/final_reflection.md:9','U','',NC,'stage-1 notes: no such message found in turn1.jsonl.gz (log does not contain harness messages as user text; not checkable)')],
 drop=[('notes: reflection discloses helper files written to /tmp (final_reflection.md:33), against session rule 5; untracked scratch/ dir; 5 permission_denials','self-disclosure / workspace facts; no discrepancy with a stated claim shown (recorded for the author)'),
       ('consistency_with_data: headline K-dependent','comparison; recorded in remark_readings')])
run('thm01-R-sonnet55-b04-G',
 'multiple readings: T1/T3 (f into g+CK, or g-only): every gb trivial (I08.md:91, headline "Adopted reading ... T1", I08.md:96); T2 (f: g -> g, central part kept): trivial iff gb=0 (I08.md:92). "Ambiguity 1 (central K)" (I08.md:96).',
 [],
 drop=[('notes: 8 permission_denials (pd.py)','no run statement compared'),('consistency_with_data: headline K-dependent','comparison; recorded in remark_readings')])
run('thm01-R-sonnet55-b06-G',
 'multiple readings: Weyl-symmetrised odd generators, f: g -> g, no K in gamma: every gb trivial (I08.md:71, headline); with normal-ordered odd generators (K appears) and f: g -> g: trivial iff gb=0 (I08.md:78, section 4(a)).',
 [],
 drop=[('notes: 7 permission_denials; extra dirs docs/responses/ and scripts/; probe_gauge.py left in place','no run statement contradicted'),('consistency_with_data: not K-dependent in run data; reading flips with normal ordering','recorded in remark_readings')])
run('thm01-R-sonnet55-b08-G',
 'multiple readings: (E) f: g -> g(+)CK: every gb trivial (I08.md:82, headline "(C-E)"); (S) f restricted to g: trivial iff gb=0 (I08.md:83); "I regard (E) as more plausible but cannot confirm from the documents." (I08.md:88).',
 [],
 extra=[('W','a status ping asked me to say what I was doing','docs/issues/final_reflection.md:9','U','',NC,'stage-1 notes: not found in the log (not checkable)')],
 drop=[('notes: 7 permission_denials; src/_explore.py left in repo; I05 commit amended once','no run statement contradicted'),('consistency_with_data: headline K-dependent','comparison; recorded in remark_readings')])
run('thm01-R-sonnet55-b10-G',
 'multiple readings: (A,B) g-valued part / f may take K values: trivial for every gb (I08.md:91, headline); (C) f restricted to g with the kappa-K residue: trivial iff gb=0 (I08.md:92); "I judge B the natural one" (I08.md:94); "A human decision is needed on the reading before this is cited." (I08.md:94).',
 [('T','C',CODE,'src/triviality_search.py build_system: columns nA (32) + nK (4) = 36 for n=1, printed rank(delta ext)=32 -> kernel 4 (stage-1 reading of code; not rerun)')],
 drop=[('notes: 9 permission_denials (pd.py)','no run statement compared'),('consistency_with_data: headline K-dependent','comparison; recorded in remark_readings')])
