import json,sys,collections
sys.path.insert(0,'.')
from spec import S
REV='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/'
tot=collections.Counter()
used=set()
for g in ['bG_haiku_luna_opus4x','bG_opus55_sonnet']:
    out=[]; n=0
    for l in open(REV+'judging/facts/'+g+'.jsonl'):
        o=json.loads(l); r=o['run']; sp=S[r]; used.add(r)
        ais=o.get('argument_issues') or []
        assert len(ais)==len(sp['ai']),(r,len(ais),len(sp['ai']))
        th=[];wk=[]
        for a,(lst,k,ev,det) in zip(ais,sp['ai']):
            it=dict(quote=a['quote'],loc=a['loc'],kind='contradiction' if k=='C' else 'unsupported',
                    contradicts=a['contradicts'] if k=='C' else '',evidence=ev,
                    evidence_detail=det if k=='C' else ('no support: '+a['contradicts']+' | '+det))
            (th if lst=='T' else wk).append(it)
        for (lst,q,loc,k,c,ev,det) in sp['extra']:
            it=dict(quote=q,loc=loc,kind='contradiction' if k=='C' else 'unsupported',contradicts=c,evidence=ev,evidence_detail=det)
            (th if lst=='T' else wk).append(it)
        dr=[dict(item=i,reason=rs) for i,rs in sp['drop']]
        dr.append(dict(item='stage-1 computation / reported_numbers / rerun / consistency_with_data fields',reason='facts about code, data and rank comparisons already in stage 1 and g_summary.csv; no run statement beyond the items above flagged; rerun was not done'))
        res=dict(run=r,commit_checked=o['commit_checked'],remark_readings=sp['remark'],theory_items=th,work_items=wk,dropped=dr)
        out.append(res); n+=1
        for lstn,items in (('theory',th),('work',wk)):
            for it in items: tot[(g,lstn,it['kind'],it['evidence'])]+=1
    open(REV+'judging/facts2/'+g+'.jsonl','w').write(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out))
    print(g,n)
assert used==set(S)
agg=collections.Counter()
for (g,l,k,e),c in tot.items(): agg[(g,l,k)]+=c
for k,v in sorted(agg.items()): print(k,v)
ev=collections.Counter()
for (g,l,k,e),c in tot.items(): ev[(g,e)]+=c
for k,v in sorted(ev.items()): print(k,v)
