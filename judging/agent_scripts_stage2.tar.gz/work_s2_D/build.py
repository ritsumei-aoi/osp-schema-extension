import json,re,sys,collections
sys.path.insert(0,'.')
from spec_data import S
J='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/judging/'
KIND={'C':'contradiction','U':'unsupported'}
def cut(q,n=300):
    return q if len(q)<=n else q[:n-3]+'...'
LOCRE=re.compile(r'\(((?:docs|scripts|data|final_|supplementary|code|artifacts|verification|[A-Za-z_]+\.(?:py|md|json))[^()]*?:\d[^()]*)\)')
def getloc(q):
    m=LOCRE.findall(q)
    return m[-1] if m else ''
def mk(lst,kind,quote,loc,contradicts,ev,detail):
    if kind=='U' and contradicts:
        detail=(detail+' | stage-1 note: '+contradicts) if detail else contradicts
        contradicts=''
    return lst,{"quote":cut(quote),"loc":loc,"kind":KIND[kind],"contradicts":contradicts,"evidence":ev,"evidence_detail":detail}
tot=collections.Counter()
LOCFIX={('thm01-R-sonnet46-b03-C',7):'final_reflection.md:9; supplementary_metrics.md:10',('thm01-R-opus48-b01-C',1):'docs/issues/issue_open.md:43-45'}
for g in ['bC_opus4x','bC_opus55_sonnet55','bC_sonnet46']:
    out=[]
    for l in open(J+'facts/'+g+'.jsonl'):
        o=json.loads(l); r=o['run']
        if 'status' in o:
            out.append({"run":r,"commit_checked":None,"status":o['status'],"remark_readings":"not applicable (status aborted; stage 1 reports only run, status, deliverables)","theory_items":[],"work_items":[],"dropped":[{"source":"all","reason":"status aborted; no fields beyond deliverables extracted in stage 1"}]})
            continue
        sp=S[r]; cc=o['commit_checked']; scope='first' if cc.startswith('first') else 'final'
        T=[];W=[]
        issues=o['argument_issues']
        for i,iss in enumerate(issues):
            if i not in sp['issues']: raise SystemExit(f'unplaced {r} {i}')
            lst,k,ev,det=sp['issues'][i]
            loc=iss.get('loc') or getloc(iss['quote'])
            loc=LOCFIX.get((r,i),loc)
            lst2,it=mk(lst,k,iss['quote'],loc,iss['contradicts'],ev,det)
            (T if lst=='T' else W).append(it)
        for e in sp['extra']:
            lst,k,q,loc,c,ev,det,sc=e
            if sc!='both' and sc!=scope: continue
            _,it=mk(lst,k,q,loc,c,ev,det)
            (T if lst=='T' else W).append(it)
        for n in sp['issues']:
            if n>=len(issues) and n not in range(len(issues)): pass
        obj={"run":r,"commit_checked":cc,"remark_readings":sp['remark'],"theory_items":T,"work_items":W,"dropped":sp['dropped']}
        out.append(obj)
        for it in T:
            tot[(g,'theory',it['kind'],it['evidence'])]+=1
        for it in W:
            tot[(g,'work',it['kind'],it['evidence'])]+=1
        tot[(g,'dropped')]+=len(sp['dropped'])
        tot[(g,'objects')]+=1
    with open(J+'facts2/'+g+'.jsonl','w') as f:
        for ob in out: f.write(json.dumps(ob,ensure_ascii=False)+'\n')
    tot[(g,'n_out')]=len(out)
for k in sorted(tot,key=str): print(k,tot[k])
