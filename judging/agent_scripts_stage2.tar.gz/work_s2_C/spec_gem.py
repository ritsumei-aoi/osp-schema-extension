from lib import *
S={}
D_PROMPT="quote is the task prompt given to the Worker (run.json), not a statement of the run; the absence of any discussion of 'up to scalar' in the proof is recorded in remark_readings"
S['thm01-R-gemini31p-b01-C']=dict(
 remark="single reading: gb as plain commuting symbols (no parity or kappa sign stated), K absent (basis of g only, f cannot map into K); headline 'trivial iff gb=0' (docs/issues/mathematical_proof.md:34-35).",
 tags=[
  DROP(0,D_PROMPT),
  A(1,'T','V','spec reference ranks A = 28/168/516 (extract_spec.md); run-side values from verification_artifacts.json via agent computation work_bC_gemini38f_31p/summ_b01.py (rank A 176 at n=2, 528 at n=3 = number of f columns)'),
  A(2,'W','S','docs/issues/mathematical_proof.md:34-35 (conclusion stated for all n, no general-n argument in the file)'),
 ])
S['thm01-R-gemini31p-b03-C']=dict(
 remark="single reading: kappa odd central, K not mentioned; headline 'trivial iff gb=0' (docs/issues/mathematical_proof.md:57) rests on a sign argument, no data.",
 tags=[
  A(0,'T','O','scratch/solve.py:44-48 (stub, pass); docs/issues/verification_artifacts.json has no f','U',contra=''),
  A(1,'T','D','docs/math/C_coboundary_definition.md:21 (delta f formula, f odd) vs docs/issues/mathematical_proof.md:45 (shift map called even)'),
  A(2,'W','O','docs/issues/verification_artifacts.json (keys: algebra, generators, gamma_deformation, coboundary_operator, triviality_proof; prose only)',loc='run.json turn 2 final message'),
  A(3,'W','O','scratch/solve.py:44-48 (stub with pass)',loc='run.json turn 2 final message'),
  DROP(4,"quote is a requirement of the task (issue_open.md), not a statement of the run; absence of n-specific analysis and of 'scalar' recorded in remark_readings"),
  A(5,'T','N','no computation, no source in docs/','U',contra=''),
  X('W','U','"step3": "gamma(F1, F2) evaluates to -delta_f(F1, F2) for this unique mapping."','docs/issues/verification_artifacts.json:20','','O','prose string in JSON; no code computes gamma (scratch/solve.py is a stub; stage-1 computation field)'),
 ])
S['thm01-R-gemini31p-b05-C']=dict(
 remark="single reading: constants (K) dropped ('Modulo constants', docs/issues/mathematical_proof.md:7), gb not stated odd/even, kappa sign not stated; headline 'trivial iff gb=0' (nullspace dimension 4/8/12).",
 tags=[
  A(0,'W','O','docs/math/structure_constants.json (146 bytes, only basis); export.py:4-6 (pass)'),
  A(1,'W','O','algebra.py:132-170 (hand-written gamma case table); solver.py, solver_final.py, scratch_verify.py produce no output'),
  A(2,'W','L','run.json (run id thm01-R-gemini31p-b05-C)'),
  DR("notes: compiled __pycache__/algebra.cpython-314.pyc committed","fact about files, not a statement of the run"),
 ])
S['thm01-R-gemini31p-b07-C']=dict(
 remark="single reading: kappa odd and super-commuting (a k = -k a, solve.py:14-15), K dropped ('up to scalar' handled by matching basis coefficients only); headline 'trivial iff gb=0' (n=1: nullspace dimension 0).",
 tags=[
  A(0,'W','O','solve.py:197-201; rerun printed 14 WARNING lines (stage-1 rerun field)'),
  A(1,'T','A','agent computation b07_31p_rank/solve_with_rank.py (Worker code patched to print ranks): f columns rank 32, all 36 columns rank 36; reference rank A n=1 = 28, [A|G] = 28 for kappa super and K dropped (extract_spec.md); not validated against independent_triviality4.py'),
  A(2,'T','O','solve.py has no loop over n; docs/issues/issue_open.md Requirements 1 asks n=1,2,3','U',contra='',loc='docs/issues/mathematical_proof.md:29'),
  DR("notes: uncommitted debug.py, debug2.py, __pycache__; 4 denied commands","session facts, not statements of the run"),
 ])
S['thm01-R-gemini31p-b09-C']=dict(
 remark="two readings of 'scalar' in the same file: (a) 'up to scalar' = proportional to delta f, gamma = c*delta f (docs/issues/mathematical_proof.md:8); (b) constants are excluded from g and f(X) cannot contain a scalar component (:20, :33), which is what produces gb=0 (K kept as obstruction). Headline: (b), 'trivial iff gb=0'.",
 tags=[
  A(0,'T','S','docs/issues/mathematical_proof.md:8 vs :33-37'),
  A(1,'T','N','no code computes these; no derivation in the file','U',contra=''),
  A(2,'W','O','no code in the commit; scratch/calc.py was denied (run.json)','U',contra='',loc='final_reflection_template.md:19'),
  A(3,'T','O','no computation of any n in the commit (issue_open.md asks n=1,2,3)','U',contra=''),
  X('W','U','"is_trivial": false','docs/issues/triviality_artifact.json','','O','literal boolean in a prose/formula JSON; no code computes it (stage-1 computation field)'),
  DR("notes: reflection written into template files; cp denied","session fact, not a statement of the run"),
 ])
S['thm01-R-gemini31p-b11-C']=dict(
 remark="single reading (K handling unclear): kappa odd with sign from passing fermions in code (solver.py:75-78), pure scalar terms 'factored out' (docs/issues/mathematical_proof.md:20) while H_{n+1} carries a constant; headline 'trivial iff gb=0' (4n conditions).",
 tags=[
  A(0,'W','O','turn3.jsonl.gz tool output / rerun_n3_stdout.txt: M shape (13976, 528); stage-1 rerun field'),
  A(1,'W','O','solve_cohomology.py:153-154 (n=1 only); solver.py main prints one bracket; run_n.py uncommitted (run.json)'),
  A(2,'W','O','extract.py:46 (scalar_remnant = 0 never used), :35-36 (silent skip)'),
  DR("notes: uncommitted __pycache__, run_n.py, test.py; 3 denied commands incl. generate_json.py","session facts, not statements of the run; the n=2,3 dependence on uncommitted run_n.py is carried by argument_issues[1]"),
 ])
S['thm01-R-gemini38f-b01-C']=dict(
 remark="single reading: gb odd (parity-1, :12), kappa odd, K dropped ('modulo the central scalars C + C kappa', :94); headline 'trivial iff gb=0'.",
 tags=[
  A(0,'T','S','docs/issues/mathematical_proof.md:12 vs :66-68; code cn1_algebra.py:13 commuting symbols'),
  A(1,'T','S','docs/issues/mathematical_proof.md:56-59 (basis lists H_1 with b_1 only); verify_minimal.py:98 (n=1, Y=H_1)'),
  A(2,'T','D','no source in docs/math (grep derivation: 0 hits); only ker M = 4n computed','U',contra=''),
  X('W','U','"triviality_conclusion": "Trivial if and only if gb = 0 (unconditionally non-trivial for any non-zero gb)"','verification/export_artifacts.py:148','','O','literal string in code (stage-1 computation field), written into artifacts_n{1,2,3}.json'),
 ])
S['thm01-R-gemini38f-b04-C']=dict(
 remark="single reading: gb parity 1 (:13), kappa odd, K dropped (central scalars projected out); headline 'trivial iff gb=0'.",
 tags=[
  A(0,'T','S','docs/issues/mathematical_proof.md:13 vs :96-99; code verify_all_n.py:46-47 commuting symbols'),
  A(1,'T','O','scripts/export_detailed_data.py exports n=1 obstruction equations only; H_1, H_2 definitions at :168 differ from docs/math/Cn1_definition.md H_k','U',contra=''),
  A(2,'T','D','no source in docs/math (grep derivation: 0 hits); only dim ker = 4n computed','U',contra=''),
  A(3,'W','O','scripts/solve_n1.py:234 prints 111 (rerun); verify_all_n.py gives 112'),
  X('W','U','"(delta f)(H1, H2) at F_mm = -phi_H1_F_mm - 2*phi_H2_F_mm = -gb_pp"','scripts/export_detailed_data.py:38-88','','O','literal strings in obstructions dictionary and :96 theorem (stage-1 computation field); not computed'),
 ])
S['thm01-R-gemini38f-b05-C']=dict(
 remark="single reading: gb parity 1 (:12), kappa odd and super-commuting (a_1^+ kappa = -kappa a_1^+, :146), K dropped (scalar parts discarded); headline 'all gb trivial' (explicit f, rank A = 28 = rank [A|G] at n=1).",
 tags=[
  A(0,'T','O','data/verification_artifacts_cn1.json num_nonzero_structure_constants 40/198/528'),
  A(1,'T','S','docs/issues/mathematical_proof.md:12 vs :69; :106 v^sigma'),
  A(2,'T','S','docs/issues/mathematical_proof.md:93 vs :89-90; verify_shift.py:296, export_artifacts.py discard scalar parts'),
  A(3,'W','O','scripts/test_jacobi.py (final line solve_Cn1(1), n=1 only); no committed script runs Jacobi for n=2,3 (grep jacobi in scripts/: only test_jacobi.py)','U',contra=''),
  DROP(4,"re-checked in the run copy: scripts/export_artifacts.py:395-410 checks gamma = -delta(f) on all pairs for n=1,2,3 and the rerun printed 'n=1: Checked 64 ... n=2 361 ... n=3 1156'; the statement is supported by export_artifacts.py, not a disagreement"),
  X('W','U','"theorem" string in data/verification_artifacts_cn1.json','scripts/export_artifacts.py (generate_json_artifacts)','','O','literal string written by the script (stage-1 computation field)'),
 ])
S['thm01-R-gemini38f-b07-C']=dict(
 remark="single reading: gb parity not stated (Omega_1 odd form), kappa odd (sign handling not stated), K dropped (central scalar terms discarded; general_solver.py:215); headline 'all gb trivial'.",
 tags=[
  A(0,'T','O','general_solver.py:273-277 (main n=1,2 only); grep 516 in scripts/ and artifacts/: no hit; rank n=1,2 = 28/168 equal reference','U',contra=''),
  A(1,'W','S','docs/issues/mathematical_proof.md:181-183 (totals 256, 2888, 13872)'),
  A(2,'T','N','no source in docs/math, not computed','U',contra=''),
  A(3,'T','N','relation of T-hat to the explicit f of :149-160 not stated in the file; no derivation','U',contra=''),
 ])
S['thm01-R-gemini38f-b12-C']=dict(
 remark="single reading: kappa odd (sign rules not examined), K dropped (quotient by central scalars, :80-94); headline 'trivial iff gb=0' (rank M_phi 28/168/516 vs M_all 32/176/528).",
 tags=[
  A(0,'T','A','agent computation work_bC_gemini38f_31p/det_formula.py; stated values equal scripts/test_quad_iso.py output (1/4, -1/16, 1/64)'),
  A(1,'W','O','scripts/verify_reproducibility.py:5-9 (loads JSON, no recomputation)'),
  A(2,'T','D','no source in docs/math (grep derivation: 0 hits); only dim ker = 4n computed','U',contra=''),
 ])
