import json,sys
g,a,b=sys.argv[1],int(sys.argv[2]),int(sys.argv[3])
prev=None
for i,l in enumerate(open('facts/%s.jsonl'%g)):
    o=json.loads(l)
    show=a<=i<b
    if show:
        print('=====',i,o['run'],o.get('commit_checked'))
        for k,v in o.items():
            if k in('run','commit_checked','scope','test_range','stated_conclusion','changes_since_first'): continue
            if prev and prev['run']==o['run'] and prev.get(k)==v and k!='notes':
                print('##',k,': SAME AS PREVIOUS'); continue
            if k=='argument_issues':
                for j,x in enumerate(v): print('## AI',j,json.dumps(x,ensure_ascii=False))
            else: print('##',k,':',json.dumps(v,ensure_ascii=False))
        if 'changes_since_first' in o: print('## changes_since_first:',o['changes_since_first'])
    prev=o
