import json,re,os
REV='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/judging/'
LOCRE=re.compile(r'[\w./\-]+\.(?:md|py|json|jsonl|gz|txt|tsv|csv):\d+(?:-\d+)?')
EV={'V':'validated_reference','O':'run_own_code_or_data','D':'definition_docs','S':'own_other_statement','L':'logs','A':'agent_unvalidated','N':'not_checked'}
def A(i,cls,ev,detail,kind='C',loc=None,contra=None,quote=None):
    return dict(i=i,cls=cls,ev=ev,detail=detail,kind=kind,loc=loc,contra=contra,quote=quote)
def X(cls,kind,quote,loc,contra,ev,detail):
    return dict(i=None,cls=cls,ev=ev,detail=detail,kind=kind,loc=loc,contra=contra,quote=quote)
def DROP(i,reason): return dict(i=i,drop=reason)
def DR(source,reason): return dict(i=None,drop=reason,source=source)
def item(q,loc,kind,contra,ev,detail):
    return {"quote":q,"loc":loc,"kind":'contradiction' if kind=='C' else 'unsupported',"contradicts":contra if kind=='C' else "","evidence":EV[ev],"evidence_detail":detail}
def build(group,specs):
    """specs: run -> dict(remark=str, tags=[...], final_extra=[...]) or per 'run|first' keys"""
    out=[]
    for l in open(REV+'facts/%s.jsonl'%group):
        o=json.loads(l)
        run=o['run']
        if o.get('status') and o.get('status')!='completed':
            out.append({"run":run,"commit_checked":None,"status":o['status'],"remark_readings":"not applicable (status %s; no deliverable to sort)"%o['status'],"theory_items":[],"work_items":[],"dropped":[]}); continue
        which='first' if o['commit_checked'].startswith('first') else 'final'
        sp=specs.get(run+'|'+which) or specs[run]
        ais=o.get('argument_issues',[])
        T=[];W=[];D=[]
        used=set()
        for t in sp['tags']:
            if t['i'] is None and 'drop' in t:
                D.append({"source":t['source'],"reason":t['drop']}); continue
            if t['i'] is not None and 'drop' in t:
                used.add(t['i']); a=ais[t['i']]
                D.append({"source":"argument_issues[%d]: "%t['i']+(a.get('quote') or a.get('statement'))[:250],"reason":t['drop']}); continue
            if t['i'] is not None:
                if t['i']>=len(ais): raise Exception('bad idx %s %s %s'%(run,which,t['i']))
                used.add(t['i'])
                a=ais[t['i']]
                q=t['quote'] or a.get('quote') or a.get('statement')
                loc=t['loc']
                if not loc:
                    m=LOCRE.search(q); loc=m.group(0) if m else None
                if not loc: raise Exception('no loc %s %s'%(run,t['i']))
                contra=t['contra'] if t['contra'] is not None else a.get('contradicts','')
            else:
                q=t['quote'];loc=t['loc'];contra=t['contra']
            if 'drop' in t:
                D.append({"source":t.get('source') or ('argument_issues[%d]: '%t['i'])+(ais[t['i']].get('quote') or ais[t['i']].get('statement'))[:200],"reason":t['drop']}); continue
            it=item(q,loc,t['kind'],contra,t['ev'],t['detail'])
            (T if t['cls']=='T' else W).append(it)
        for j in range(len(ais)):
            if j not in used: raise Exception('unplaced %s %s %d'%(run,which,j))
        out.append({"run":run,"commit_checked":o['commit_checked'],"remark_readings":sp['remark'],"theory_items":T,"work_items":W,"dropped":D})
    os.makedirs(REV+'facts2',exist_ok=True)
    with open(REV+'facts2/%s.jsonl'%group,'w') as f:
        for x in out: f.write(json.dumps(x,ensure_ascii=False)+'\n')
    return out
def summarize(out):
    from collections import Counter
    c=Counter()
    for o in out:
        for lst in('theory_items','work_items'):
            for it in o[lst]: c[(lst,it['kind'],it['evidence'])]+=1
        c[('dropped','',"")]+=len(o['dropped'])
    return c
