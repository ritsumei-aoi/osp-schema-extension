import json,glob,os
N4=os.path.dirname(os.path.abspath(__file__))
OUT='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/judging/n4/n4_interactive.jsonl'
def logs(r):
    d={}
    for f in glob.glob(f'{N4}/{r}.*.runlog.json'):
        l=json.load(open(f)); d[l['tag']]=l
    return d
def outs(r):
    o=[f'{N4}/{r}/data/{x}' for x in sorted(os.listdir(f'{N4}/{r}/data')) if '_4_' in x or x.startswith('C_4')] if os.path.isdir(f'{N4}/{r}/data') else []
    if os.path.isdir(f'{N4}/{r}/src/output'): o+= [f'{N4}/{r}/src/output/{x}' for x in sorted(os.listdir(f'{N4}/{r}/src/output')) if '_4_' in x]
    return o
def rec(run,cond,entry,method,edit,diff,order,**kw):
    L=logs(run) if order else {}
    cmds=[L[t]['cmd'] for t in order if t in L]
    secs=round(sum(L[t]['seconds'] for t in order if t in L),1)
    bad=[L[t] for t in order if t in L and L[t]['exit']!=0]
    exitc=(bad[-1]['exit'] if bad else (0 if order else None))
    to=any(L[t]['timed_out'] for t in order if t in L)
    err=''
    if bad: err=(bad[-1]['stderr'] or '')[-600:] or f"timeout 1800 killed the process (exit {bad[-1]['exit']}); no stdout/stderr output"
    d=dict(run=run,condition=cond,entry_points=entry,n4_method=method,edit_summary=edit,diff_file=(f'{N4}/{run}.diff' if diff else None),
      command=' ; '.join(cmds) if cmds else None,exit_code=exitc,seconds=secs if order else None,timed_out=to,error_tail=err,
      n4_outputs=(outs(run) if (order and run not in ('thm01-R-luna-r3-C',)) else []),n4_reported=kw.get('rep'),n4_vs_reference=kw.get('vs'),needs=kw.get('needs'),notes=kw.get('notes'))
    return d
REF='REFERENCE_N4: rank A=1168; rank [A|G]=1168 (super, K dropped) or 1184 (other three readings); rank G=16; #phi=1184.'
R=[]
common_dims='dims even 37 / odd 16 (53), 16 gb parameters.'
# luna-A
R.append(rec('thm01-R-luna-A','Copilot CLI A1',['src/C_generators.py','src/C_gamma_generator.py','src/C_coboundary_generator.py','src/C_evaluated_generator.py'],'unmodified','none; n is a positional CLI argument (python3 src/X.py 4)',False,['gen1','C_gamma_generator','C_coboundary_generator','C_evaluated_generator'],
 rep=['C_generators: data/C_4_structure.json','C_coboundary_generator: "data/C_4_coboundary.json: 1184 f parameters, 45788 nonzero coboundary records, 148877 graded anti-symmetry checks passed"','C_evaluated_generator: "data/C_4_evaluated.json: 16 parameters, 3608/3608 nonzero evaluated gamma records, 148877 cocycle triples passed"','structure JSON metadata: dimension even 37, odd 16, total 53'],
 vs='not comparable (the run has no committed rank/triviality script; no rank A / rank [A|G] / conclusion is produced for n=4). Counts match reference: 1184 phi, 16 gb, dims 37/16',
 needs=None,notes='Schema 1-4 JSON for n=4 produced unmodified; triviality ranks of issue I08 were a one-off not committed (per sheet). Coordinator: check gamma with gcheck.'))
# luna-C
R.append(rec('thm01-R-luna-C','Copilot CLI C',[],'no-code','none',False,[],rep=None,vs='not comparable',needs=None,notes='No .py/.sh files; only Markdown and docs/issues/cn1_triviality_artifacts.json (n_values [1,2,3] as data, a data inventory).'))
# luna-F
R.append(rec('thm01-R-luna-F','Copilot CLI F',['src/C_generators.py','src/C_gamma.py','src/C_coboundary.py','src/evaluate_C_structure.py'],'range-edit','four files: "for n in (1, 2, 3)" -> "for n in (4,)" (C_generators.py:514, C_gamma.py:480, C_coboundary.py:245, evaluate_C_structure.py:157)',True,['C_generators','C_gamma','C_coboundary','evaluate_C_structure'],
 rep=['Generated data/C_4_{structure,gamma,coboundary,evaluated_all_plus}.json; structure dims even 37, odd 16, total 53','No triviality/rank code in the repo (ranks were session one-offs)'],
 vs='not comparable (no rank/conclusion produced); dims match reference',needs=None,notes='Note: first invocation of each script (before the edit) regenerated n=1..3 files in the copy by mistake of my shell (sed -i usage error); it did not touch anything outside the copy. Coordinator: check gamma with gcheck.'))
# luna-G
R.append(rec('thm01-R-luna-G','Copilot CLI G',['src/C_generators.py','src/C_gamma.py','src/C_coboundary.py','src/C_evaluate.py','src/C_triviality.py'],'range-edit','C_triviality.py:136 "for n in (1, 2, 3)" -> "for n in (4,)"; the four generators take --n (unmodified)',True,['C_generators','C_gamma','C_coboundary','C_evaluate','triv'],
 rep=['"C_4: central obstruction rank 16/16; all-plus central mismatch=True; condition: all gb parameters are zero"','"example: [H_1, E_eps1_del1_pm] -> 1 κ K; no corresponding K target in Layer 4"'],
 vs='not comparable on ranks (script reports only the rank of the K-valued gamma matrix, 16 = rank G; no rank A or [A|G]); its stated condition "all gb parameters are zero" is the same as the reference outcome for the K-kept / non-supercommuting readings (1184)',needs=None,notes='Coordinator: check gamma with gcheck.'))
# luna-r2-C
R.append(rec('thm01-R-luna-r2-C','Copilot CLI C',[],'no-code','none',False,[],rep=None,vs='not comparable',needs=None,notes='No .py/.sh files; only Markdown and docs/issues/cn1_triviality_verification.json (data inventory with n=1..3).'))
# luna-r2-G
R.append(rec('thm01-R-luna-r2-G','Copilot CLI G',['src/C_generators.py','src/C_gamma.py','src/C_coboundary.py','src/C_evaluate.py','src/C_triviality.py'],'range-edit','"(1, 2, 3)" -> "(4,)" in the default of ranks (C_generators.py:381, C_gamma.py:242, C_coboundary.py:158, C_evaluate.py:78) and C_triviality.py:88 loop',True,['C_generators','C_gamma','C_coboundary','C_evaluate','C_triviality'],
 rep=['"C(5): 16 parameters; 1974 evaluated gamma terms; 154 K obstructions; all-plus trivial=False; conjectured triviality iff all gb=0"'],
 vs='not comparable on ranks (no rank A / [A|G] printed); conclusion "iff all gb=0" equals the reference outcome for the K-kept / non-supercommuting readings',needs=None,notes='Coordinator: check gamma with gcheck.'))
# luna-r3-C
R.append(rec('thm01-R-luna-r3-C','Copilot CLI C',['docs/issues/verify_cn1_artifacts.py'],'no-code','none (not edited); the script only asserts values read from docs/issues/cn1_triviality_artifacts.json, cases n=1,2,3',False,['lunar3C'],
 rep=['Ran unmodified: "validated_cases": [1, 2, 3]; "adjoint_valued_triviality_decidable_from_inputs": false','JSON data contain no case for n=4; script has no computation of ranks'],vs='not comparable',needs=None,notes='Validation of a JSON data file; no computation code. n4_outputs empty (nothing for n=4 produced).'))
# luna-r3-G
R.append(rec('thm01-R-luna-r3-G','Copilot CLI G',['src/C_generators.py','src/C_gamma_generator.py','src/C_coboundary_generator.py','src/evaluate_C_gamma.py','src/compare_C_triviality.py'],'unmodified','none; every script takes --ranks 4',False,['C_generators','C_gamma_generator','C_coboundary_generator','evaluate_C_gamma','compare'],
 rep=['"C_4: all_plus_trivial=False; trivial gb dimension=0/16"','16 lines "condition: gb_... = 0" (one per gb parameter)','"witness: (E_2del1_m, E_eps_del1_mp, K), combination=1, gamma(all +1)=1"'],
 vs='not comparable on ranks (no rank A / [A|G] printed); outcome "only gb=0 trivial (0/16 free)" equals the reference outcome for the K-kept / non-supercommuting readings (rank [A|G]=1184)',needs=None,notes='compare_C_triviality ran in 0.4 s. Coordinator: check gamma with gcheck.'))
# sonnet46-A
R.append(rec('thm01-R-sonnet46-A','Claude Code A2',['src/build_C_structure_constants.py','src/build_C_gamma.py','src/build_C_coboundary.py','src/build_C_evaluated.py'],'range-edit','"for n in [1, 2, 3]:" -> "for n in [4]:" in build_C_structure_constants.py:593, build_C_gamma.py:474, build_C_coboundary.py:216, build_C_evaluated.py:154',True,['structure','gamma','coboundary','evaluated'],
 rep=['structure: "Basis: 16 odd + 37 even = 53 total; Non-zero brackets: 542"','gamma: "gb parameters: 16; Non-zero γ records: 1979; Parity check: PASSED" (+ "WARNING: 155 K (scalar) terms found")','coboundary: "phi parameters: 1184; delta_f (X, Y, Z) entries: 22958"','evaluated: "Non-zero evaluated entries: 1979"'],
 vs='not comparable (no rank/triviality script in the repo; ranks of I08 have no committed code); counts match reference: 1184 phi, 16 gb, dims 37/16',needs=None,notes='build_C_structure_constants.py writes to src/output/ (not data/); I copied src/output/C_4_structure.json to data/C_4_structure.json by hand (run procedure, not a code edit) because the other scripts read data/C_n_structure.json. Coordinator: check gamma with gcheck.'))
# A1
R.append(rec('thm01-R-sonnet46-A1','Claude Code A1',['src/C_generators.py','src/C_gamma.py','src/C_coboundary.py','src/C_evaluated.py','src/C_triviality.py'],'range-edit','"for n in [1, 2, 3]:" -> "for n in [4]:" in C_generators.py:535, C_gamma.py:339, C_coboundary.py:224, C_evaluated.py:217, C_triviality.py:321',True,['C_generators','C_gamma','C_coboundary','C_evaluated','triv'],
 rep=['"K-entries in gamma: 308 ... Rank of K-constraint system: 16 / 16 ... All gb forced to zero by K-constraints: True"','"Total rows (X,Y,Z) triples: 45796; phi parameters: 1184; gb parameters: 16; Rank of M (coboundary): 1168"','"Additional gb constraints from non-K part: 52" (e.g. "(-4)gb_m_1_m = 0")','generators: "C(5): 1184 phi params, 45788 coboundary entries"'],
 vs='match for rank A (1168 = reference); K-constraint rank 16/16 and "all gb forced to zero" consistent with the reference K-kept outcome (1184); rank [A|G] not printed as such',needs=None,notes='C_triviality took 120.8 s. Coordinator: check gamma with gcheck.'))
# sonnet46-C
R.append(rec('thm01-R-sonnet46-C','Claude Code C',['scripts/verify_triviality.py'],'no-code','none (not run); script prints hard-coded n=1 tables and a theorem string; triviality_theorem(n) returns a text template for any n',False,[],
 rep=None,vs='not comparable',needs=None,notes='Not run. Script content: GENERATORS_N1, GAMMA_GB_N1, BRACKETS_N1, IMAGE_E_ED_* are literals for n=1; loop "for n in [1, 2, 3]" (line 136) prints "Theorem: gamma_gb trivial ... iff all gb = 0" from a fixed string; no linear algebra or rank computation. A [4] edit would only print that string.'))
# sonnet46-F
R.append(rec('thm01-R-sonnet46-F','Claude Code F',['src/C_generators.py','src/C_gamma.py','src/C_coboundary.py','src/C_evaluated.py','src/triviality_search.py'],'range-edit','"for n in [1, 2, 3]:" -> "for n in [4]:" in C_generators.py:446, C_gamma.py:318, C_coboundary.py:216, C_evaluated.py:91, triviality_search.py:212',True,['C_generators','C_gamma','C_coboundary','C_evaluated','triv'],
 rep=['table row: "n=4 phi 1184, rows 45794, rank 1168, sol_dim 16, consist NO, obstr 6"','"rank(A): 1168; solution_dim (null(A)): 16; Consistent?: NO; Inconsistent equations: 1470"','"STRUCTURAL OBSTRUCTION: 6 rows with gamma_eval ≠ 0 but no coboundary term" (gamma_eval(E_eps1_del1_pm,H_1;H_2..4) = 2)','"CONCLUSION: The deformation is NON-TRIVIAL for all n=1,2,3." (text is a fixed string; table has only n=4)'],
 vs='match for rank A (1168) and null dim 16; all-ones profile reported inconsistent (consistent with reference rank [A|G]=1184 readings; rank [A|G] not printed). Does not state the +/- per-direction result',needs=None,
 notes='triviality_search.main() contains an "n=1" detail section (compare_support(1), load(1)) that stays n=1 data after the range edit (prints n=1 counts 0/124/88); the CONCLUSION line text says n=1,2,3 literally. Not edited. Coordinator: check gamma with gcheck.'))
# sonnet46-G
R.append(rec('thm01-R-sonnet46-G','Claude Code G',['src/C_generators.py','src/C_gamma.py','src/C_coboundary.py','src/C_evaluate.py','src/C_triviality.py'],'range-edit','"for n in [1, 2, 3]:" -> "for n in [4]:" in C_generators.py, C_gamma.py, C_coboundary.py, C_evaluate.py, C_triviality.py (one line each)',True,['C_generators','C_gamma','C_coboundary','C_evaluate','triv'],
 rep=['"Concrete (gb=+1): trivial=False, rank_A=1168, triples=22962, phi_params=1184"','"Symbolic analysis: rank(coboundary A)=1168; Trivial gb directions (0): []; Non-trivial gb directions (16)"','"All gb directions trivial: False"'],
 vs='match for rank A (1168); per-direction result: 0 of 16 directions trivial (consistent with reference K-kept / non-supercommuting readings); rank [A|G] not printed',needs=None,notes='C_triviality took 976 s (machine under load from other agents); C_coboundary 67.8 s. It overwrote data/C_triviality_report.json in the copy (n=4 only). Coordinator: check gamma with gcheck.'))
# sonnet46-r2-C
R.append(rec('thm01-R-sonnet46-r2-C','Claude Code C',['docs/issues/verification_artifacts.py'],'needs-code-change','none (not run, not edited)',False,[],
 rep=None,vs='not comparable',needs='n=1-only literals: BASIS/GEN_NAMES/PARITY for 8 generators (verification_artifacts.py:~22-30), BRACKETS_C2 table for osp(2|2) (~:100-125), SAMPLE_GB_N1 (4 gb), compute_f_odd_generators / compute_gamma_gb_sample / verify_trivial_for_pair written for the four n=1 odd generators and two pairs only; no function builds structure constants for general n',notes='Not run. Script is a hand-written n=1 check; "n_verified": 1 in its JSON; conclusion printed states all gb trivial by an appeal to Whitehead lemma, not computed.'))
# sonnet46-r2-G
R.append(rec('thm01-R-sonnet46-r2-G','Claude Code G',['src/C_generators.py','src/C_gamma.py','src/C_coboundary.py','src/C_evaluate.py','src/C_triviality.py'],'range-edit','"for n in [1, 2, 3]:" -> "for n in [4]:" in C_generators.py:693, C_gamma.py:395, C_coboundary.py:196, C_evaluate.py:108, C_triviality.py:292',True,['C_generators','C_gamma','C_coboundary','C_evaluate','triv'],
 rep=['generators: "Basis: 37 even + 16 odd; Structure constants: 1084 non-zero entries"','gamma: "gb parameters: 16; gamma entries: 2804; Consistency with Schema 1: PASS"','coboundary: "phi parameters (f map): 1184; coboundary entries: 67450"','C_triviality.py: killed by timeout 1800 (no output)'],
 vs='not comparable (triviality step timed out; no numbers)',needs=None,notes='Schema 1-4 JSON for n=4 were produced (about 14 s total). C_triviality (n=4) did not finish in 1800 s while the machine was loaded by other agents; no retry. Coordinator: check gamma with gcheck.'))
# sonnet46-r3-C
R.append(rec('thm01-R-sonnet46-r3-C','Claude Code C',['verify_triviality.py'],'needs-code-change','none (not run, not edited)',False,[],
 rep=None,vs='not comparable',needs='n=1-only: DIM=8, EVEN/ODD/NAMES lists, hand-entered structure constants set_bracket(...) calls (verify_triviality.py ~:30-65), gt (gamma_tilde) entries for gb_{+,1,+} only (~:95-105), build_system_pair on pairs (F1,H2),(F1,H1); no generator of structure constants for general n',notes='Not run. numpy-based n=1 check printing an inconsistency; JSON record is "algebra": "C(2) = osp(2|2), n=1".'))
# sonnet46-r3-G
R.append(rec('thm01-R-sonnet46-r3-G','Claude Code G',['src/C_generators.py','src/C_gamma.py','src/C_coboundary.py','src/C_evaluated.py','src/C_triviality.py'],'range-edit','"for n in [1, 2, 3]:" -> "for n in [4]:" in C_generators.py:569, C_gamma.py:427, C_coboundary.py:224, C_evaluated.py:179, C_triviality.py:399',True,['C_generators','C_gamma','C_coboundary','C_evaluated','triv'],
 rep=['generators: "Basis: 37 even, 16 odd; Structure constants: 1084 non-zero entries"','gamma: "Non-zero gamma entries: 3624"','coboundary: "Non-zero coboundary entries: 45788; phi parameter count: 1184"','C_triviality.py: killed by timeout 1800 (no output)'],
 vs='not comparable (triviality step timed out; no numbers)',needs=None,notes='Schema 1-4 JSON for n=4 produced (under 1 s total). C_triviality (n=4) did not finish in 1800 s while the machine was loaded by other agents; no retry. Coordinator: check gamma with gcheck.'))
# sonnet46 A... A1 ordering handled; reorder to requested order
order="thm01-R-luna-A thm01-R-luna-C thm01-R-luna-F thm01-R-luna-G thm01-R-luna-r2-C thm01-R-luna-r2-G thm01-R-luna-r3-C thm01-R-luna-r3-G thm01-R-sonnet46-A thm01-R-sonnet46-A1 thm01-R-sonnet46-C thm01-R-sonnet46-F thm01-R-sonnet46-G thm01-R-sonnet46-r2-C thm01-R-sonnet46-r2-G thm01-R-sonnet46-r3-C thm01-R-sonnet46-r3-G".split()
by={x['run']:x for x in R}
assert len(by)==17 and set(by)==set(order),(set(order)-set(by))
with open(OUT,'w') as f:
    for r in order: f.write(json.dumps(by[r],ensure_ascii=False)+'\n')
for r in order: x=by[r]; print(r,x['n4_method'],x['exit_code'],x['seconds'],x['timed_out'])
