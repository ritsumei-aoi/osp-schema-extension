import sys,subprocess,time,json,os
run=sys.argv[1]; tag=sys.argv[2]; cmd=sys.argv[3:]
cwd=os.path.join(os.path.dirname(os.path.abspath(__file__)),run)
t=time.time(); to=False
try:
    p=subprocess.run(['timeout','1800']+cmd,cwd=cwd,capture_output=True,text=True)
    rc=p.returncode; out,err=p.stdout,p.stderr
except Exception as e:
    rc=-1;out='';err=str(e)
dt=time.time()-t
to = rc==124
log=dict(run=run,tag=tag,cmd=' '.join(cmd),exit=rc,seconds=round(dt,1),timed_out=to,stdout=out,stderr=err)
json.dump(log,open(os.path.join(os.path.dirname(cwd),f'{run}.{tag}.runlog.json'),'w'),indent=1)
print('exit',rc,'sec',round(dt,1)); print('--stdout tail'); print(out[-2500:]); print('--stderr tail'); print(err[-1500:])
