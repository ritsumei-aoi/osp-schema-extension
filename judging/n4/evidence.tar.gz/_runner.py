import subprocess, time, json, os, sys, difflib
N4=os.path.dirname(os.path.abspath(__file__))
J='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final'
jobs=[("01","run_full_verification.py"),("03","analyze_triviality.py"),("06","scripts/verify_osp.py"),("08","verification/verify_c_algebra.py"),("09","generate_artifacts.py"),("11","run_full_analysis.py"),("12","fast_verify.py"),("13","fast_verify.py"),("14","scripts/solve_triviality.py"),("15","solve_triviality.py")]
only=sys.argv[1:]
for b,f in jobs:
    if only and b not in only: continue
    run=f"thm01-R-gemini37f-b{b}-C"; d=f"{N4}/{run}"
    orig=open(f"{J}/{run}/{f}").read()
    new=orig.replace("for n in [1, 2, 3]:","for n in [4]:",1)
    assert new!=orig
    open(f"{d}/{f}","w").write(new)
    diff="".join(difflib.unified_diff(orig.splitlines(1),new.splitlines(1),f"a/{f}",f"b/{f}"))
    open(f"{N4}/{run}.diff","w").write(diff)
    before=set()
    for r,_,fs in os.walk(d):
        for x in fs: before.add(os.path.join(r,x))
    t=time.time(); to=False
    try:
        p=subprocess.run(["python3",f],cwd=d,capture_output=True,text=True,timeout=1800)
        out,err,rc=p.stdout,p.stderr,p.returncode
    except subprocess.TimeoutExpired as e:
        to=True;rc=None
        out=(e.stdout or b"").decode() if isinstance(e.stdout,bytes) else (e.stdout or "")
        err=(e.stderr or b"").decode() if isinstance(e.stderr,bytes) else (e.stderr or "")
    sec=time.time()-t
    after=set()
    for r,_,fs in os.walk(d):
        for x in fs: after.add(os.path.join(r,x))
    newf=sorted(os.path.relpath(x,d) for x in after-before if "__pycache__" not in x)
    open(f"{N4}/_logs/{run}.out","w").write(out); open(f"{N4}/_logs/{run}.err","w").write(err)
    json.dump(dict(run=run,cmd=f"python3 {f}",rc=rc,sec=round(sec,1),timed_out=to,newfiles=newf),open(f"{N4}/_logs/{run}.json","w"))
    print(run,rc,round(sec,1),to,flush=True)
