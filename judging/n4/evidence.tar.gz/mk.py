import json
N4="/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/n4work"
def d(r): return f"{N4}/{r}.diff"
def outs(r,extra=()):
    import os
    return [f"{N4}/{r}/data/{f}" for f in sorted(os.listdir(f"{N4}/{r}/data")) if "_4_" in f or f in extra]
P=["src/C_generators.py","src/C_gamma.py","src/C_evaluate(d).py","src/C_coboundary.py"]
rows=[]
def add(run,cond="G",**k):
    base=dict(run=run,condition=cond,timed_out=False,error_tail="",needs=None,notes="")
    base.update(k); base["n4_outputs"]=outs(run,k.pop("_extra",())) if False else outs(run)
    rows.append(base)
add("thm01-R-opus46-b06-G",entry_points=["src/C_generators.py","src/C_gamma.py","src/C_evaluated.py","src/C_coboundary.py","src/C_triviality.py","src/C_triviality_detailed.py"],
 n4_method="range-edit",edit_summary="`for n in [1, 2, 3]:` -> `for n in [4]:` in 6 loops (generators, gamma, evaluated, coboundary, triviality x2, triviality_detailed main)",diff_file=d("thm01-R-opus46-b06-G"),
 command="cd copy; python3 src/C_generators.py; src/C_gamma.py; src/C_evaluated.py; src/C_coboundary.py; src/C_triviality.py; src/C_triviality_detailed.py",exit_code=0,seconds=289,
 n4_reported=["C_triviality: 'Linear system: 23146 equations, 1184 unknowns ... RESULT: Deformation is NON-TRIVIAL (γ = δf has no solution)'","C_triviality_detailed: 'Matrix rank: 1168 ... Symbolic system: 23146 triples, 16 gb params, 1184 phi params ... Rank of combined matrix: 1184 ... Null space dimension: 16 ... Rank of gamma-only matrix: 16 ... Rank of coboundary-only matrix: 1168 (out of 1184 phi params)'","'CONCLUSION: The ONLY gb assignment making γ trivial is gb = 0'"],
 n4_vs_reference="match (rank A 1168, rank [A|G] 1184, rank G 16; only gb=0 trivial)",notes="exact Fraction elimination; C_triviality 54 s, detailed 234 s. Note #equations 23146 (agent's own enumeration).")
add("thm01-R-opus46-b08-G",entry_points=["src/C_generators.py","src/C_gamma.py","src/C_evaluate.py","src/C_coboundary.py","src/C_triviality.py","src/C_triviality_extended.py"],
 n4_method="range-edit",edit_summary="`for n in [1, 2, 3]:` -> `for n in [4]:` in 7 loops (generators, gamma, evaluate, coboundary, triviality x2, triviality_extended)",diff_file=d("thm01-R-opus46-b08-G"),
 command="python3 src/C_generators.py; C_gamma; C_evaluate; C_coboundary; C_triviality; C_triviality_extended",exit_code=0,seconds=118,
 n4_reported=["C_triviality: 'Linear system: 46592 equations, 1184 phi parameters ... Rank of A: 1184 ... Rank of [A|b]: 1185 ... Null space dimension: 0 ... NON-TRIVIAL for C(5) with all_plus profile'","C_triviality_extended: 'Rank of A: 1184'; all_plus, all_minus, alternating: NON-TRIVIAL (residual = 2.00e+00); (65536 sign profiles not enumerated: code branch `if n <= 2` else-branch used, printed text says 'n=3')"],
 n4_vs_reference="mismatch with numbers (rank A 1184, null dim 0 vs reference rank A 1168 / 16-dim kernel; rank [A|b] 1185 for all_plus; conclusion non-trivial agrees with 'only gb=0 trivial' direction)",notes="numpy float rank tol 1e-10; its coboundary matrix has 46592 rows (1263184 coboundary entries) vs 22-23k in other runs; same mismatch pattern not checked at n<=3 by me.")
add("thm01-R-opus46-b10-G",entry_points=["src/C_generators.py","src/C_gamma.py","src/C_evaluated.py","src/C_coboundary.py","src/C_triviality.py","src/check_K_obstruction.py"],
 n4_method="range-edit",edit_summary="`for n in [1, 2, 3]:` -> `[4]` (n loops) and `for n_val in [1, 2, 3]:` -> `[4]` in generators, gamma, evaluated, coboundary, triviality (2 loops), check_K_obstruction",diff_file=d("thm01-R-opus46-b10-G"),
 command="python3 src/C_generators.py; C_gamma; C_evaluated; C_coboundary; C_triviality; check_K_obstruction",exit_code=0,seconds=15,
 n4_reported=["'Dimensions: 1184 phi params, 22988 equations (XYZ triples); gb parameters: 16'","'Coboundary matrix rank: 1168 ... Kernel dimension: 16'","'NON-TRIVIAL: Inconsistent (rank 1168 vs augmented rank 1169)' (all-plus)","all 16 single gb: NON-TRIVIAL; 'The gamma columns are fully independent of the coboundary image. CONJECTURE: The deformation is NON-TRIVIAL for all non-zero gb.'","'General: never_trivial'"],
 n4_vs_reference="match (rank A 1168; conclusion only gb=0 trivial; combined rank [A|G] not printed)",notes="numpy float rank; evaluated file named C_4_evaluated_all_plus.json; check_K_obstruction ran (exit 0).")
add("thm01-R-opus46-b12-G",entry_points=["src/C_generators.py","src/C_gamma.py","src/C_evaluated.py","src/C_coboundary.py","src/C_triviality.py","src/C_triviality_numerical.py"],
 n4_method="range-edit",edit_summary="`for n in [1, 2, 3]:` -> `[4]` (10 loops incl. __main__ consistency checks) in generators, gamma, evaluated, coboundary, triviality, triviality_numerical",diff_file=d("thm01-R-opus46-b12-G"),
 command="python3 src/C_generators.py; C_gamma; C_evaluated; C_coboundary; C_triviality_numerical; C_triviality (sympy, 536 s)",exit_code=0,seconds=540,
 n4_reported=["C_triviality: 'Matrix A: 22834 x 1184 ... Rank of A: 1168 ... Rank of [A|b]: 1169 ... System is INCONSISTENT for generic gb ... Conditions on gb for triviality: 1 = 0 ... Always trivial: False'","C_triviality_numerical: 'rank(A) = 1168, rank([A|b]) = 1169 ... NOT TRIVIAL for gb=all_plus ... Sanity check (gb=0): rank(A)=1168, consistent=True'"],
 n4_vs_reference="match (rank A 1168; non-trivial; generic symbolic gb handled as one column so [A|b]=1169, not 1184)",notes="")
add("thm01-R-opus46-b13-G",entry_points=["src/C_generators.py","src/C_gamma.py","src/C_evaluated.py","src/C_coboundary.py","src/C_triviality.py"],
 n4_method="range-edit",edit_summary="`for n in [1, 2, 3]:` -> `[4]` in 5 mains",diff_file=d("thm01-R-opus46-b13-G"),
 command="python3 src/C_generators.py; C_gamma; C_evaluated; C_coboundary; C_triviality",exit_code=0,seconds=21,
 n4_reported=["'rank(A) = 1168, rank(A|B) = 1184'","'All-plus profile: rank(A|b_all) = 1169 -> UNSOLVABLE (non-trivial)'","'Summary: 0/16 gb directions are in col(A)'","'Trivial subspace dimension: 0 out of 16 gb parameters'; 'The deformation is NON-TRIVIAL in general.'"],
 n4_vs_reference="match (rank A 1168, rank [A|G] 1184, only gb=0 trivial)",notes="numpy float rank")
add("thm01-R-opus47-b02-G",entry_points=["src/C_generators.py","src/C_gamma.py","src/C_evaluate.py","src/C_coboundary.py","src/C_triviality.py"],
 n4_method="range-edit",edit_summary="`for n in (1, 2, 3):` -> `(4,)` in generators, gamma, evaluate, coboundary; `for n in (1, 2):` -> `(4,)` in C_triviality main",diff_file=d("thm01-R-opus47-b02-G"),
 command="python3 -m src.C_generators|C_gamma|C_evaluate|C_coboundary (modules need `-m`, plain `python3 src/X.py` gives ModuleNotFoundError: src); timeout 1800 python3 -m src.C_triviality",exit_code=124,seconds=1809,timed_out=True,
 error_tail="timeout 1800 killed python3 -m src.C_triviality (exit 124); no stdout was flushed (output empty); stderr empty",
 n4_reported=["C_coboundary: 'wrote .../data/C_4_coboundary.json (1184 phi, 45788 entries)' (Schema 1-4 for n=4 produced)","C_triviality (sympy exact rank): no result within 1800 s"],
 n4_vs_reference="not comparable (timed out)",notes="Schema 1-4 JSON for n=4 exist (C_4_structure/gamma/evaluated/coboundary).")
add("thm01-R-opus48-b02-G",entry_points=["src/C_generators.py","src/C_gamma.py","src/C_evaluate.py","src/C_coboundary.py","src/C_triviality.py","src/C_triviality_witness.py (n=1 only)"],
 n4_method="range-edit",edit_summary="`for n in (1, 2, 3):` -> `(4,)` in generators, gamma, evaluate, coboundary, triviality",diff_file=d("thm01-R-opus48-b02-G"),
 command="python3 src/C_generators.py; C_gamma; C_evaluate; C_coboundary; C_triviality (sympy exact, 631 s)",exit_code=0,seconds=638,
 n4_reported=["'equations=23122, phi=1200, gb=16'","'rank(M)=1184 (coboundary space), rank(B)=16, rank([M|B])=1200'","'nontrivial deformation classes = 16; dim(trivial locus in gb-space) = 0 / 16; ALWAYS TRIVIAL: False (independent conditions on gb: 16)'; conditions gb_*=0 for all 16"],
 n4_vs_reference="match in conclusion (only gb=0 trivial); numbers use 1200 unknowns (K as extra target: rank M 1184 = 1200-16, [M|B] = rank M + 16), equal to the reference variant with K kept",notes="C_triviality_witness only handles n=1 by design (not run).")
add("thm01-R-opus5-b02-G",entry_points=["src/C_generators.py","src/C_gamma.py","src/C_evaluate.py","src/C_coboundary.py","src/C_triviality.py"],
 n4_method="unmodified",edit_summary="no edit: each main takes n from argv (`python3 src/X.py 4`)",diff_file=None,
 command="python3 src/C_generators.py 4; C_gamma 4; C_evaluate 4; C_coboundary 4; C_triviality 4",exit_code=0,seconds=26,
 n4_reported=["'profile all_plus gamma=1568 delta_f=1568 identical=True -> TRIVIAL' (7 profiles all TRIVIAL)","'linear solve [f -> g+CK] unknowns=1200 rank=1184 soln-dim=16 consistent=True -> TRIVIAL for all gb'","'linear solve [f -> g] unknowns=1184 rank=1168 soln-dim=16 consistent=False obstructions=144 -> NON-TRIVIAL: obstruction in the K-component'","'K-obstruction pairs (restricted setting): 144'; 'SUMMARY: PASS'"],
 n4_vs_reference="match (rank 1168 for g-valued f, 1184 with K target; kernel 16; g+CK reading: all gb trivial, strict g reading: only gb=0)",notes="both readings reported, as for n<=3.")
add("thm01-R-opus55-b02-G",entry_points=["src/C_generators.py","src/C_gamma.py","src/C_evaluate.py","src/C_coboundary.py","src/C_triviality.py"],
 n4_method="range-edit",edit_summary="default argument `def main(ns=(1, 2, 3))` -> `(4,)` in 5 files (main() called without args)",diff_file=d("thm01-R-opus55-b02-G"),
 command="python3 src/C_generators.py; C_gamma; C_evaluate; C_coboundary; C_triviality",exit_code=0,seconds=99,
 n4_reported=["'[mod_K] eqs=22958 unknowns=1184 rank(delta)=1168 gb-condition rank=0 -> trivial gb subspace dim 16/16'","'[strict] eqs=23112 unknowns=1184 rank(delta)=1168 gb-condition rank=16 -> trivial gb subspace dim 0/16'","'[strict_cent] eqs=23112 unknowns=1200 rank(delta)=1184 gb-condition rank=0 -> trivial gb subspace dim 16/16'","closed form: mismatches incl. K = 0 ... mod K = 0"],
 n4_vs_reference="match (rank A 1168; K-dropped: all gb trivial; strict: only gb=0 trivial)",notes="")
add("thm01-R-opus55-b04-G",entry_points=["src/C_generators.py","src/C_gamma.py","src/C_evaluate.py","src/C_coboundary.py","src/C_triviality.py"],
 n4_method="range-edit",edit_summary="default argument `def main(ns=(1, 2, 3))` -> `(4,)` in generators, gamma, evaluate, coboundary; C_triviality takes n from argv (`4`) unmodified",diff_file=d("thm01-R-opus55-b04-G"),
 command="python3 src/C_generators.py; C_gamma; C_evaluate; C_coboundary; python3 src/C_triviality.py 4",exit_code=0,seconds=34,
 n4_reported=["'odd 1-cochains=1184, rank δ=1168, dim ker δ=16 (dim g_odd=16)'","'T1_g_valued: conditions on gb = none; trivial for all gb = True'","'T2_with_central_h: ... trivial for all gb = True'","'T3_strict_no_h: conditions on gb = [16 conditions gb=0]'; all_plus T3 trivial=False (154 inconsistent eqs)"],
 n4_vs_reference="match (rank A 1168; K-absorbing readings all gb trivial, strict only gb=0)",notes="")
add("thm01-R-opus55-b06-G",entry_points=["src/C_generators.py","src/C_gamma.py","src/C_evaluate.py","src/C_coboundary.py","src/C_triviality.py"],
 n4_method="unmodified",edit_summary="no edit: n from argv (`python3 src/X.py 4`)",diff_file=None,
 command="python3 src/C_generators.py 4; C_gamma 4; C_evaluate 4; C_coboundary 4; C_triviality 4",exit_code=0,seconds=67,
 n4_reported=["mode A: 'trivial(rank 1184/1200, null 16)' all profiles","mode B: 'NON-trivial(rank 1168/1184, null 16, bad rows 308)' (zero profile trivial)","mode C: 'trivial(rank 1168/1184, null 16)'","'symbolic mode A: conditions rank 0/16 -> trivial for ALL gb; mode B: conditions rank 16/16 -> trivial iff gb = 0; mode C: conditions rank 0/16 -> trivial for ALL gb'","closed-form f mismatches = 0"],
 n4_vs_reference="match (rank 1168 for g-valued; 1184 for g+K; K-dropped all gb trivial, strict only gb=0)",notes="")
add("thm01-R-opus55-b08-G",entry_points=["src/C_generators.py","src/C_gamma.py","src/C_evaluate.py","src/C_coboundary.py","src/C_triviality.py"],
 n4_method="unmodified",edit_summary="no edit: n from argv (`python3 src/X.py 4`)",diff_file=None,
 command="python3 src/C_generators.py 4; C_gamma 4; C_evaluate 4; C_coboundary 4; C_triviality 4",exit_code=0,seconds=208,
 n4_reported=["'dim ker(delta) on g-valued f = 16 (odd part dim 16), on g+K-valued f = 16'","strict-g all_plus: 'non-trivial (rank 1168/1169, res 1.0e+00)'; mod-K: 'TRIVIAL (rank 1168/1168)'; strict-gK: 'TRIVIAL (rank 1184/1184)'","'single gb parameters: {strict-g: 0, mod-K: 16, strict-gK: 16} solvable out of 16'","negative control all False; exact check 'failures = 0'"],
 n4_vs_reference="match (rank A 1168; [A|b] 1169 for a single profile; K-dropped all trivial, strict only gb=0)",notes="float SVD (residuals ~1e-14).")
add("thm01-R-opus55-b10-G",entry_points=["src/C_generators.py","src/C_gamma.py","src/C_evaluate.py","src/C_coboundary.py","src/C_triviality.py","src/C_triviality_report.py","src/C_cohomology.py"],
 n4_method="range-edit",edit_summary="default argument `def main(ns=(1, 2, 3))` -> `(4,)` in generators, gamma, evaluate, coboundary, triviality; `for n in (1, 2, 3):` -> `(4,)` in C_triviality_report (3 loops); C_cohomology run with argv `4` unmodified",diff_file=d("thm01-R-opus55-b10-G"),
 command="python3 src/C_generators.py; C_gamma; C_evaluate; C_coboundary; C_triviality; C_triviality_report; C_cohomology 4",exit_code=0,seconds=74,
 n4_reported=["'[mod_K] unknowns=1184 rank=1168 kernel=16 trivial=25/25'","'[exact] unknowns=1200 rank=1184 kernel=16 trivial=25/25'","'[strict] unknowns=1184 rank=1168 kernel=16 trivial=1/25 non-trivial=[all_plus ... unit:gb_*]'","'analytic candidate residuals: {0}'","C_cohomology: 'odd cochains=34736, rank(cocycle eqs)=33568, dim Z^2_odd=1168, dim B^2_odd=1168, dim H^2_odd=0'"],
 n4_vs_reference="match (rank A 1168; K-dropped/exact: all gb trivial; strict: only gb=0)",notes="C_triviality_report contains n=1-specific hard-coded sections (loads n=4 data for the first and last parts); its output was not used for conclusions.")
with open("<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/judging/n4/n4_bG_opus.jsonl","w") as f:
    for r in rows: f.write(json.dumps(r,ensure_ascii=False)+"\n")
print(len(rows))
