#!/bin/bash
# usage: run_seq.sh RUN file1 file2 ...   (edits "for n in [1, 2, 3]:" -> [4], runs in order)
N4=/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/n4work
J=/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final
R=$1; shift
cd $N4/$R
for f in "$@"; do sed -i '' -e 's/n_values=\[1, 2, 3\]/n_values=[4]/' -e 's/for n in range(1, 4):/for n in [4]:/' -e 's/for n in \[1, 2, 3\]:/for n in [4]:/' src/$f.py; done
(cd $N4; diff -ru $J/$R $R > $R.diff)
grep '^[+-]' $N4/$R.diff | grep -v '^+++\|^---'
for f in "$@"; do echo "### $f"; s=$(date +%s); timeout 1800 python3 src/$f.py > $N4/n4out/$R.$f.out 2> $N4/n4out/$R.$f.err; echo "exit $? $(( $(date +%s)-s ))s"; tail -3 $N4/n4out/$R.$f.err; done
