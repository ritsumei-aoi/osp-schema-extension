#!/bin/bash
# usage: run_args.sh RUN "script args" ...  (each in order, cwd = copy)
N4=/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/n4work
R=$1; shift
cd $N4/$R
for c in "$@"; do b=$(echo $c | tr ' /' '__'); echo "### python3 $c"; s=$(date +%s); timeout 1800 python3 $c > $N4/n4out/$R.$b.out 2> $N4/n4out/$R.$b.err; e=$?; echo "exit $e $(( $(date +%s)-s ))s"; tail -3 $N4/n4out/$R.$b.err; cat $N4/n4out/$R.$b.out | head -${HEADN:-15}; done
