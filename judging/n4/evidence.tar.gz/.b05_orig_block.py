# Verification artifacts for C(n+1) triviality analysis
# These dictionaries encode the triviality analysis results.

import json

def build_triviality_data(n):
    """
    Build verification data for C(n+1) = osp(2|2n).
    Returns a dict with structure constants and gb-triviality classification.
    """
    data = {
        "algebra": f"C({n+1}) = osp(2|{2*n})",
        "n": n,
        "dim_even": 2*n**2 + n + 1,
        "dim_odd": 4*n,
        "dim_total": 2*n**2 + 5*n + 1,
        "num_gb_params": 4*n,
        "gb_parameters": {},
    }
    
    for j in range(1, n+1):
        for sigma in ["+", "-"]:
            for s in ["+", "-"]:
                key = f"gb_{sigma}_{j}_{s}"
                # Bracket [b_j^s, a_1^sigma]_0 in original g:
                # Nonzero iff (sigma, s) are opposite signs
                original_bracket_nonzero = (sigma != s)
                
                data["gb_parameters"][key] = {
                    "sigma": sigma,
                    "j": j,
                    "s": s,
                    # Root of [b_j^s, a_1^sigma] in C(n+1):
                    "original_bracket_root": (
                        f"E_{{epsilon-delta_{j}}}" if (sigma == "+" and s == "-") else
                        f"E_{{delta_{j}-epsilon}}" if (sigma == "-" and s == "+") else
                        "0"
                    ),
                    "original_bracket_nonzero": original_bracket_nonzero,
                    # Adjoint triviality: always True (kappa acts trivially)
                    "adjoint_trivial_for_all_values": True,
                    # Strict triviality: only if bracket is nonzero (parameter can be matched by h)
                    # or parameter itself must be zero (if bracket is zero)
                    "strict_trivial_condition": (
                        "arbitrary" if original_bracket_nonzero else "must_be_zero"
                    ),
                }
    
    return data

# Generate for n = 1, 2, 3
results = {}
for n in [1, 2, 3]:
    results[f"C({n+1})"] = build_triviality_data(n)

# Summary
summary = {
    "theorem": "Triviality of C(n+1) Inhomogeneous Deformation",
    "adjoint_result": (
        "gamma_gb is trivial in the adjoint representation for ALL gb parameters, "
        "since kappa is central and acts as zero on g."
    ),
    "strict_result": (
        "gamma_gb is strictly trivial iff gb_{+,j,+} = gb_{-,j,-} = 0 for all j=1,...,n. "
        "The parameters gb_{+,j,-} and gb_{-,j,+} are unconstrained."
    ),
    "n1_strict_free_params": 2,
    "n1_strict_zero_params": 2,
    "general_strict_free_params": "2n",
    "general_strict_zero_params": "2n",
    "cases": results,
}

print(json.dumps(summary, indent=2))
