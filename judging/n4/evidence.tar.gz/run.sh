#!/bin/zsh
# usage: run.sh <run> <cmd...> ; logs to $N4/<run>.log
N4=/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/n4work
r=$1; shift
cd $N4/$r
s=$(date +%s)
timeout 1800 "$@" >> $N4/$r.out 2> $N4/$r.err
e=$?
echo "CMD: $* EXIT=$e SECONDS=$(( $(date +%s)-s ))" | tee -a $N4/$r.meta
