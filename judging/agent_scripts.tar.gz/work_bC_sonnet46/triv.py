# Agent computation: n=1 linear-algebra test delta f = gamma, using alg_data.pkl from run_alg.py (kappa-left convention)
import pickle, sympy as sp, itertools, random
from osc import NAMES, PAR, GB
SC,GAM=pickle.load(open('alg_data.pkl','rb'))
def sc(X,Y):  # bracket in g (+K central)
    if X=='K' or Y=='K': return {}
    return SC[(X,Y)]
def gam(X,Y,keepK):
    if X=='K' or Y=='K': return {}
    return {k:v for k,v in GAM[(X,Y)].items() if keepK or k!='K'}
def build(keepK, gbvals_list, domK=True):
    basis=NAMES+(['K'] if keepK else [])
    P=dict(PAR); P['K']=0
    # unknown f: phi[(target,source)] with parity(target)=parity(source)+1
    phis={}
    for s in (basis if domK else NAMES):
        for t in basis:
            if P[t]==(P[s]+1)%2: phis[(t,s)]=sp.Symbol(f'phi_{t}_{s}')
    def fimg(s): return {t:phis[(t,s)] for t in basis if (t,s) in phis}
    def brk_el(X,vec):  # [X, sum c_t t]
        out={}
        for t,c in vec.items():
            for k,v in sc(X,t).items(): out[k]=out.get(k,0)+c*v
        return out
    def brk_vec_el(vec,Y):
        out={}
        for t,c in vec.items():
            for k,v in sc(t,Y).items(): out[k]=out.get(k,0)+c*v
        return out
    rows=[]  # list of (pair, target component, linear form in phi)
    idx=sorted(phis.values(),key=str)
    for X in (basis if domK else NAMES):
        for Y in (basis if domK else NAMES):
            px,py=P[X],P[Y]
            e={}
            def acc(d,s):
                for k,v in d.items(): e[k]=e.get(k,0)+s*v
            acc(brk_el(X,fimg(Y)),(-1)**px)
            acc(brk_el(Y,fimg(X)),-(-1)**((px+1)*py))
            # [Y,f(X)] in formula is bracket of Y with f(X): sc(Y,t)
            br=sc(X,Y)
            for k,v in br.items():
                acc(fimg(k),-v)
            for k in basis:
                rows.append(((X,Y),k,sp.expand(e.get(k,0))))
    M=sp.Matrix([[r[2].coeff(p) for p in idx] for r in rows])
    gcols=[]
    for gv in gbvals_list:
        col=[]
        sub=dict(zip(GB,gv))
        for (X,Y),k,_ in rows:
            col.append(sp.sympify(gam(X,Y,keepK).get(k,0)).subs(sub))
        gcols.append(col)
    return M,sp.Matrix(gcols).T if gcols else None,rows,idx
if __name__=='__main__':
    M,Gm,rows,idx=build(True,[(1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1)],domK=False)
    print('K as target only (f defined on g): unknowns',M.shape[1],'rank A',M.rank(),'rank [A|G]',M.row_join(Gm).rank())
    for keepK in (False,True):
        dirs=[(1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1)]
        M,Gm,rows,idx=build(keepK,dirs)
        rA=M.rank()
        print('keepK',keepK,'unknowns',M.shape[1],'rows',M.shape[0],'rank A',rA,'rank [A|G(4 dirs)]',M.row_join(Gm).rank())
        for i,d in enumerate(dirs):
            print('  direction',d,'rank [A|g_i]',M.row_join(Gm[:,i]).rank())
        for gv in [(1,1,1,1),(1,-1,1,-1),(2,3,5,7)]:
            _,g1,_,_=build(keepK,[gv]); print('  profile',gv,'rank [A|g]',M.row_join(g1).rank())
