import gzip,json,sys
run=sys.argv[1]; t=sys.argv[2]
p=f"<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/runs/batch/{run}/{t}.jsonl.gz"
i=0
for line in gzip.open(p,'rt'):
    i+=1
    try:o=json.loads(line)
    except: continue
    ty=o.get('type')
    m=o.get('message',{})
    c=m.get('content') if isinstance(m,dict) else None
    if isinstance(c,str): print(i,ty,'TEXT',c[:300].replace('\n',' ')); continue
    for b in c or []:
        if b.get('type')=='tool_use':
            print(i,'TOOL',b['name'],json.dumps(b['input'])[:250])
        elif b.get('type')=='text':
            print(i,ty,'TEXT',b['text'][:200].replace('\n',' '))
        elif b.get('type')=='tool_result':
            cc=b.get('content'); s=json.dumps(cc)[:150]; print(i,'RESULT',s)
        elif b.get('type')=='thinking':
            print(i,'THINK',len(b.get('thinking','')))
