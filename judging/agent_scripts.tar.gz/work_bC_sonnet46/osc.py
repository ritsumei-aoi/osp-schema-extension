# Agent computation: n=1 oscillator algebra of C(2)=osp(2|2) with deformed relations b^s a^sigma = a^sigma b^s - gb[sigma,s]*kappa
# letters: A=a1+, a=a1-, B=b1+, b=b1-, k=kappa (odd central, kappa^2=0). Normal order: k < A < a < B < b
import sympy as sp
from fractions import Fraction
ORD={'k':0,'A':1,'a':2,'B':3,'b':4}
ODD={'k','A','a'}
GB=sp.symbols('gAp_bp gAp_bm gAm_bp gAm_bm')  # gb_{sigma,1,s}: (sigma,s)=(+,+),(+,-),(-,+),(-,-)
GBMAP={('A','B'):GB[0],('A','b'):GB[1],('a','B'):GB[2],('a','b'):GB[3]}
def add(d,w,c):
    if c==0: return
    d[w]=sp.expand(d.get(w,0)+c)
    if d[w]==0: del d[w]
def normal(word_dict):
    out={}; stack=list(word_dict.items())
    while stack:
        w,c=stack.pop()
        if c==0: continue
        done=True
        for i in range(len(w)-1):
            x,y=w[i],w[i+1]
            pre,post=w[:i],w[i+2:]
            if x=='k' and y=='k': done=False; break  # kappa^2=0
            if x==y and x in ('A','a'): done=False; break
            if ORD[x]>ORD[y]:
                done=False
                sign=-1 if (x in ODD and y in ODD) else 1
                if y=='k':
                    # moving k left past x: x k = (-1)^{p(x)} k x
                    s=-1 if x in ODD else 1
                    stack.append((pre+('k',x)+post,c*s)); 
                elif (x,y)==('a','A'):
                    stack.append((pre+('A','a')+post,-c)); stack.append((pre+post,c))
                elif (x,y)==('b','B'):
                    stack.append((pre+('B','b')+post,c)); stack.append((pre+post,c))
                else:
                    # a-type with b-type: x in {b,B}, y in {a,A}: x y = y x + [x,y]; [b^s,a^sig] = -gb kappa
                    assert x in ('B','b') and y in ('A','a'), (x,y)
                    stack.append((pre+(y,x)+post,c))
                    stack.append((pre+('k',)+post,-c*GBMAP[(y,x)]))
                break
            if x=='k' and y!='k': pass
        if done: add(out,w,c)
    return out
def mul(X,Y):
    r={}
    for w1,c1 in X.items():
        for w2,c2 in Y.items():
            add(r,w1+w2,c1*c2)
    return normal(r)
def lin(X,Y,a=1,b=1):
    r=dict(X)
    for w,c in Y.items(): add(r,w,c*b)
    return {w:sp.expand(c*a) for w,c in r.items()} if a!=1 else r
def par(X):
    ps={sum(1 for l in w if l in ODD)%2 for w in X}
    assert len(ps)<=1,X
    return ps.pop() if ps else 0
def scal(X,s): return {w:sp.expand(c*s) for w,c in X.items()}
def sbr(X,Y,px,py):
    XY=mul(X,Y); YX=mul(Y,X)
    return lin(XY,scal(YX,-(-1)**(px*py)))
R=sp.Rational
def W(*ws): return {w[0]:w[1] for w in ws}
G={ # basis of g, n=1
 'H1':{('A','a'):1,('B','b'):1},
 'H2':{('B','b'):-1,():R(-1,2)},
 'E2d':{('B','B'):R(1,2)},
 'Em2d':{('b','b'):R(1,2)},
 'Ap_bm':{('A','b'):1}, 'Am_bp':{('a','B'):1}, 'Ap_bp':{('A','B'):1}, 'Am_bm':{('a','b'):1},
}
PAR={'H1':0,'H2':0,'E2d':0,'Em2d':0,'Ap_bm':1,'Am_bp':1,'Ap_bp':1,'Am_bm':1}
NAMES=list(G)
# decomposition of an element (no kappa words) into basis + scalar 1
mono=[('A','a'),('B','b'),('B','B'),('b','b'),('A','b'),('a','B'),('A','B'),('a','b'),()]
def decompose(X):
    """X dict of words (no kappa). returns dict name->coef and 'K'->scalar"""
    cols=NAMES+['K']
    vecs={n:G[n] for n in NAMES}; vecs['K']={():1}
    syms=sp.symbols('x0:9')
    eqs=[]
    for m in mono:
        eqs.append(sum(syms[i]*vecs[cols[i]].get(m,0) for i in range(9))-X.get(m,0))
    extra=[w for w in X if w not in mono]
    assert not extra,extra
    sol=sp.solve(eqs,syms,dict=True)
    assert len(sol)==1
    s=sol[0]
    return {cols[i]:sp.simplify(s[syms[i]]) for i in range(9) if sp.simplify(s[syms[i]])!=0}
def split_kappa(X):
    k={w[1:]:c for w,c in X.items() if w and w[0]=='k'}
    nk={w:c for w,c in X.items() if not(w and w[0]=='k')}
    return nk,k
