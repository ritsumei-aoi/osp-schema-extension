import itertools, sympy as sp
from osc import *
els=dict(G)
for l in 'AaBb': els[l]={(l,):1}
bad=0;n=0
for x,y,z in itertools.product(els,repeat=3):
    L=mul(mul(els[x],els[y]),els[z]); Rr=mul(els[x],mul(els[y],els[z]))
    d=lin(L,scal(Rr,-1))
    d={w:c for w,c in d.items() if sp.expand(c)!=0}
    n+=1
    if d: bad+=1; print('nonassoc',x,y,z,d)
print('triples',n,'nonassociative',bad)
