import re,sys,subprocess,os,shutil,hashlib,json
JR='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot'
W='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_bC_sonnet46'
for r in sys.argv[1:]:
    run=f'thm01-R-sonnet46-{r}-C'
    dst=f'{W}/copies/{run}'
    if os.path.exists(dst): shutil.rmtree(dst)
    shutil.copytree(f'{JR}/final/{run}',dst)
    md=open(f'{dst}/docs/issues/mathematical_proof.md').read()
    lines=md.split('\n')
    blocks=[];cur=None
    for i,l in enumerate(lines,1):
        if l.startswith('```'):
            if cur is None: cur=(l[3:].strip(),i,[])
            else: blocks.append((cur[0],cur[1],i,cur[2])); cur=None
        elif cur is not None: cur[2].append(l)
    print('==',run,'blocks:',[(b[0],b[1],b[2]) for b in blocks])
    for n,(lang,s,e,body) in enumerate(blocks):
        if lang!='python': continue
        fn=f'{dst}/extracted_block_L{s}.py'
        open(fn,'w').write('\n'.join(body)+'\n')
        p=subprocess.run(['timeout','600','python3','-I',fn],cwd=dst,capture_output=True,text=True)
        print(f'-- block L{s}-{e} exit={p.returncode} stdout_len={len(p.stdout)} stderr={p.stderr[-300:]!r}')
        if p.stdout: print(p.stdout[:3000])
