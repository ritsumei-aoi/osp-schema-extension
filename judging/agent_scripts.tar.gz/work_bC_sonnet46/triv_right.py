# Agent computation: same as triv.py, but kappa-right convention ([X,Y]_gamma = [X,Y]_0 + gamma'(X,Y)*kappa): gamma' = (-1)^{p(gamma)} gamma
import pickle, sympy as sp
from osc import NAMES, PAR, GB
import triv
SC,GAM=pickle.load(open('alg_data.pkl','rb'))
flip={}
for (X,Y),v in GAM.items():
    s=-1 if (PAR[X]+PAR[Y]+1)%2==1 else 1
    flip[(X,Y)]={k:s*c for k,c in v.items()}
triv.GAM=flip
dirs=[(1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1)]
M,Gm,rows,idx=triv.build(False,dirs)
print('kappa-right, K dropped: rank A',M.rank(),'rank [A|G(4 dirs)]',M.row_join(Gm).rank())
for i,d in enumerate(dirs): print('  direction',d,'rank [A|g_i]',M.row_join(Gm[:,i]).rank())
for gv in [(1,1,1,1),(1,-1,1,-1),(2,3,5,7)]:
    _,g1,_,_=triv.build(False,[gv]); print('  profile',gv,'rank [A|g]',M.row_join(g1).rank())
