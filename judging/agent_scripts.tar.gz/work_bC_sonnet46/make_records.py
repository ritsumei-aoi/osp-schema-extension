import json,re,os,pickle
JR='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot'
WORK=os.path.dirname(os.path.abspath(__file__))
def lines_of(run,f):
    return open(f'{JR}/final/thm01-R-sonnet46-{run}-C/{f}',encoding='utf8').read().split('\n')
CACHE={}
FAILS=[]
def q(run,f,span,text):
    key=(run,f)
    if key not in CACHE: CACHE[key]=lines_of(run,f)
    L=CACHE[key]
    a,b=(span,span) if isinstance(span,int) else span
    blob=' '.join(L[a-1:b])
    for seg in text.split(' ... '):
        if seg not in blob:
            FAILS.append((run,f,span,seg)); 
            # try to locate
            for i,l in enumerate(L,1):
                if seg[:30] in l: FAILS.append(('   found at line',i)); break
    loc=f'{f}:{a}' if a==b else f'{f}:{a}-{b}'
    return f'"{text}" ({loc})'
PF='docs/issues/mathematical_proof.md'
AC=("agent computation (scripts in "+WORK+": osc.py, run_alg.py, assoc_check.py, triv.py, triv_right.py; n=1 only): oscillator algebra with the deformed relation "
    "b^s a^sigma = a^sigma b^s - gb_{sigma,s} kappa (gb an even scalar, kappa odd central, kappa^2=0; associativity checked on all 1728 triples of {8 generators, a+,a-,b+,b-}). "
    "Convention kappa-left, [X,Y]_gamma=[X,Y]_0+kappa*gamma(X,Y), as in docs/math/C_inhomogeneous_definition.md:30, K dropped: delta f = gamma unknowns 32, rank A=28 (reference 28 reproduced), "
    "rank [A|G] over the 4 gb directions jointly=28, each single direction 28, profiles (1,1,1,1),(1,-1,1,-1),(2,3,5,7) all 28 (solvable for every gb tested). "
    "Convention kappa-right ([X,Y]_gamma=[X,Y]_0+gamma'(X,Y)*kappa): rank A=28, joint rank [A|G]=32, each single direction 29, the three profiles 29 (not solvable). "
    "K-kept variants (K as target and/or domain) were computed but not reported: their setup differs from the reference pair 28->32 and is not comparable.")
GSUM="g_summary.csv has no rows for this run (inventory.csv: no gamma/realization files)."
ENV="python3 --version = Python 3.14.8; sympy.__version__ = 1.14.0 (sympy imported only by the b09 script)"
GAM=pickle.load(open(WORK+'/alg_data.pkl','rb'))[1]
recs=[]
# ---------------- b03 ----------------
def rec_b03(commit):
    R='b03'
    r=dict(run='thm01-R-sonnet46-b03-C',commit_checked=commit)
    r['stated_conclusion']=q(R,PF,252,'The inhomogeneous deformation $\\gamma_{gb}$ of $C(n+1) = \\mathfrak{osp}(2|2n)$ is trivial if and only if all $4n$ deformation parameters $\\mathrm{gb}_{\\sigma,j,s}$ vanish.')
    r['stated_conclusion_class']='trivial iff gb=0'
    r['scope']=('n=1,2,3: only parameter counts and restatement of the argument, no coboundary computed: '+q(R,PF,112,'Same argument applies. All 8 parameters must vanish.')+'; '+q(R,PF,118,'Same structural argument forces all 12 parameters to zero.')+
        '. General n: '+q(R,PF,120,'For $C(n+1)$, there are $4n$ deformation parameters, all of which must vanish for triviality.')+' and proof claim '+q(R,PF,237,'"proof_valid_for": "all n >= 1"'))
    r['declared_reading']=dict(
        gb_parity='not stated (gb is used as a scalar coefficient); the text only says '+q(R,PF,71,'Since $\\kappa$ is **odd** and central'),
        kappa_sign_handling='kappa odd central: '+q(R,PF,15,'$\\kappa$ is **odd central**')+'; no sign rule for moving kappa past odd elements is stated',
        K_treatment=q(R,PF,15,'where $K$ is even central')+'; K is not used afterwards (f: g -> g, K not in the listed basis). "Up to scalar" is read as: '+q(R,PF,81,'means equality modulo $Z(\\mathfrak{g}) = \\{0\\}$, i.e., exact equality'))
    r['test_range']='none (structural image argument stated for all gb at once; no rank test, no coboundary equation written out)'
    r['computation']=('no computation code. The only code is a markdown block of dictionaries ('+PF+':141-246). Values written directly: '+q(R,PF,210,'"non_trivial_for_gb_nonzero": True,')+'; '+q(R,PF,211,'"n_values_verified": [1, 2, 3],')+'; '+q(R,PF,243,'"all_must_vanish": True')+
        '. Placeholder: '+q(R,PF,180,'"n": None,  # set to 1, 2, or 3'))
    r['reported_numbers']=('dimensions and parameter counts only: '+q(R,PF,96,'Dimension: $(4|4)$')+', '+q(R,PF,107,'Dimension: $(11|8)$')+', '+q(R,PF,116,'Dimension: $(22|12)$')+'; no ranks. '+q(R,PF,101,'$f$ is determined by 16 parameters $\\phi_{ij}$ (4 even → 4 odd, 4 odd → 4 even)')+
        ' (agent computation, triv.py: the parity-reversing f on the 8-dimensional g of n=1 has 32 coefficients, K dropped). Reference ranks 28/28 or 32: not reported by the run.')
    r['rerun']=('extracted the python block '+PF+':141-246 to extracted_block_L141.py in a scratch copy of the run, `cd <copy>; timeout 600 python3 -I extracted_block_L141.py`: exit 0, empty stdout, no files produced; the block only defines dictionaries and computes nothing. '+ENV)
    r['argument_issues']=[
     dict(quote=q(R,PF,15,'where $K$ is even central and $\\kappa$ is **odd central**. Thus $L = \\mathfrak{g} \\oplus \\kappa\\mathfrak{g}$ as vector spaces.'),
          contradicts='same sentence: L is first described as g + CK + C kappa (spanned by g, K, kappa) and then as g + kappa g (contains kappa X for every X in g); the task document has both descriptions (docs/math/C_inhomogeneous_definition.md:5 and :32).'),
     dict(quote=q(R,PF,56,'We evaluate on the pair $(X, Y) = (b_j^s, a_1^\\sigma)$')+' and '+q(R,PF,65,'$f(a_1^\\sigma) \\in \\mathfrak{g}_{\\bar{0}}$'),
          contradicts='the run lists the basis of g without b_j^s, a_1^sigma: '+q(R,PF,98,'Even generators $\\mathfrak{g}_{\\bar{0}}$: $\\{H_1, H_2, E_{\\pm 2\\delta_1}\\}$ (dim 4).')+'; docs/math/Cn1_definition.md:44-71 gives generators of g as quadratic expressions in the oscillators. The pair on which the proof is evaluated consists of oscillators, not of listed elements of g.'),
     dict(quote=q(R,PF,71,'Since $\\kappa$ is **odd** and central, this lies in $\\mathfrak{g}_{\\bar{1}}^{\\mathrm{ext}} := \\kappa\\mathfrak{g}_{\\bar{0}} \\subset L$'),
          contradicts='docs/math/C_inhomogeneous_definition.md:36 "the deformation parameters $\\mathrm{gb}$ must have parity 1" (so gb*kappa is even); the run does not state the parity of gb, and treats -gb*kappa as odd.'),
     dict(quote=q(R,PF,101,'$f$ is determined by 16 parameters $\\phi_{ij}$ (4 even → 4 odd, 4 odd → 4 even)'),
          contradicts='agent computation (triv.py, n=1, K dropped): 32 coefficients (4x4 even->odd plus 4x4 odd->even) as the quoted decomposition itself indicates.'),
     dict(quote=q(R,PF,[90,92],'## 5. Explicit Verification for n = 1, 2, 3 ... For each $n$, we count the parameters and confirm the structure.'),
          contradicts='docs/issues/issue_open.md:23 "Generate structured data ... representing your structure constants and gamma structures": the data block '+PF+':141-246 contains root lists and parameter lists, no structure constants and no gamma values.'),
     dict(quote=q(R,PF,238,'"cohomological_class": "nonzero in H^1_odd(g, kappa*C) for any nonzero gb"')+' and '+q(R,PF,127,'$$[\\gamma_{gb}] \\in H^1_{\\mathrm{odd}}(\\mathfrak{g}, \\kappa\\mathbf{C}) \\otimes \\mathfrak{g}^*_{\\bar{1}} \\otimes \\mathfrak{g}_{\\bar{0}}$$'),
          contradicts='docs/math/C_inhomogeneous_definition.md:31 "$\\gamma: \\mathfrak{g} \\otimes \\mathfrak{g} \\to \\mathfrak{g}$ is a 2-cocycle" (a 2-cochain); no document defines the group the run names.'),
    ]
    return r
def final_extra(r,**kw):
    r=dict(r); r['commit_checked']=kw['commit']; return r
# ---------------- b05 ----------------
def rec_b05(commit):
    R='b05'
    r=dict(run='thm01-R-sonnet46-b05-C',commit_checked=commit)
    r['stated_conclusion']=q(R,PF,249,'the inhomogeneous deformation $\\gamma_{gb}$ of $C(n+1)$ is **always trivial**, for any values of the $4n$ parameters $\\mathrm{gb}_{\\sigma,j,s}$. The triviality witness is the zero map $f = 0$.')
    r['stated_conclusion_class']='all gb trivial'
    r['scope']=('the run states two notions. Adjoint triviality (its reading of the task): '+q(R,PF,127,'Under **adjoint triviality** (the condition stated in the problem): all $4n$ parameters are unconstrained.')+
        '. Strict triviality (f = kappa*h, f: g -> L, not the task\'s f: g -> g): '+q(R,PF,251,'exactly $2n$ of the $4n$ parameters must vanish, namely those corresponding to pairs $(\\sigma, s)$ of the same sign.')+
        ' n=1,2,3: listed by hand '+q(R,PF,[113,113],'**Strict triviality constraint**: 4 of the 8 parameters must vanish.')+'; general n stated as pattern '+q(R,PF,121,'### 5.4. General Pattern for C(n+1)'))
    r['declared_reading']=dict(
        gb_parity='not stated',
        kappa_sign_handling=q(R,PF,17,'$$L = \\mathfrak{g} \\oplus \\mathbf{C}\\kappa, \\quad p(\\kappa)=1, \\quad \\kappa \\text{ central in } L,$$')+'; '+q(R,PF,32,'Since $\\kappa$ is central in $L$, $[\\kappa, X] = 0$ for all $X \\in \\mathfrak{g} \\subset L$.')+'; no sign rule stated',
        K_treatment='not stated (K is not mentioned in the proof). "Up to scalar" is given a definition: '+q(R,PF,44,'Two deformations $\\gamma, \\gamma\'$ are **equivalent** if $\\gamma - \\gamma\'$ acts identically in the adjoint representation'))
    r['test_range']='none + per-direction (adjoint part: structural argument f=0; strict part: hand argument per (sigma,s) type at '+PF+':97-111, no code)'
    r['computation']=('no code computes gamma, delta f or ranks. Code block '+PF+':133-208 (build_triviality_data) prints a JSON built from rules written into the code: '+q(R,PF,160,'original_bracket_nonzero = (sigma != s)')+'; '+q(R,PF,174,'"adjoint_trivial_for_all_values": True,')+'; '+q(R,PF,200,'"n1_strict_free_params": 2,'))
    r['reported_numbers']='no ranks; counts '+q(R,PF,113,'4 of the 8 parameters must vanish')+', '+q(R,PF,119,'6 of the 12 parameters')+'; dimensions '+q(R,PF,85,'dim = 4|4')+'. Reference ranks not reported.'
    r['rerun']=('extracted '+PF+':133-208 to extracted_block_L133.py in a scratch copy, `timeout 600 python3 -I extracted_block_L133.py`: exit 0, stdout 8065 chars, no files produced. The seven keys of the "Expected output" block ('+PF+':211-220) equal the printed values (checked by script); the printed JSON has an extra key "cases" that the expected-output block omits. '+ENV)
    r['argument_issues']=[
     dict(quote=q(R,PF,18,'$\\gamma_{gb}: \\mathfrak{g} \\otimes \\mathfrak{g} \\to \\mathbf{C}\\kappa$'),
          contradicts='docs/math/C_inhomogeneous_definition.md:31-32 "$\\gamma: \\mathfrak{g} \\otimes \\mathfrak{g} \\to \\mathfrak{g}$ ... $L:=\\mathfrak{g}\\oplus \\kappa\\mathfrak{g}$" (run: '+q(R,PF,17,'$$L = \\mathfrak{g} \\oplus \\mathbf{C}\\kappa')+').'),
     dict(quote=q(R,PF,44,'$[\\gamma(X,Y), Z] = [\\gamma\'(X,Y), Z]$ for all $X, Y, Z \\in \\mathfrak{g}$'),
          contradicts='this definition of "up to scalar" does not appear in docs/math/C_coboundary_definition.md:23-25 ("$\\gamma(X, Y) = (\\delta f)(X, Y)$ for all $X, Y \\in \\mathfrak{g}$ up to scalar").'),
     dict(quote=q(R,PF,57,'we require a map $f: \\mathfrak{g} \\to L$'),
          contradicts='docs/issues/issue_open.md:17 and docs/math/C_coboundary_definition.md:7: f is an odd linear map $\\mathfrak{g} \\to \\mathfrak{g}$.'),
     dict(quote=q(R,PF,73,'[b_j^-, a_1^+]_0 \\propto E_{\\varepsilon - \\delta_j}'),
          contradicts='docs/math/Cn1_definition.md:45-46 gives relations only among the a\'s and among the b\'s, and :53 defines $E_{\\varepsilon - \\delta_1} = a_1^+ b_1^-$ as a product; b_j^-, a_1^+ are not elements of g (Cn1_definition.md:44-71).'),
     dict(quote=q(R,PF,75,'$b_j^+$ and $a_1^+$ have the same "creation" parity, so $[b_j^+, a_1^+]_0 = 0$'),
          contradicts='no such rule in docs/math/*; the zero/non-zero pattern (sigma != s) is then hard-coded at '+PF+':160.'),
     dict(quote=q(R,PF,66,'$$(\\delta(\\kappa h))(X,Y) = -\\kappa \\cdot h([X,Y]).$$')+' and '+q(R,PF,69,'$$-h([X,Y]) = \\mathrm{gb}_{\\sigma,j,s} \\quad \\text{when } (X,Y) = (b_j^s, a_1^\\sigma),$$'),
          contradicts='line 66 is stated for all X,Y while gamma_gb is nonzero only on the pairs (b_j^s,a_1^sigma) (:18-19); the condition at the other pairs is not discussed, yet :77-79 says h "is freely specifiable" (not checked whether the other pairs constrain h).'),
    ]
    return r
# ---------------- b06 ----------------
def rec_b06(commit):
    R='b06'
    r=dict(run='thm01-R-sonnet46-b06-C',commit_checked=commit)
    r['stated_conclusion']=q(R,PF,67,'The inhomogeneous deformation $\\gamma_{gb}$ of $C(n+1)$ is trivial — i.e., $\\gamma_{gb} = \\delta f$ in the adjoint representation up to scalar — **if and only if** all deformation parameters $\\mathrm{gb}_{\\sigma,j,s} = 0$.')
    r['stated_conclusion_class']='trivial iff gb=0'
    r['scope']=('n=1: one representative bracket, not a coboundary computation: '+q(R,PF,129,'the correction $\\gamma_{gb}(X,Y)$ acts as a scalar, confirming Step 1 of the proof.')+'; n=2,3: '+q(R,PF,141,'The same structural argument applies.')+' and '+q(R,PF,145,'Same conclusion.')+'. General n: Theorem at :67 for all n.')
    r['declared_reading']=dict(
        gb_parity='not stated',
        kappa_sign_handling=q(R,PF,15,'$K$ is even central and $\\kappa$ is odd central')+'; '+q(R,PF,45,'identification $\\kappa \\leftrightarrow \\mathrm{Id}$ (since $\\kappa$ acts as a scalar in the representation)'),
        K_treatment=q(R,PF,13,'$\\{a_1^-, a_1^+\\} = K$ (even central element)')+'; '+q(R,PF,246,'the adjoint representation identifies the even central element $K \\in A$ with the identity operator')+'; '+q(R,PF,252,'The "up to scalar" condition allows $\\gamma_{gb}(X,Y) - (\\delta f)(X,Y)$ to lie in $\\mathbf{C} \\cdot K$.'))
    r['test_range']='none'
    r['computation']=('no computation code; markdown block '+PF+':153-213 is a dictionary. Written directly: '+q(R,PF,164,'"is_simple": True,')+'; '+q(R,PF,165,'"center_dim": 0,')+'; '+q(R,PF,196,'"gamma_gb(X,Y) acts as scalar multiple of Id in adjoint rep (centrality)"')+'; JSON block :215-238 lists brackets such as '+q(R,PF,233,'"gamma_gb(E_{e-d1}, E_{-e+d1})": "-gb_{-,1,-} * (scalar in adjoint)"')+'.')
    r['reported_numbers']='dimensions only: '+q(R,PF,111,'dim $= 4|4$')+', '+q(R,PF,137,'dim $= 11|8$')+', '+q(R,PF,143,'dim $= 22|12$')+'; '+q(R,PF,131,'has 16 free parameters')+'; '+q(R,PF,220,'"dimension_of_H2_contribution": "4n (equals number of gb parameters)"')+'. No ranks (reference 28/28 or 32 not reported).'
    r['rerun']='extracted '+PF+':153-213 to extracted_block_L153.py in a scratch copy, `timeout 600 python3 -I extracted_block_L153.py`: exit 0, empty stdout, no files produced (dictionary only). '+ENV
    r['argument_issues']=[
     dict(quote=q(R,PF,13,'$\\{a_1^-, a_1^+\\} = K$ (even central element)')+' and '+q(R,PF,14,'$[b_k^-, b_l^+] = \\delta_{kl} K$'),
          contradicts='docs/math/Cn1_definition.md:45-46 "$\\{a_1^-, a_1^+\\} = 1$" and "$[b_k^-, b_l^+] = \\delta_{kl}$".'),
     dict(quote=q(R,PF,31,'$\\gamma_{gb}(X,Y)$ is a scalar multiple of $K$')+' vs '+q(R,PF,41,'$$\\gamma_{gb}(X,Y) \\in \\kappa \\cdot \\mathfrak{g}_{\\bar{0}} \\subset \\kappa L,$$')+' vs '+q(R,PF,127,'The correction term from $\\gamma_{gb}$ is proportional to $\\kappa \\cdot b_1^+$ and $\\kappa \\cdot a_1^+$, which are elements of $\\kappa V$, not $\\mathfrak{g}$.'),
          contradicts='three different descriptions of the values of gamma_gb inside the same document (c).'),
     dict(quote=q(R,PF,45,'$\\kappa$ acts as a scalar in the representation'),
          contradicts='docs/math/C_inhomogeneous_definition.md:32 "where the central element $\\kappa$ acts trivial"; and run :129 "identifying $K = \\mathrm{Id}$" / :246 identifies K, not kappa, with Id; docs :5 "K and kappa are even/odd central elements".'),
     dict(quote=q(R,PF,133,'$$(\\delta f)(X,Y) = -[X,f(Y)] + [Y,f(X)] - f([X,Y])$$'),
          contradicts='docs/math/C_coboundary_definition.md:17 (and run :53) with p(X)=p(Y)=1 gives exponent (p(X)+1)p(Y)=2, i.e. the second term enters as "-[Y,f(X)]", not "+[Y,f(X)]".'),
     dict(quote=q(R,PF,131,'An odd map $f: \\mathfrak{g} \\to \\mathfrak{g}$ for $C(2)$ has 16 free parameters.'),
          contradicts='agent computation (triv.py, n=1, K dropped): 32 coefficients; the run lists 4|4 generators (:116-117), i.e. 4x4 even->odd plus 4x4 odd->even.'),
     dict(quote=q(R,PF,81,'Explicitly, the non-zero values occur when $X$ and $Y$ involve generators that couple via the deformed oscillator relations.'),
          contradicts='Step 1 (:77-79) asserts ad(gamma(X,Y)) = c(X,Y)*Id without giving any c(X,Y); no value is computed anywhere in the document or its code block (:233-234 give only symbolic "(scalar in adjoint)").'),
     dict(quote=q(R,PF,85,'the Lie superalgebra $\\mathfrak{g}$ is simple (Kac\'s classification; the $C(n+1)$ series consists of simple Lie superalgebras for $n \\geq 1$)'),
          contradicts='cited from literature that is not in the copy; final_reflection.md:43 "The reference to Kac\'s classification of simple Lie superalgebras is from training knowledge, not a file lookup."'),
    ]
    return r
# ---------------- b09 ----------------
def rec_b09(commit):
    R='b09'
    r=dict(run='thm01-R-sonnet46-b09-C',commit_checked=commit)
    r['stated_conclusion']=q(R,PF,11,'The inhomogeneous deformation $\\gamma_{gb}$ of $C(n+1) = \\mathfrak{osp}(2|2n)$ is trivial — i.e., equals a coboundary $\\delta f$ for some odd linear map $f: \\mathfrak{g} \\to \\mathfrak{g}$ — if and only if all deformation parameters vanish:')
    r['stated_conclusion_class']='trivial iff gb=0'
    r['scope']=('n=1 only, one parameter explicit: '+q(R,PF,96,'### 2.4 Explicit Values for n=1, only $\\mathrm{gb}_{+,1,-} \\equiv \\mathrm{gb} \\neq 0$')+'; other three parameters: '+q(R,PF,218,'Analogous arguments apply by symmetry:')+'; n=2,3: no computation (only dimensions, :364-366); general n: '+q(R,PF,228,'the constraints for different indices $j$ decouple (generators with different $j$ do not mix in the relevant bracket calculations)'))
    r['declared_reading']=dict(
        gb_parity='not stated; gamma is called odd: '+q(R,PF,54,'$\\gamma_{gb}$ is an odd cochain: $p(\\gamma_{gb}(X,Y)) = p(X)+p(Y)+1$'),
        kappa_sign_handling=q(R,PF,24,'$\\kappa$ odd central (parity $p(\\kappa) = 1$)')+'; '+q(R,PF,52,'$$[X,Y]_\\gamma = [X,Y]_0 + \\kappa\\cdot\\gamma_{gb}(X,Y), \\quad X,Y \\in \\mathfrak{g}.$$'),
        K_treatment='K even central ('+q(R,PF,24,'with $K$ even central')+'); constants dropped "up to scalar": '+q(R,PF,60,'where equality holds in $\\mathfrak{g}$ up to scalar multiples of the identity')+'; '+q(R,PF,121,'(up to scalar)')+'; '+q(R,PF,236,'Pure multiples of $\\kappa$ (the central odd element) in the bracket correction. These vanish in the adjoint representation since $\\kappa$ acts as zero on $\\mathfrak{g}$.'))
    r['test_range']='per-direction (only gb_{+,1,-} at n=1, hand-derived equations (A),(C),(E); the other three directions "by symmetry"; no n=2,3)'
    r['computation']=('no code computes gamma, delta f or ranks. Blocks: '+PF+':252-287 (structure_constants_C2, typed table), :291-320 (gamma_gb_nonzero, typed table), :374-428 (sympy script). The script types the equations: '+q(R,PF,405,'eq_C = sp.Eq(c1 + d4, 0)')+' and '+q(R,PF,409,'eq_E = sp.Eq(c1 + d4, -2*gb)')+' and '+q(R,PF,418,'lhs_diff = (c1 + d4) - (c1 + d4)  # = 0')+'; it does not use the two tables.')
    r['reported_numbers']='no ranks. Dimensions '+q(R,PF,364,'"C(2)_n1": {"even": 4, "odd": 4, "total": 8, "gb_parameters": 4}')+'. Equations (A),(C),(E) in :149,:163,:178. Reference ranks (28/28 or 32) not reported. Agent computation, own gamma table (gb_{+,1,-}=1, skew-completed, other pairs 0) in delta f = gamma, K dropped (script compare.py b09): rank A=28, rank [A|g_table]=29.'
    r['rerun']=('extracted the three python blocks to extracted_block_L252.py, _L291.py, _L374.py in a scratch copy, `timeout 600 python3 -I <file>` each: all exit 0; L252 and L291 print nothing (dictionaries); L374 prints "Solution to {c1+d4=0} AND {c1+d4=-2*gb}: {c1: -d4, gb: 0}", "Contradiction equation: Eq(0, -2*gb)", "Forces gb = 0: [0]". The script\'s own comment '+q(R,PF,425,'# Solution to {c1+d4=0} AND {c1+d4=-2*gb}: {gb: 0}')+' differs from the printed "{c1: -d4, gb: 0}" on that line. No files produced. '+ENV)
    r['argument_issues']=[
     dict(quote=q(R,PF,263,'("H2", "E1"): {"E1": -1},                 # [H2, E1] = -E1')+' ; '+q(R,PF,267,'("E_2d", "E1"): {"E3": 1},               # [E_{2d}, E1] = E3'),
          contradicts='the run\'s own text '+q(R,PF,144,'Using the standard brackets $[E_1, H_1] = 0$, $[E_1, H_2] = -E_1$, $[E_1, E_{2\\delta_1}] = E_3$')+' (for even-odd pairs [X,Y] = -[Y,X], so table entries imply [E1,H2]=+E1 and [E1,E_{2d}]=-E3). Agent computation (osc.py, compare.py): the text brackets agree with the oscillator realization; 6 of the 26 table entries differ from it: (H2,E1), (H2,E2), (E_2d,E1), (E_2d,E4), (E_-2d,E2), (E_-2d,E3).'),
     dict(quote=q(R,PF,52,'$$[X,Y]_\\gamma = [X,Y]_0 + \\kappa\\cdot\\gamma_{gb}(X,Y), \\quad X,Y \\in \\mathfrak{g}.$$')+' vs '+q(R,PF,298,'("E1", "E1"): {"E1": -2},            # -2*gb*E1'),
          contradicts='agent computation (compare.py b09, kappa-left as in :52 and docs/math/C_inhomogeneous_definition.md:30): odd-odd entries are +2gb*E1, +gb*E3, +gb*E4, +gb*E2 for (E1,E1),(E1,E3),(E1,E4),(E3,E4); the run\'s signs agree with kappa placed on the right. Even-odd entries are unaffected. With kappa-left the full system is solvable (rank 28 = 28), with kappa-right it is not (28 vs 29 for this direction); see consistency_with_data.'),
     dict(quote=q(R,PF,124,'\\gamma_{gb}(H_1, E_1) = \\mathrm{gb}\\cdot(H_1+2H_2)')+' and '+q(R,PF,310,'("H1",  "E1"): {"H1": 1, "H2": 2}, # gb*(H1+2*H2)'),
          contradicts='agent computation (compare.py b09): gamma(H1,E1) = -gb*H1 (plus a K component, dropped) for gb=gb_{+,1,-}, in both kappa conventions; the entries (H1,E1),(E1,H1) are the only mismatches under kappa-right.'),
     dict(quote=q(R,PF,[292,293],'# gamma_gb(X, Y) = result in g, for non-zero entries only ... # (all other pairs evaluate to 0)'),
          contradicts='agent computation (compare.py b09): with only gb_{+,1,-} non-zero, gamma(H1,H2) and gamma(H1,E_{-2d}) (and the reversed pairs) are non-zero, e.g. kappa-left gamma(H1,E_{-2d}) = gb*E_{-eps-delta} (E4); these pairs are not in the table.'),
     dict(quote=q(R,PF,140,'using $[E_1, E_1] = 2E_1^2$ (for odd $E_1$, [X,X] = {X,X} need not vanish in characteristic zero)'),
          contradicts='same run: '+q(R,PF,276,'("E1", "E1"): {},                          # {E1,E1} = 0 in g (since (a+)^2=0)')+' (c).'),
     dict(quote=q(R,PF,228,'Since all four parameter types are independently obstructed, and the constraints for different indices $j$ decouple'),
          contradicts='only gb_{+,1,-} at n=1 is worked (:96-187); the other three types are "by symmetry" (:218) and n=2,3 are not computed; no table or code in the run covers them (not checked).'),
    ]
    return r
# ---------------- b10 ----------------
def rec_b10(commit):
    R='b10'
    r=dict(run='thm01-R-sonnet46-b10-C',commit_checked=commit)
    r['stated_conclusion']=q(R,PF,[15,17],'> **Theorem (Unconditional Triviality)**: For any values of the deformation parameters ... > gb_{σ,j,s}, the 2-cocycle γ_gb ∈ C²_odd(g, g) is a coboundary. Equivalently, > H²_odd(g, g) = 0 for g = C(n+1).')
    r['stated_conclusion_class']='all gb trivial'
    r['scope']=('n=1: partial explicit f, '+q(R,PF,[328,329],'This can be verified: using the brackets between Eᵢ, the above f gives δf = γ_gb on all pairs, confirming triviality.')+'; n=2,3: only formula-generated counts (:432-460); general n: '+q(R,PF,237,'3. **H²_odd(g, g) = 0**: By the Whitehead vanishing theorem applied to g = C(n+1)'))
    r['declared_reading']=dict(
        gb_parity='not stated; gamma called odd cochain: '+q(R,PF,57,'γ_gb is an **odd 2-cochain**'),
        kappa_sign_handling=q(R,PF,31,'- **Central elements**: K (even), κ (odd), both central in A')+'; '+q(R,PF,49,'$$[X, Y]_\\gamma = [X, Y]_0 + \\kappa \\cdot \\gamma_{\\mathrm{gb}}(X, Y).$$'),
        K_treatment=q(R,PF,[251,253],'terms involving the central element K (the bosonic central element of A). In U(A), K = 1 (identity), so such terms appear as scalars.')+'; '+q(R,PF,[257,258],'we work modulo the (trivial) center, i.e., we project all computations from U(A) to g.'))
    r['test_range']='joint (n=1, symbolic alpha,beta,gamma~,delta in a hand-derived f(H1), not computed or fully worked) + none (general n: cohomology-vanishing argument, no rank test)'
    r['computation']=('no code computes gamma, delta f or ranks. Blocks in '+PF+': :356-385 (generators_n1, structure_odd_odd_n1), :389-428 (gamma_gb_n1, f_map_n1: typed tables), :432-460 (triviality_statement). Values written directly: '+q(R,PF,447,'"H2_odd_gg": 0,            # vanishes by Whitehead theorem')+'; '+q(R,PF,450,'"f_exists": True,')+'; '+q(R,PF,452,'"f_freedom": 0,            # H1(g,g)=0, so f is unique up to coboundaries')+'. Self-flagged uncertainty in code: '+q(R,PF,377,'# {E_eps-d, E_-eps+d} = H1 (verify: H1+0*H2?)'))
    r['reported_numbers']=('no ranks. Rerun of :432-460 gives f_dimension 32, 176, 528 for n=1,2,3 (formula '+q(R,PF,451,'dim_g1 * dim_g0 + dim_g0 * dim_g1')+'). '+q(R,PF,303,'reduce to a 16×16 linear system')+'. Agent computation (compare.py b10): structure_odd_odd_n1 (6 entries) equals the oscillator-realization brackets (0 mismatches); own gamma table at (gb_{+,1,+},gb_{+,1,-},gb_{-,1,+},gb_{-,1,-})=(1,2,3,5) (skew-completed, other pairs 0): rank A=28, rank [A|g_table]=29. Reference ranks not reported by the run.')
    r['rerun']=('extracted the three python blocks to extracted_block_L356.py, _L389.py, _L432.py in a scratch copy, `timeout 600 python3 -I <file>` each: all exit 0; L356, L389 print nothing; L432 only defines results = {n: triviality_statement(n)}, no print statement; values inspected by importing it: f_dimension 32/176/528 and the hard-coded fields above. No files produced. '+ENV)
    r['argument_issues']=[
     dict(quote=q(R,PF,[328,329],'the above f gives δf = γ_gb on all pairs, confirming triviality.')+' ; '+q(R,PF,477,'demonstrated explicitly for n=1'),
          contradicts='agent computation (compare.py b10): with the run\'s f ('+PF+':416-427) and the run\'s gamma table (:394-413), delta f differs from the table on 48 of the 64 ordered pairs; at (H1,E1): delta f = {H1: -alpha, H2: -2alpha, E_{2d}: 2beta} vs table '+q(R,PF,403,'("H1","E1"): [("α", "H1"), ("2α", "H2"), ("−2β", "E_2d")]')+'. Also the run\'s own reflection final_reflection.md:30 "the explicit construction of f, which I only partially completed for n=1" and proof :303-304 "By the vanishing theorem, this system has a solution."'),
     dict(quote=q(R,PF,[95,96],'**Even–Even pairs**: γ_gb = 0 identically (no fermionic oscillators cross bosonic ones in purely even brackets).'),
          contradicts='agent computation (osc.py, n=1): gamma(H1,H2), gamma(H1,E_{2d}), gamma(H1,E_{-2d}) are non-zero (e.g. kappa-left gamma(H1,E_{2d}) = gb_{+,1,+}*E_{-eps+delta} - gb_{-,1,+}*E_{eps+delta}).'),
     dict(quote=q(R,PF,[394,413],'gamma_gb_n1 = {'),
          contradicts='agent computation (compare.py b10): the 14 listed entries: odd-odd entries have the opposite sign of the kappa-left convention that the run states at :49 (they agree with kappa-right); the 8 entries (H1,E_i),(H2,E_i) differ from the realization in both conventions, e.g. realization gamma(H1,E1) for E1=a+b+ is -alpha*H1 - 2beta*E_{2d} (+K component) vs table '+q(R,PF,403,'("H1","E1"): [("α", "H1"), ("2α", "H2"), ("−2β", "E_2d")]')+'; 26 ordered pairs with non-zero realization gamma are in the table neither as such nor as the reversed pair (includes diagonal pairs and pairs with E_{+-2d}).'),
     dict(quote=q(R,PF,[265,266],'(no residual scalar). So γ_gb takes values in g unambiguously.'),
          contradicts='agent computation (run_alg.py): the K (scalar) component of gamma(H1,E1), E1=a+b+, is -gb_{+,1,+} (kappa-left, nonzero); several other even-odd gamma entries have K components (alg_data.pkl).'),
     dict(quote=q(R,PF,[257,258],'we work modulo the (trivial) center, i.e., we project all computations from U(A) to g.')+' vs '+q(R,PF,[268,269],'The "up to scalar" in the problem statement refers to the fact that f is determined only up to elements of Z¹_odd(g, g)'),
          contradicts='two different meanings of "up to scalar" in the same section (c).'),
     dict(quote=q(R,PF,[186,188],'**Theorem (Fuks–Leites–Serganova)**: Let g be a finite-dimensional basic classical simple Lie superalgebra over ℂ, and let M be a finite-dimensional completely reducible g-module. Then H^k(g, M) = 0 for all k ≥ 1.'),
          contradicts='cited from literature not in the copy; run states '+q(R,PF,492,'Background theory (standard results, no external access required):')+' (logs: no web tool used). The run also says '+q(R,PF,452,'"f_freedom": 0,            # H1(g,g)=0, so f is unique up to coboundaries')+' vs '+q(R,PF,[270,271],'f is determined up to coboundaries δe for even e: g → g')+' (c).'),
    ]
    return r
GCOMMON=dict()
def finish(r,final):
    r['consistency_with_data']=(GSUM+' Stated class "'+r['stated_conclusion_class']+'". '+AC+' Comparison (facts): '+
        ('class "trivial iff gb=0" does not match the kappa-left result (solvable for all gb) and matches the kappa-right result (nonsolvable for every direction and profile).' if r['stated_conclusion_class']=='trivial iff gb=0'
         else 'class "all gb trivial" matches the kappa-left result (solvable for all gb) and does not match the kappa-right result.')+
        ' Declared K treatment: see declared_reading; conclusion is not derived from a K-dependent computation (no computation).')
    return r
def reflection_issues(run,items):
    return items
runs={}
for name,fn in [('b03',rec_b03),('b05',rec_b05),('b06',rec_b06),('b09',rec_b09),('b10',rec_b10)]:
    runs[name]=fn
out=[]
# reflection-related items (final only)
ref_issues={
 'b03':[dict(quote=q('b03','final_reflection.md',20,'Structured Python/JSON verification artifacts were included so the result is computationally checkable.'),contradicts='rerun: the artifacts are dictionaries that compute nothing (no output).'),
        dict(quote=q('b03','final_reflection.md',9,'1 (resume after output token limit hit mid-startup)')+' and '+q('b03','supplementary_metrics.md',10,'approximately 40,000–50,000 tokens consumed'),contradicts='turn1.jsonl.gz contains 3 user messages "Output token limit hit. Resume directly" (lines 722, 1452, 2160 of turn1.jsonl); run.json turn 1 usage output_tokens = 207470.')],
 'b05':[dict(quote=q('b05','supplementary_metrics.md',12,'**Files created**: 2 (`docs/issues/mathematical_proof.md`, `final_reflection.md`, `supplementary_metrics.md`)'),contradicts='the same line lists three files while stating 2; and supplementary_metrics.md:10 "2 Write" vs turn1 log: 1 Write call in turn 1.')],
 'b06':[dict(quote=q('b06','final_reflection.md',32,'The proof is logically complete but lacks a fully explicit bracket-by-bracket computation for $n=1$'),contradicts=q('b06',PF,109,'## 5. Verification for Small Cases')+' and '+q('b06',PF,129,'confirming Step 1 of the proof')+' (c).'),
        dict(quote=q('b06','final_reflection.md',44,'using only Read, Write, Bash, and Edit tools'),contradicts='supplementary_metrics.md:11 "Edit (×0)"; logs contain no Edit call.')],
 'b09':[dict(quote=q('b09','final_reflection.md',27,'I ensured accuracy by computing all Lie superalgebra brackets directly from the oscillator realization')+' and '+q('b09','final_reflection.md',78,'was reached by explicit algebraic computation'),
          contradicts='turn1/turn2 logs: tool calls are Read, Glob, Write and Bash (git, `git status`) only, no computation tool; and the structure-constant table at '+PF+':256-286 has 6 entries that differ from the oscillator realization (first issue above).')],
 'b10':[dict(quote=q('b10','final_reflection.md',19,'γ_gb(H₁, E₁) = α(H₁ + 2H₂) − 2β E_{2δ₁} ∈ g'),contradicts='agent computation (compare.py b10): realization gives -alpha*H1 - 2beta*E_{2d} plus a K component (see argument_issues).')],
}
notes_common="Group bC_sonnet46, batch condition C, one Worker session (turn1 proof, turn2 reflection); no g_summary rows; inventory.csv n*_structure/gamma/coboundary layers all 0 (no realization files). Scratch dir: "+WORK+"."
for name in ['b03','b05','b06','b09','b10']:
    fn=runs[name]
    inv={'b03':('c46af65','8af2c6c'),'b05':('692efa4','156900a'),'b06':('538abbc','301597f'),'b09':('d79f3a9','1ccffd8'),'b10':('1818ebc','b1b3783')}[name]
    first=finish(fn(f'first ({inv[0]})'),False)
    first['notes']=notes_common+' First commit: '+PF+(' and docs/issues/final_reflection.md' if name=='b03' else (' , docs/issues/final_reflection.md and docs/issues/supplementary_metrics.md' if name=='b09' else ''))+' (no root final_reflection.md / supplementary_metrics.md). Reflection-based checks are in the final object.'
    final=finish(fn(f'final ({inv[1]})'),True)
    final['argument_issues']=list(final['argument_issues'])+ref_issues[name]
    final['changes_since_first']=('files added under root: final_reflection.md, supplementary_metrics.md (diff -rq first vs final); '+PF+' and other data/code/proofs unchanged (identical); no data or code files in either commit (the verification artifacts are code blocks inside '+PF+').')
    final['notes']=notes_common+' Final commit adds the turn-2 reflection files. run.json: fixed_replies 0, uncommitted [], outside_refs [].'
    out+= [first,final]
b08=dict(run='thm01-R-sonnet46-b08-C',status='aborted',
  deliverables='run.json: status aborted, terminal_reason api_error, result "You\'ve hit your session limit · resets 11:20pm (Asia/Tokyo)"; commits: only the init commit e09166b; uncommitted: "?? docs/issues/mathematical_proof.md" (written by a Write call at turn1.jsonl.gz message index 2606 but not present in the copy $JROOT/final/thm01-R-sonnet46-b08-C, which contains only docs/ inputs, issue_open.md and the two templates); no final_reflection.md, no supplementary_metrics.md, no code or data files; turn 2 not run.')
out.append(b08)
for x in FAILS: print(x)
if FAILS: raise SystemExit(1)
path='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/judging/facts/bC_sonnet46.jsonl'
with open(path,'w',encoding='utf8') as f:
    for o in out: f.write(json.dumps(o,ensure_ascii=False)+'\n')
print('written',len(out),'records')
