# Agent computation: compare run tables (b09, b10) with osc.py-derived structure constants / gamma (n=1, K dropped)
import pickle, re, sympy as sp, itertools, runpy
from osc import NAMES, PAR, GB
from triv import build
SC,GAM=pickle.load(open('alg_data.pkl','rb'))
gA_pp,gA_pm,gAm_pp,gAm_mm=None,None,None,None
gAp_bp,gAp_bm,gAm_bp,gAm_bm=GB
def drop(d): return {k:sp.expand(v) for k,v in d.items() if k!='K' and sp.expand(v)!=0}
def pgam(X,Y): return (PAR[X]+PAR[Y]+1)%2
def gam(X,Y,conv):
    g=drop(GAM[(X,Y)])
    if conv=='right' and pgam(X,Y)==1: g={k:-v for k,v in g.items()}
    return g
def vec_eq(a,b): 
    keys=set(a)|set(b); return all(sp.expand(a.get(k,0)-b.get(k,0))==0 for k in keys)
def delta_f(f,X,Y):
    # f: dict source->{target:coef}
    e={}
    def acc(d,s):
        for k,v in d.items(): e[k]=e.get(k,0)+s*v
    px,py=PAR[X],PAR[Y]
    for t,c in f.get(Y,{}).items(): acc({k:c*v for k,v in SC[(X,t)].items()},(-1)**px)
    for t,c in f.get(X,{}).items(): acc({k:c*v for k,v in SC[(Y,t)].items()},-(-1)**((px+1)*py))
    for k,v in SC[(X,Y)].items():
        acc({t:v*c for t,c in f.get(k,{}).items()},-1)
    return drop(e)
def solvable(gtab):
    """gtab: dict (X,Y)->{target:coef(sympy in some symbol)}; K dropped, f unknown generic. returns (rankA, rank[A|g]) for generic symbol values substituted"""
    M,_,rows,idx=build(False,[])
    return M,rows
import sys
which=sys.argv[1]
if which=='b09':
    ns=runpy.run_path('copies/thm01-R-sonnet46-b09-C/extracted_block_L252.py')
    sc_tab=ns['structure_constants_C2']
    ns2=runpy.run_path('copies/thm01-R-sonnet46-b09-C/extracted_block_L291.py')
    gtab=ns2['gamma_gb_nonzero']
    L={'H1':'H1','H2':'H2','E_2d':'E2d','E_-2d':'Em2d','E1':'Ap_bm','E2':'Am_bp','E3':'Ap_bp','E4':'Am_bm'}
    print('== b09 structure constants table (L252-287) vs script SC')
    bad=0
    for (x,y),v in sc_tab.items():
        X,Y=L[x],L[y]; tv={L[k]:c for k,c in v.items()}
        if not vec_eq(tv,drop(SC[(X,Y)])):
            bad+=1; print('  MISMATCH',(x,y),'table',v,'script',dict(SC[(X,Y)]))
    print('  entries',len(sc_tab),'mismatches',bad)
    gb=sp.Symbol('gb'); sub={gAp_bm:gb,gAp_bp:0,gAm_bp:0,gAm_bm:0}
    for conv in ('left','right'):
        print('== b09 gamma table (L291-320) vs script gamma, only gb_{+,1,-}=gb, kappa-%s'%conv)
        bad=0; listed=set()
        for (x,y),v in gtab.items():
            X,Y=L[x],L[y]; listed.add((X,Y))
            tv={L[k]:c*gb for k,c in v.items()}
            sv={k:sp.expand(c.subs(sub)) for k,c in gam(X,Y,conv).items()}
            sv={k:c for k,c in sv.items() if c!=0}
            if not vec_eq(tv,sv): bad+=1; print('  MISMATCH',(x,y),'table',tv,'script',sv)
        miss=[(X,Y,{k:sp.expand(c.subs(sub)) for k,c in gam(X,Y,conv).items() if sp.expand(c.subs(sub))!=0}) for X in NAMES for Y in NAMES if (X,Y) not in listed]
        miss=[m for m in miss if m[2]]
        print('  listed',len(gtab),'mismatches',bad,'; pairs with non-zero script gamma not in table:',len(miss))
        for m in miss: print('   ',m)
    # solvability with b09's own gamma table (gb symbolic -> gb=1), K dropped
    M,rows,_=None,None,None
    Mx,_,rows,idx=build(False,[])
    full={}
    for (x,y),v in gtab.items(): full[(L[x],L[y])]={L[k]:c for k,c in v.items()}
    col=sp.Matrix([full.get((X,Y),{}).get(k,0) for (X,Y),k,_ in rows])
    print('== b09 own gamma table (gb=1): rank A',Mx.rank(),'rank [A|g_table]',Mx.row_join(col).rank())
    # also test only the subsystem of the three pairs used in its derivation: (E1,E4),(E1,E_-2d),(E1,E1)
    sel=[i for i,((X,Y),k,_) in enumerate(rows) if (X,Y) in {('Ap_bm','Am_bm'),('Ap_bm','Em2d'),('Ap_bm','Ap_bm')}]
    Ms=Mx.extract(sel,list(range(Mx.shape[1]))); cs=col.extract(sel,[0])
    print('   subsystem of pairs (E1,E4),(E1,E_-2d),(E1,E1): rank A_sub',Ms.rank(),'rank [A_sub|g]',Ms.row_join(cs).rank())
if which=='b10':
    ns=runpy.run_path('copies/thm01-R-sonnet46-b10-C/extracted_block_L356.py')
    # parse gamma/f tables from the markdown text blocks (strings with unicode)
    src=open('copies/thm01-R-sonnet46-b10-C/docs/issues/mathematical_proof.md',encoding='utf8').read().split('\n')
    def blk(a,b): return '\n'.join(src[a-1:b])
    code=blk(389,428).replace('```','')
    code=open('copies/thm01-R-sonnet46-b10-C/extracted_block_L389.py',encoding='utf8').read()
    ns=runpy.run_path('copies/thm01-R-sonnet46-b10-C/extracted_block_L389.py')
    gt=ns['gamma_gb_n1']; ft=ns['f_map_n1']
    L={'H1':'H1','H2':'H2','E_2d':'E2d','E_m2d':'Em2d','E1':'Ap_bp','E2':'Ap_bm','E3':'Am_bp','E4':'Am_bm'}
    S={'α':gAp_bp,'β':gAp_bm,'γ̃':gAm_bp,'δ':gAm_bm}
    def pc(s):
        s=s.replace('−','-')
        m=re.fullmatch(r'(-?\d*)(α|β|γ̃|δ)?',s)
        c=m.group(1); sym=m.group(2)
        k={'':1,'-':-1}.get(c,None); k=int(c) if k is None else k
        return k*(S[sym] if sym else 1)
    def conv_tab(t): return {(L[x],L[y]):{L[g]:pc(c) for c,g in v} for (x,y),v in t.items()}
    gtab=conv_tab(gt)
    ftab={L[s]:{L[g]:pc(c) for c,g in v} for s,v in ft.items()}
    print('== b10 f_map_n1 (L416-427): f =',ftab)
    # b10 gamma table: skew-completion? compare listed pairs, both conventions
    for conv in ('left','right'):
        bad=0;listed=set()
        print('== b10 gamma table (L394-413) vs script gamma, kappa-%s, all four gb'%conv)
        for (X,Y),tv in gtab.items():
            listed.add((X,Y)); sv=gam(X,Y,conv)
            if not vec_eq(tv,sv): bad+=1; print('  MISMATCH',(X,Y),'table',tv,'script',sv)
        miss=[(X,Y) for X in NAMES for Y in NAMES if (X,Y) not in listed and (Y,X) not in listed and gam(X,Y,conv)]
        print('  listed',len(gtab),'mismatches',bad,'; unordered pairs with non-zero script gamma and not listed:',len(miss),miss)
    # delta f of their f versus their table and versus script
    for name,ref in (('own table (listed pairs; unlisted ordered pairs: table value or its skew partner else 0)',None),):
        pass
    badtab=0;badscr={'left':0,'right':0}
    for X in NAMES:
        for Y in NAMES:
            d=delta_f(ftab,X,Y)
            if (X,Y) in gtab: t=gtab[(X,Y)]
            elif (Y,X) in gtab:
                sgn=-(-1)**(PAR[X]*PAR[Y]); t={k:sgn*v for k,v in gtab[(Y,X)].items()}
            else: t={}
            if not vec_eq(d,t): badtab+=1
            for conv in ('left','right'):
                if not vec_eq(d,gam(X,Y,conv)): badscr[conv]+=1
    print('== b10 f_map: ordered pairs (of 64) where delta f != their gamma table (skew-completed):',badtab,'; != script gamma:',badscr)
    for X,Y in [('H1','Ap_bp')]:
        print('   (delta f)(H1,E1) with their f:',delta_f(ftab,X,Y),'their gamma:',gtab[(X,Y)])
    # solvability of their own gamma table
    Mx,_,rows,idx=build(False,[])
    full={}
    for (X,Y),v in gtab.items():
        full[(X,Y)]=v
        sgn=-(-1)**(PAR[X]*PAR[Y])
        if (Y,X) not in gtab: full[(Y,X)]={k:sgn*c for k,c in v.items()}
    for vals in [(1,2,3,5)]:
        sub=dict(zip(GB,vals))
        col=sp.Matrix([sp.sympify(full.get((X,Y),{}).get(k,0)).subs(sub) for (X,Y),k,_ in rows])
        print('== b10 own gamma table at (gb++,+-,-+,--)=',vals,': rank A',Mx.rank(),'rank [A|g_table]',Mx.row_join(col).rank())
    # b10 odd-odd structure table vs SC
    t=runpy.run_path('copies/thm01-R-sonnet46-b10-C/extracted_block_L356.py')['structure_odd_odd_n1']
    bad=0
    for (x,y),v in t.items():
        X,Y=L[x],L[y]; tv={L[k]:c for k,c in v.items()}
        if not vec_eq(tv,drop(SC[(X,Y)])): bad+=1; print('  SC MISMATCH',(x,y),'table',v,'script',dict(SC[(X,Y)]))
    print('== b10 structure_odd_odd_n1 mismatches',bad,'of',len(t))
