import sympy as sp, json, itertools, pickle
from osc import *
# 1) undeformed structure constants and gamma
SC={}; GAM={}
for X in NAMES:
    for Y in NAMES:
        br=sbr(G[X],G[Y],PAR[X],PAR[Y])
        nk,k=split_kappa(br)
        SC[(X,Y)]=decompose(nk) if nk else {}
        # nk should equal undeformed bracket (gb independent)
        assert all(not c.free_symbols for c in nk.values()),(X,Y)
        GAM[(X,Y)]=decompose(k) if k else {}
pickle.dump((SC,GAM),open('alg_data.pkl','wb'))
for (X,Y),v in SC.items():
    if v: print('SC',X,Y,v)
print()
for (X,Y),v in GAM.items():
    if v: print('GAM',X,Y,v)
