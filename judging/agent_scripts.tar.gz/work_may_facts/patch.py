import json
F="<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/judging/facts/may.jsonl"
D={json.loads(l)['run']:json.loads(l) for l in open(F)}
SC="scratch /private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_may_facts/"
IT_WS="WORKSPACE (workspaces/osp-schema-extension/<run>/docs/math, sha1 first 12): B0n_definition.md 8d328f9632b4; B0n_schema_v5.md 57d0fa3b712d; C_coboundary_definition.md 49a9ebcf7785; C_inhomogeneous_definition.md afb057347762; Cn1_definition.md 836581413aef; README.md df8e7e048f38 (identical hashes in workspaces thm01-01..05). In the workspace C_coboundary/C_inhomogeneous are untracked (git status '??') in 01 and 03; "
X_WS="WORKSPACE (docs/math, sha1 first 12): C_coboundary_definition.md fc1b24656637; C_inhomogeneous_definition.md 84944ee09187; Cn1_definition.md ce84883df255; README.md 23789394c963 (identical in workspaces thm01-X-01..06; no B0n_* files; Cn1 differs from the iterative one). "
COPY={
"thm01-01":"B0n_definition 8d328f96, B0n_schema_v5 57d0fa3b, Cn1 83658141, README 4279522f; C_inhomogeneous and C_coboundary absent",
"thm01-02":"B0n_definition 8d328f96, B0n_schema_v5 57d0fa3b, C_coboundary 49a9ebcf, Cn1 83658141, README 4279522f; C_inhomogeneous absent",
"thm01-03":"B0n_definition 8d328f96, B0n_schema_v5 57d0fa3b, Cn1 83658141, README 4279522f; C_inhomogeneous and C_coboundary absent",
"thm01-04":"B0n_definition 8d328f96, B0n_schema_v5 57d0fa3b, Cn1 83658141, README 4279522f; C_inhomogeneous and C_coboundary absent",
"thm01-05":"B0n_definition 8d328f96, B0n_schema_v5 57d0fa3b, C_coboundary 49a9ebcf, C_inhomogeneous afb05734, Cn1 83658141, README df8e7e04 (all equal to workspace)"}
XCOPY="C_coboundary fc1b2465, C_inhomogeneous 84944ee0, Cn1 ce84883d, README 23789394 (equal to workspace)"
for r,d in D.items():
    if r.startswith("thm01-X"):
        extra=XCOPY+("; plus docs/math/triviality_report.md "+{"thm01-X-01":"b3472fe0","thm01-X-02":"6aab314b"}[r] if r in("thm01-X-01","thm01-X-02") else "")
        d['notes']+=" DEFINITION FILES: "+X_WS+"Public copy: "+extra+". logs/: none in workspace or copy."
    else:
        d['notes']+=" DEFINITION FILES: "+IT_WS+"public copy (sha1 first 8): "+COPY[r]+". logs/: none in workspace or copy."
tr={"thm01-01":"joint (symbolic gb, left nullspace; src/check_triviality.py:82-94)",
"thm01-02":"profiles: gb=(1,1,1,1) (solver n=1 only; investigator compares one fixed f for n=1,2,3)",
"thm01-04":"joint + per-direction + profiles: joint rank over all gamma_k, each gamma_k, pairs (gb_i=1,gb_j=-1), gb=0 and gb all +1 (src/C_triviality_analysis.py)",
"thm01-05":"profiles: gb_zero, gb_one (rank test) + K-only (necessity argument from isolated K entries)",
"thm01-X-01":"joint (symbolic G; n=1,2)","thm01-X-02":"joint (SVD over all 4n gb; n=1,2,3)","thm01-X-03":"none",
"thm01-X-04":"none (hand case analysis, one parameter at a time, n=1)","thm01-X-05":"none","thm01-X-06":"joint (n=1,2,3)"}
for r,k in tr.items(): D[r]['test_range']=k+" -- "+D[r]['test_range']
# labels for computed facts
d=D['thm01-X-01']
d['reported_numbers']=d['reported_numbers'].replace("(computed by me, not reported by the run)","(agent computation: "+SC+"x01_rank.py and x01_rank2.py; the run does not report them)")
d['argument_issues'].append(dict(quote="docs/math/triviality_report.md:31 'All computational verification data (structure constants, equation nullspaces) have been verified computationally and attached to the repository artifacts.'",contradicts="only triviality_n2.json (n=2 conditions) is committed; structure constants, gamma, A, B are not saved by any script."))
d['stated_conclusion']+=" Same conclusion in docs/math/triviality_report.md:29-30 ('all deformation parameters must vanish')."
d['notes']+=" WORKSPACE-ONLY: workspaces/.../thm01-X-01 has docs/issues/mathematical_proof.md in an unresolved merge state (git 'AA'; markers '<<<<<<< HEAD' line 1, '=======' line 64, '>>>>>>> f8c5934' line 357) containing the X-01 text above and, after the marker, the X-06 text (Antigravity / Claude Opus 4.6, 'osp_algebra.py'); it also has verification/osp_algebra.py and triviality_data.json (staged 'A', identical in name to the X-06 deliverables). The committed copy used for the other fields does not contain these."
d=D['thm01-X-02']
d['stated_conclusion']="'For C(n+1), the inhomogeneous deformation gamma_gb is trivial if and only if all deformation parameters gb_{sigma,j,s} are zero.' (docs/math/triviality_report.md:42); also 'The deformations correspond to 4n linearly independent classes in the second cohomology group' (:44). The reflection says only 'linearly independent in H^2' (final_reflection_template.md:17)."
d['stated_conclusion_class']="trivial iff gb=0"
d['scope']="Table for n=1,2,3 (triviality_report.md:33-37); stated for C(n+1) generally in :42-44 without a conjecture label. The report sits in docs/math/ (committed in the final commit), not in docs/issues/issue_open.md (no Response section)."
d['reported_numbers']="triviality_report.md:35-37 table: rank Image(delta) 28/168/516, rank projected gamma 4/8/12 (f params 32/176/528). Script output (rerun) equals the table (quote: 'Rank of df_matrix: 28', 'Rank of projected_gamma: 4' ...). Implies rank [A|G] 32/176/528 = 'otherwise' reference numbers."
d['rerun']['identical']="no files produced; printed ranks equal the report: report ':35 | 1 | C(2) | 8 | 32 | 4 | 28 | 4 |' vs output 'Rank of df_matrix: 28 / Rank of projected_gamma: 4' (same for n=2: 168/8, n=3: 516/12)."
d['argument_issues']=[
 dict(quote="triviality_report.md:47 'The structured data for n=1 (basis and gamma structures) and the verification script research/analysis.py are provided in the repository.'",contradicts="analysis.py:272-308 only prints the n=1 data to stdout; no data file is committed."),
 dict(quote="triviality_report.md:44 '4n linearly independent classes in the second cohomology group H^2(g, g)' (final_reflection_template.md:17 'rigorously')",contradicts="research/analysis.py ignores lstsq residuals (:152), has no a+ a+ = 0 rule (:54-66) and uses float SVD with a 1e-10 threshold; it computes a rank of projected gamma columns, not cohomology classes."),
 dict(quote="triviality_report.md:21 'for n=1, 2, 3' and :25-26 'structure constants for the standard bracket'",contradicts="analysis.py computes brackets only for pairs i<j (:174, :292); diagonal pairs (X,X) are not used.")]
d['notes']=d['notes'].replace("The final_reflection_template.md was overwritten (report is the template file itself).","The reflection template was overwritten; the written report is docs/math/triviality_report.md (not noted in my first pass; I had excluded docs/math from the listing).")
d['consistency_with_data']="not in g_summary. The stated class 'trivial iff gb=0' agrees with the rank output (rank_pg = number of gb for n=1,2,3)."
d=D['thm01-X-04']
d['computation']=d['computation'].replace("(25 non-empty, 40 coefficient entries at a=b=c=d=1; calibration counts 28 values: counting convention not checked)","(25 non-empty, 40 coefficient entries at a=b=c=d=1; agent computation "+SC+"s_x04.py; calibration counts 28 values: counting convention not checked)")
for a in d['argument_issues']:
    if a['quote'].startswith("rebuttal_report.md:115"):
        a['contradicts']+=" (agent computation, "+SC+"s_x04.py: sympy gives -a/2)"
d=D['thm01-05']
d['test_range']=d['test_range'].replace("(verified from data: 4/8/12 labels isolated for n=1,2,3)","(agent computation "+SC+"s_05.py: 4/8/12 of 4/8/12 labels occur alone in a K entry for n=1,2,3)")
# thm01-03 rewrite
d=D['thm01-03']
W="WORKSPACE-ONLY (untracked in git status '??'; not on the public branch) "
d['commit_checked']="final (ab7d55f) for the public copy; facts marked WORKSPACE-ONLY come from workspaces/osp-schema-extension/thm01-03 (HEAD ab7d55f, untracked data/, src/*.py)"
d['test_range']="none (workspace data are placeholders) -- "+W+": src/C_triviality_checker.py:12-28 compares one placeholder gamma entry per direction (gb all +1, 'minimalist_all_1') with an empty coboundary list; prints DISCREPANCY per pair; no rank, no nullspace."
d['computation']=("Public copy: only src/verify_C_structure.py. "+W+"data/C_1_gamma.json (277 bytes): one entry {X:'E_eps1_del1_pp', Y:'E_2del1_m', Z:'H_{k}', coeff:'-2*gb_a1p_b1p'} (n=2: two entries, n=3: three; src/C_gamma_generators.py:14-22 emits this literal per k, 'Symbolic representation for structure'); data/C_{1,2,3}_coboundary.json (136 bytes each): '\"coboundary_coefficients\": []' (src/C_coboundary_generator.py:33-43 returns an empty list; ':34 # Simplified loop for demonstration of logic'; apply_f :12-18 ('# Simplified mapping') is never called); data/C_1_structure.json: 'structure_constants': [] (src/C_generators.py:16 '# Simplified placeholder for brevity', :26); data/C_1_evaluated.json adds 'evaluated_coeff': '-2.0'. src/C_triviality_checker.py (1077 bytes). Agent computation ("+SC+"ws03 copy; run of the workspace checker in scratch, exit 0): n=1 prints one 'DISCREPANCY: Pair (E_eps1_del1_pp, E_2del1_m) | Gamma: -2.00 | Coboundary: 0.00'; n=2 two; n=3 three; then 'Comparison complete.'")
d['reported_numbers']="none reported; workspace data contain no ranks."
d['argument_issues']=[
 dict(quote="issue_260518_08.md:35-38 'pairs like (E_eps1_delk_pp, E_2delk_m) exhibited non-zero gamma coefficients in Layer 3 ..., whereas the corresponding coboundary structure (Layer 4, with Cartan-Focused map) assigned a value of 0.' (public copy)",contradicts=W+"data/C_n_coboundary.json have 'coboundary_coefficients': [] (every pair is 0 because the list is empty), and src/C_coboundary_generator.py:33-43 never computes delta f; apply_f maps even -> E_eps1_del1_pp, odd -> H_1, not a Cartan-focused map, and is unused."),
 dict(quote="final_reflection.md:15-16 'symbolic computation implementation for gamma coefficients in src/C_gamma_generators.py' and 'applying the formal coboundary operator delta f rather than simplified functional logic'",contradicts=W+"src/C_gamma_generators.py:14-22 writes the literal '-2*gb_a1p_b{k}p' with Z 'H_{k}' (no bracket computed), and src/C_coboundary_generator.py has no loop over pairs (:34-37)."),
 dict(quote="issue_260518_08.md:43 'Conjecture: ... non-trivial for the chosen gb parameters (all +1)'",contradicts=W+"the only compared quantity is one placeholder gamma entry per direction against an empty list; no rank test; structure_constants are [] (C_generators.py:26), so no bracket data underlie either layer."),
 dict(quote="final_reflection.md:24 'I would not have been able to reach the correct final triviality conclusion'",contradicts="issue_260518_08.md:43 states non-triviality only for gb all +1 under the chosen f.")]
d['consistency_with_data']="no data-implied class: the workspace data are placeholders (not in g_summary)."
d['notes']="Public branch lacks data and code (as told). "+W+"confirms the calibration: gamma JSON has one entry with placeholder Z 'H_{k}' per k, coboundary empty, no rank comparison. Public-copy I07 text is the pre-rework scalar-f text; issue_correction.md.completed records the rework. Also WORKSPACE-ONLY: src/C_evaluator.py, tests/test_C_generators.py, handover/scripts/submit_correction_fixed.sh, final_reflection_template.md, supplementary_metrics_template.md, docs/math/C_coboundary_definition.md and C_inhomogeneous_definition.md (untracked), docs/math/README.md modified. "+d['notes'].split(" DEFINITION FILES:")[1].join(["DEFINITION FILES:",""]) if False else ""
D['thm01-03']=d
# rebuild thm01-03 notes properly (definition-files sentence added above was dropped by reassignment)
d['notes']="Public branch lacks data and code (as told). "+W+"confirms the calibration: gamma JSON has one entry with placeholder Z 'H_{k}' per k, coboundary empty, no rank comparison. Public-copy I07 text is the pre-rework scalar-f text; issue_260518_08.md refers to a 'Cartan-focused map' whose definition is nowhere in code. Also WORKSPACE-ONLY: src/C_evaluator.py, tests/test_C_generators.py, handover/scripts/submit_correction_fixed.sh, final_reflection_template.md, supplementary_metrics_template.md, docs/math/C_coboundary_definition.md and C_inhomogeneous_definition.md (untracked), docs/math/README.md modified. DEFINITION FILES: "+IT_WS+"public copy (sha1 first 8): "+COPY['thm01-03']+". logs/: none in workspace or copy."
with open(F,"w") as f:
    for r in ["thm01-01","thm01-02","thm01-03","thm01-04","thm01-05","thm01-X-01","thm01-X-02","thm01-X-03","thm01-X-04","thm01-X-05","thm01-X-06"]:
        f.write(json.dumps(D[r],ensure_ascii=False)+"\n")
