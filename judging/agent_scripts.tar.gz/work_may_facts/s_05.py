import json
R='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_may_facts/thm01-05/data/'
for n in (1,2,3):
    gm=json.load(open(R+f'C_{n}_gamma.json'))['inhomogeneous_deformation']['gamma_matrix']
    labs=set(l for e in gm for l in e['coeff']); iso=set(list(e['coeff'])[0] for e in gm if e['Z']=='K' and len(e['coeff'])==1)
    print(n,len(gm),len(labs),len(iso))
