import sys,io,contextlib
sys.path.insert(0,'.')
with contextlib.redirect_stdout(io.StringIO()):
    import nullspace_n2 as m
import numpy as np
A=np.array(m.A_mat.tolist(),dtype=float);B=np.array(m.B_mat.tolist(),dtype=float)
print(A.shape,np.linalg.matrix_rank(A),np.linalg.matrix_rank(np.hstack([A,B])))
