"""
C_gamma_generators.py
Computation logic for C(n+1) Gamma structure constants.
"""

import json

def get_gamma_coeffs(n):
    """
    Computes symbolic gamma coefficients for C(n+1) based on
    $[b_j^s, a_1^\sigma] = - \mathrm{gb}_{\sigma, j, s} \cdot \kappa$.
    """
    coeffs = []
    # Symbolic representation for structure: -2 * gb_{sigma, j, s}
    # Example symbolic entry:
    for k in range(1, n + 1):
        coeffs.append({
            "X": f"E_eps1_del{k}_pp",
            "Y": f"E_2del{k}_m",
            "Z": "H_{k}",
            "coeff": f"-2*gb_a1p_b{k}p"
        })
    return coeffs

def generate_gamma(n):
    return {
        "schema_version": "5.0",
        "inhomogeneous_deformation": {
            "gb_matrix_convention": "minimalist_all_1",
            "gamma_coefficients": get_gamma_coeffs(n)
        }
    }

if __name__ == "__main__":
    for n in [1, 2, 3]:
        data = generate_gamma(n)
        with open(f"data/C_{n}_gamma.json", "w") as f:
            json.dump(data, f, indent=2)
