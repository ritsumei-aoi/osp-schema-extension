"""
C_triviality_checker.py
Compares Layer 3 (deformation) and Layer 4 (coboundary) to analyze triviality.
"""

import json

def load_json(filepath):
    with open(filepath, 'r') as f:
        return json.load(f)

def compare_structures(n):
    layer3 = load_json(f"data/C_{n}_evaluated.json")
    layer4 = load_json(f"data/C_{n}_coboundary.json")
    
    coeffs3 = { (c['X'], c['Y']): float(c['evaluated_coeff']) for c in layer3['inhomogeneous_deformation']['gamma_coefficients'] }
    coeffs4 = { (c['X'], c['Y']): float(c['coeff']) for c in layer4['coboundary_structure']['coboundary_coefficients'] }
    
    print(f"--- Triviality Check for C({n+1}) ---")
    all_pairs = set(coeffs3.keys()) | set(coeffs4.keys())
    
    for pair in all_pairs:
        val3 = coeffs3.get(pair, 0.0)
        val4 = coeffs4.get(pair, 0.0)
        if abs(val3 - val4) > 1e-9:
            print(f"DISCREPANCY: Pair {pair} | Gamma: {val3:.2f} | Coboundary: {val4:.2f}")
    
    print("Comparison complete.")

if __name__ == "__main__":
    for n in [1, 2, 3]:
        compare_structures(n)
