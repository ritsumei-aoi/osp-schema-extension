"""
C_evaluator.py
Substitution script for generating Schema 3 JSON from Schema 2 symbols.
Uses the Uniform Positive Assignment (gb = +1).
"""

import json
import re

def evaluate_coeffs(n):
    with open(f"data/C_{n}_gamma.json", "r") as f:
        data = json.load(f)
    
    # Substitutes 'gb_...' symbols with '1.0'
    for entry in data["inhomogeneous_deformation"]["gamma_coefficients"]:
        coeff_str = entry["coeff"]
        # Pattern: replace any 'gb_...' with '1.0'
        # The symbolic format is e.g. "-2*gb_a1p_b1p"
        eval_val = re.sub(r'gb_[a-z0-9_]+', '1.0', coeff_str)
        # Evaluate simple math string: "-2*1.0"
        entry["evaluated_coeff"] = str(eval(eval_val))
    
    return data

if __name__ == "__main__":
    for n in [1, 2, 3]:
        data = evaluate_coeffs(n)
        with open(f"data/C_{n}_evaluated.json", "w") as f:
            json.dump(data, f, indent=2)
