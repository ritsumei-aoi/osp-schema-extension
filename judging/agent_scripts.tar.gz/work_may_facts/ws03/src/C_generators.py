"""
C_generators.py
Implementation for computing structure constants for C(n+1) = osp(2|2n)
based on finalized conventions.
"""

import json

def get_basis(n):
    """Returns sorted basis based on PBW ordering."""
    # Even: Cartans (n+1) + roots (2n^2-n even roots)
    even = [f"H_{i}" for i in range(1, n + 2)]
    # Roots: +2*delta_k, -2*delta_k, \pm delta_i \pm delta_j
    even += [f"E_2del{k}_p" for k in range(1, n+1)]
    even += [f"E_2del{k}_m" for k in range(1, n+1)]
    # Simplified placeholder for brevity
    
    odd = [f"E_eps1_del{k}_{s}" for k in range(1, n + 1) for s in ["pp", "pm", "mp", "mm"]]
    return odd + even 

def generate_schema(n):
    return {
        "schema_version": "5.0",
        "algebra": {"family": "C", "m": 1, "n": n},
        "basis": get_basis(n),
        "structure_constants": []
    }

if __name__ == "__main__":
    for n in [1, 2, 3]:
        data = generate_schema(n)
        with open(f"data/C_{n}_structure.json", "w") as f:
            json.dump(data, f, indent=2)
