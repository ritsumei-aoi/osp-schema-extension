import sys, sympy as sp
sys.path.insert(0,'/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_may_facts/thm01-X-04/docs/issues')
sys.dont_write_bytecode=True
import verification_artifacts as v
g=v.gamma_gb_n1(1,1,1,1)
print('keys',len(g),'nonempty',sum(1 for k in g if g[k]),'entries',sum(len(x) for x in g.values()))
a,p1,q1,al=sp.symbols('a p1 q1 al')
sol=sp.solve([2*p1-al+a, q1-al+a/2],[p1,q1],dict=True)[0]
print('2p1-q1 =',sp.simplify(2*sol[p1]-sol[q1]))
