import sys,io,contextlib
sys.path.insert(0,'.')
with contextlib.redirect_stdout(io.StringIO()):
    import nullspace_n1 as m
import sympy as sp
A,B=m.A_mat,m.B_mat
print(A.shape,B.shape,A.rank(),A.row_join(B).rank())
nl=[ (k,v) for k,v in m.gamma.items() if any(isinstance(c,sp.Expr) and len(c.free_symbols)>0 and sp.Poly(c,*m.G_vars).total_degree()>1 for c in v)]
print('nonlinear gamma entries',len(nl))
print('n basis',len(m.basis))
