import json, os, sys
J='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/'
OUT='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/judging/facts/bC_gemini37f.jsonl'
def Q(run, path, snip):
    p=J+'thm01-R-gemini37f-%s-C/'%run+path
    for i,l in enumerate(open(p,encoding='utf-8'),1):
        if snip in l: return '%s:%d: "%s"'%(path,i,snip)
    raise SystemExit('NOT FOUND %s %s %s'%(run,path,snip))
PRF='docs/issues/mathematical_proof.md'; ISS='docs/issues/issue_open.md'
VER='python3 --version = Python 3.14.8; sympy.__version__ = 1.14.0'
REF=("Reference (independent_triviality4.py, run as copy, n=1/n=2): sign=super K=drop 28->28 / 168->168; sign=none K=drop 28->32 / 168->176; K=keep 28->32 / 168->176 (both signs).")
recs=[]
def add(r): recs.append(r)
LAT='Cited code is each run own engine; "agent computation" items use scripts in work_bC_gemini37f/checks/.'
ORACLE=("agent computation, not validated against the reference: checks/check_oscillator_claims.py (own explicit representation a+=[[0,1],[0,0]], a-=[[0,0],[1,0]], b+=x, b-=d/dx)")

# ---------------- b01 ----------------
def b01(commit,first):
    r='b01'
    d=dict(run='thm01-R-gemini37f-b01-C',commit_checked=commit,
     stated_conclusion=Q(r,ISS,'unconditionally trivial for all values of the deformation parameters')+' ; '+Q(r,PRF,'**unconditionally trivial** for **all** configurations'),
     stated_conclusion_class='all gb trivial',
     scope='Evidence n=1,2,3: '+Q(r,PRF,'**Unconditionally Trivial** | **Unconditionally Trivial** | **Unconditionally Trivial**')+'. General n: '+Q(r,PRF,'### Main Theorem (Unconditional Triviality)')+' ; '+Q(r,PRF,'## 6. Mathematical Derivation of General Solution for All $n$')+' (explicit f given only partially, "+ \\dots", lines 130-135).',
     declared_reading=dict(
      gb_parity=Q(r,PRF,'parity-1 parameters')+' (code uses gb as ordinary sympy symbols).',
      kappa_sign_handling=Q(r,PRF,"$\\kappa$ is an odd central parameter")+' ; code: '+Q(r,'algebra_solver.py',"p1 = 1 if (t1[0] == 'a' or t1[0] == 'kappa') else 0")+' (kappa supercommutes: sign -1 when odd element passes kappa).',
      K_treatment=Q(r,PRF,'project to $0$ in')+' ; code decompose_modulo_scalars returns the scalar part separately and run_full_verification.py:250 discards it (K dropped, f cannot map into K).'),
     test_range='joint: '+Q(r,'run_full_verification.py','sol = sp.solve(equations, list(phi.values()))')+' with symbolic gb; '+Q(r,'run_full_verification.py','remaining = [sp.simplify(eq.subs(sol))')+' counts equations left on gb (0).',
     computation='run_full_verification.py (DeformedLieSuperalgebra.normal_order_word, superbracket, decompose_modulo_scalars, run_verification_for_n: C, gamma, delta f, sp.solve). Earlier/debug scripts also committed: algebra_solver.py, compute_algebra.py, run_n1.py, run_n2.py, test_n1.py, debug_bracket.py, test_env.py; __pycache__/*.pyc committed. Hard-coded verdict: '+Q(r,'run_full_verification.py','"triviality_conclusion": "UNCONDITIONALLY_TRIVIAL",')+' written into every artifact regardless of the solve result. No placeholder content.',
     reported_numbers='proof table '+Q(r,PRF,'**Solved $\\phi$ Variables**')+' (28/168/516 = reference rank A); equations 216/2768/13848 and structure constants 42/180/462 equal artifact values (artifacts/verification_artifact_n*.json). Unsatisfied gb constraints 0 => rank[A|G]=rank A, i.e. the 28->28 / 168->168 pattern of the reference (sign=super, K=drop).',
     rerun=dict(command='cd <scratch copy>; timeout 600 python3 run_full_verification.py',exit_code=0,versions=VER,wall='about 4m14s (time log)',result='regenerated artifacts/verification_artifact_n1,n2,n3.json differ from committed only in execution_time_seconds (0.915 vs 0.953; 17.754 vs 18.757; 212.036 vs 233.699); all other fields identical. Printed "Number of unsatisfied equations on gb: 0" for n=1,2,3. '+('Code is byte-identical to the final commit (only final_reflection.md and supplementary_metrics.md differ), so this rerun covers both commits.')),
     argument_issues=[dict(quote=Q(r,PRF,'f(B_{j,k}^{++}) = -2 \\mathrm{gb}_{-, j, +} F_k^{+, +} - 2 \\mathrm{gb}_{-, k, +} F_j^{+, +} + \\dots'),
        contradicts='For j=k=1 this gives -4 gb_{-,1,+} for the F_1^{+,+} component of f(B^{++}_{11}); artifacts/verification_artifact_n1.json solution_f has phi_4_1 = "-2*gb_-_1_+ + 2*phi_2_7" (basis index 1=B++, 4=F+,+; value -2 gb_{-,1,+} at free parameters 0). Possible only if the omitted terms/gauge differ; the text says "free derivation parameters are set to zero" (line 128) and does not say the formula is for j!=k. Unclear.')],
     consistency_with_data='Not in g_summary.csv. Own rerun: all gb solved (rank[A|G]=rank A), K dropped, kappa supercommuting: matches the reference combination sign=super K=drop (all gb trivial). stated class "all gb trivial": match.',
     notes='Turns: turn1 ended while the n=3 job was running (final message "I am waiting..."); turn2 (after harness reply "No external access is approved...") holds the report; turn3 is the reflection. A command deleting scratch files (rm -rf __pycache__ ...) was denied. '+('Final commit adds only final_reflection.md and supplementary_metrics.md to the first commit.' if not first else 'First commit lacks the reflection files.')+' Conclusion is the same in both commits.')
    return d
add(b01('first (25afb24)',True))
d=b01('final (cd2f820)',False); d['deliverable_changes_first_to_final']='added final_reflection.md, supplementary_metrics.md; no change under artifacts/, code, docs/ (git diff -rq of the two archives).'; add(d)

# ---------------- b03 ----------------
r='b03'
add(dict(run='thm01-R-gemini37f-b03-C',commit_checked='final (7b0af12; first = final)',
 stated_conclusion=Q(r,ISS,'unconditionally trivial** for all parameter configurations')+' ; '+Q(r,PRF,'is **unconditionally trivial** (coboundary) for all parameter values'),
 stated_conclusion_class='all gb trivial',
 scope='n=1,2,3: '+Q(r,PRF,'fully verified by exact symbolic computer algebra computation')+' ; general n: '+Q(r,PRF,'has been rigorously proven algebraically for general $n$')+' (proof by oscillator shift f_V, section 5).',
 declared_reading=dict(gb_parity='not stated (kappa odd: '+Q(r,PRF,'odd central element $\\kappa$')+').',
  kappa_sign_handling=Q(r,PRF,'using $u \\kappa = (-1)^{p(u)} \\kappa u$')+' ; code applies the sign: '+Q(r,'bracket_solver.py','s = (-1)**pu1')+' => kappa supercommutes.',
  K_treatment=Q(r,PRF,'central scalars commute with all elements and act by $0$ in the adjoint representation')+' ; reduction.py reduce_pair_to_basis drops constants ("mod scalars").'),
 test_range='per-direction: '+Q(r,'verify_all.py','gb_dict[gb_key] = sp.Rational(1)')+' (each unit gb solved separately with gauss_jordan_solve, residual asserted 0) + joint: analyze_triviality.py builds the nullspace of [A|-G] and counts nullspace vectors with nonzero gb part (triviality_results.json gb_in_coboundary_dim = 4/8/12 = number of gb).',
 computation='verify_all.py (run_comprehensive_verification: C via bracket_solver.compute_bracket, M_delta, gauss_jordan_solve, rref rank); analyze_triviality.py (analyze_triviality: joint nullspace); algebra_helper.py, bracket_solver.py, reduction.py; also inspect_f.py, test_algebra.py, verify_cn1.py. No hard-coded verdicts found ("is_coboundary": True is set after the asserted residual). No placeholder content. .gitignore excludes pycache.',
 reported_numbers=Q(r,PRF,'| $C(2) = \\mathfrak{osp}(2\\|2)$ | $4 \\mid 4$ | 8 | 4 | 32 | 28 | 4 |')+' (rank 28/168/516 = reference rank A; all gb coboundaries). rank[A|G]=rank A: matches reference sign=super K=drop.',
 rerun=dict(command='timeout 600 python3 verify_all.py ; timeout 600 python3 analyze_triviality.py (separate copies)',exit_code='0 and 0',versions=VER,result='artifacts/triviality_verification_data.json and triviality_results.json regenerated byte-identical to committed (12s and 4s).'),
 argument_issues=[dict(quote=Q(r,PRF,'\\{- \\mathrm{gb}_{+, j, s} a_1^- + \\mathrm{gb}_{-, j, s} a_1^+, a_1^-\\} = \\mathrm{gb}_{-, j, s} \\{a_1^+, a_1^-\\} = \\mathrm{gb}_{-, j, s} = - \\mathrm{gb}_{-, j, s} (-1)')+' ; '+Q(r,PRF,'$$ [\\widetilde{b}_j^s, \\widetilde{a}_1^\\sigma]_0 = - \\mathrm{gb}_{\\sigma, j, s} \\kappa. $$'),
   contradicts='Line 127 evaluates the sigma=- case to +gb_{-,j,s}; line 129 asserts -gb_{sigma,j,s} for all sigma (so -gb_{-,j,s}). Same-run inconsistency (the odd-shift construction f_V of section 5 therefore does not reproduce the sigma=- relation as written).')],
 consistency_with_data='Not in g_summary.csv. Data: all gb solved; kappa supercommuting, K dropped: matches reference sign=super K=drop. Class "all gb trivial": match.',
 notes='Explicit f listed in proof 6.3 matches artifacts f_canonical_matrix_entries for n=1 (compared). Turn2 is the reflection (no denial reply). run.json denied commands: none.'))

# ---------------- b06 ----------------
r='b06'
add(dict(run='thm01-R-gemini37f-b06-C',commit_checked='final (05d8afa; first = final)',
 stated_conclusion=Q(r,PRF,'is **trivial if and only if $\\mathrm{gb} = 0$**'),stated_conclusion_class='trivial iff gb=0',
 scope='n=1,2,3 by rank tables (proof 5.1); general n: stated as theorem "for all n>=1" ('+Q(r,PRF,'### **Main Theorem (Triviality of Inhomogeneous Deformation)**')+'), argued only by a weight remark (section 4.2.3, line 115 "heavily overdetermined linear system which forces all $\\mathrm{gb}$ parameters to vanish").',
 declared_reading=dict(gb_parity=Q(r,PRF,'parity-1 parameters'),
  kappa_sign_handling=Q(r,PRF,'where $p(\\kappa) = 1$ is an odd central generator')+' ; code: gamma terms use comm_1 with no sign for moving kappa past u1 (verify_osp.py:132-151) => kappa treated as commuting.',
  K_treatment='K not discussed; "up to scalar" is read as gamma=c*delta f (lines 98-99). Code skips the "const" entries (verify_osp.py:162,181) => K dropped.'),
 test_range='joint: rank A, rank [A|-B] and rank B over all gb columns together ('+Q(r,'scripts/verify_osp.py','combined_rows = [A_rows[i] + B_rows[i] for i in range(num_eqs)]')+').',
 computation='scripts/verify_osp.py (build_osp_algebra: bracket_0, gamma_gb, compute_delta_f_coeffs, NumPy float rank + exact Fraction exact_rref); scripts/summarize_results.py only prints saved JSON. artifacts_verification.json stores a string field "gb_triviality_condition" written as a constant ('+Q(r,'scripts/verify_osp.py',"'gb_triviality_condition': \"gb = 0 (all gb parameters must be zero for triviality)\",")+'). No placeholder content.',
 reported_numbers=Q(r,PRF,'| $\\operatorname{Rank}(M)$ ($\\operatorname{Rank}([A \\mid -B])$) | 32 | 176 | 528 |')+' ; rank A 28/168/516; equations 112/1400/6960 (rerun prints the same). K dropped + kappa commuting: matches reference sign=none K=drop (28->32, 168->176; 516->528 at n=3 not checked against the reference script).',
 rerun=dict(command='timeout 600 python3 scripts/verify_osp.py',exit_code=0,versions=VER,result='artifacts_verification.json regenerated byte-identical (23s). Printed Exact rank of M 32/176/528, A 28/168/516, skew errors 0, Jacobi errors 0.'),
 argument_issues=[],
 consistency_with_data='Not in g_summary.csv. Own ranks 28->32 (n=1), 168->176 (n=2) equal reference sign=none K=drop; class "trivial iff gb=0": match.',
 notes='Proof 3.3 / line 86 asserts gamma is a 2-cocycle by associativity; no cocycle test in this run (other runs with the same kappa-commuting convention, b09 and b14, got cocycle failures in their own scripts). No denied commands.'))

# ---------------- b08 ----------------
r='b08'
add(dict(run='thm01-R-gemini37f-b08-C',commit_checked='final (32a5080; first = final)',
 stated_conclusion=Q(r,ISS,'is **trivial** (i.e., $\\gamma_{gb} = \\delta f$')+' ... '+Q(r,PRF,'**if and only if all deformation parameters are identically zero**'),stated_conclusion_class='trivial iff gb=0',
 scope='n=1,2,3: '+Q(r,PRF,'The results corroborate the theoretical proof with zero exceptions.')+' ; general n: analytic proof in section 4 (Whitehead lemma on sp(2n) + H_0 matching).',
 declared_reading=dict(gb_parity=Q(r,PRF,'parity-1 parameters'),kappa_sign_handling=Q(r,PRF,'central odd element $\\kappa$ ($p(\\kappa)=1$)')+' ; code: verify_c_algebra.py:128-155 bilinear_bracket puts the kappa coefficient c1 in place of the commutator with no sign => kappa commuting.',
  K_treatment='"up to scalar" read as lambda*delta f (lines 78-82); reduce_pair returns a scalar that bilinear_bracket accumulates but get_algebra never uses => K dropped.'),
 test_range='joint: '+Q(r,'verification/verify_c_algebra.py','system_matrix, rhs = sp.linear_eq_to_matrix(equations, all_vars)')+' with unknowns gb and phi together; nullspace checked for nonzero gb part (0).',
 computation='verification/verify_c_algebra.py (get_algebra, verify_and_solve). symbolic_proof_check.py hard-codes the proof equations and does not use the algebra: '+Q(r,'verification/symbolic_proof_check.py','eq1 = - c_plus_minus - gb_minus_plus')+' ; analyze_proof.py, inspect_obstruction.py only print. verification_results.json field "gb_must_be_zero" is computed.',
 reported_numbers=Q(r,PRF,'| $C(2) = \\mathfrak{osp}(2\\|2)$ | 4 | 4 | 8 | 4 | 32 | 112 | 4 | 28 | **0** |')+' ; rank A 28/168/516, gb columns rank 4/8/12. Rerun: gb_matrix rank 4/8/12, phi rank 28/168/516, no solution with gb!=0 => 28->32 pattern: matches reference sign=none K=drop.',
 rerun=dict(command='timeout 600 python3 verification/verify_c_algebra.py',exit_code=0,versions=VER,result='verification/verification_results.json regenerated byte-identical (72s); "Jacobi identity verified: True" for n=1,2,3.'),
 argument_issues=[dict(quote=Q(r,PRF,'[w, E_{+2\\delta_k}]_0 = - c_{+, k, -} E_{+\\varepsilon + \\delta_k} - c_{-, k, -} E_{-\\varepsilon + \\delta_k}')+' ; '+Q(r,PRF,'[w, E_{-2\\delta_k}]_0 = c_{+, k, +} E_{+\\varepsilon - \\delta_k} + c_{-, k, +} E_{-\\varepsilon - \\delta_k}'),
   contradicts='The run own structure constants (agent computation using the run own get_algebra, checks/check_b08_b13_b06_claims.py, n=1) give [w,E_+2d1]_0 = c_{+e-d} E_{+e+d} + c_{-e-d} E_{-e+d} and [w,E_-2d1]_0 = -c_{+e+d} E_{+e-d} - c_{-e+d} E_{-e-d} (opposite signs to lines 141 and 147). [w,h_k]_0 (line 154) and gamma(H_0,.) (lines 132-136) agree with the engine. With the engine signs, solving [w,Y]_0=gamma(H_0,Y) for Y in {E_+2d1,E_-2d1,h_1} (checks/check_b08_system.py) gives c in terms of free gb (solution c_{+e+d}=-gb_{-,1,-}, c_{+e-d}=gb_{-,1,+}, c_{-e+d}=-gb_{+,1,-}, c_{-e-d}=gb_{+,1,+}); gb is not forced to zero by this subsystem, unlike lines 159-162. A second sign check by own explicit representation (agent computation, not validated against the reference: checks/check_oscillator_claims.py) agrees with the engine.'),
  dict(quote=Q(r,'verification/symbolic_proof_check.py','assert all(v == 0 for v in sol.values()), "All gb parameters must be identically zero!"')+' ; '+Q(r,'verification/symbolic_proof_check.py','print("Proof analytically verified!")'),
   contradicts='The equations eq1..eq8 are typed in from the proof (lines 23-46), not computed from the algebra; see the previous issue for what the run engine gives.')],
 consistency_with_data='Not in g_summary.csv. Own rerun 28->32 (no nonzero-gb solution), K dropped, kappa commuting: matches reference sign=none K=drop; class "trivial iff gb=0": match for the full-system conclusion; the stated analytic derivation does not reproduce it (see argument_issues).',
 notes='Turn1 was empty (a heredoc command was denied), turn2 (after reply "No external access is approved...") holds the report, turn3 the reflection. verification/__pycache__ committed.'))

# ---------------- b09 ----------------
r='b09'
add(dict(run='thm01-R-gemini37f-b09-C',commit_checked='final (f3b2219; first = final)',
 stated_conclusion=Q(r,PRF,'**if and only if** all deformation parameters vanish identically'),stated_conclusion_class='trivial iff gb=0',
 scope='n=1,2,3 by ranks (4.1); general n: theorem stated for all n (line 14-20) with generic formulas (Der = inner, dim formulas) and no general-n derivation of the intersection 0.',
 declared_reading=dict(gb_parity='not stated (line 12 calls gb a "4n-dimensional collection").',kappa_sign_handling=Q(r,PRF,'$\\kappa$ is an odd central element ($p(\\kappa)=1, \\kappa^2 = 0$)')+' ; verify_brackets.py:119-124 terms carry no sign for moving kappa => kappa commuting.',
  K_treatment='"up to scalar" read as c*delta f (line 93); K dropped in code ('+Q(r,'verify_brackets.py','b- b+ = b+ b- + 1 = H_k (mod scalars)')+').'),
 test_range='joint: '+Q(r,'generate_artifacts.py','M_aug = M_delta.row_join(M_gamma)')+' (rank of [M_delta|M_gamma] over all gb columns; intersection dimension).',
 computation='verify_cn1.py (get_algebra), verify_brackets.py (build_representation_map, compute_brackets), solve_triviality.py (compute_delta_f; test_triviality(1) runs at import), analyze_cohomology.py (runs n=1,2 at import), generate_artifacts.py (n=1,2,3, writes artifacts/*.json); also inspect_gamma.py, test_consistency.py, verify_cocycle_correct.py. Artifact flag "is_trivial_only_at_zero" computed. No placeholders.',
 reported_numbers=Q(r,PRF,'| Augmented Rank $\\operatorname{rank}([M_\\delta \\mid M_\\gamma])$ | 32 | 176 | 528 |')+' ; rank A 28/168/516. Matches reference sign=none K=drop (n=1,2).',
 rerun=dict(command='timeout 600 python3 generate_artifacts.py',exit_code=0,versions=VER,result='artifacts/C2,C3,C4_analysis.json and *_full_structures.json regenerated byte-identical.'),
 argument_issues=[dict(quote=Q(r,PRF,'be the inhomogeneous deformation 2-cocycle associated with'),
   contradicts='The run own checks of the cocycle condition printed failure: turn1.jsonl.gz event 64 (python3 analyze_cohomology.py): "2-cocycle condition for gamma_gb: FAILED" (n=1 and n=2); event 72 (verify_cocycle_correct.py, graded signs for odd kappa): "Corrected 2-cocycle check for n=1: FAILED". The committed proof does not mention these results.'),
  dict(quote=Q(r,PRF,'$\\mathfrak{sp}(2n)$ Cartan generators: $H_k = b_k^+ b_k^- + \\frac{1}{2}$'),contradicts='verify_cn1.py defines H_k with terms [(1, bp, bm)] i.e. b_k^+ b_k^- (no +1/2); proof line 52 gives E_{+-2d_k}=(b_k^+-)^2 while docs/math/Cn1_definition.md simple generators use 1/2 (b^+-)^2. Differences are scalar/normalization; stated as report-vs-code mismatch only.')],
 consistency_with_data='Not in g_summary.csv. Own 28->32, K dropped, kappa commuting: matches reference sign=none K=drop; class: match.',
 notes='docs/issues/issue_open.md has no Response section committed (Status still "open"); the report is only in mathematical_proof.md and the final chat message of turn2. final_reflection.md says 0 human interventions while run.json has denial_replies=1 (turn2 text "No external access is approved..."). uncommitted: ?? __pycache__/. Scripts execute computations at import time.'))

# ---------------- b11 ----------------
r='b11'
add(dict(run='thm01-R-gemini37f-b11-C',commit_checked='final (898f974; first = final)',
 stated_conclusion=Q(r,PRF,'**trivial if and only if all deformation parameters $\\mathrm{gb}_{\\sigma, j, s}$ are zero**'),stated_conclusion_class='trivial iff gb=0',
 scope='n=1,2,3 table (5.1); general n: theorem for all n with "Obstruction Proof" 4.3 (lines 135-137: "sets up an overdetermined linear system ... Hence: delta f = gamma_gb => gb = 0").',
 declared_reading=dict(gb_parity=Q(r,PRF,'$4n$ odd parameters'),kappa_sign_handling=Q(r,PRF,'odd central element $\\kappa$ ($p(\\kappa)=1$)')+' ; gamma is typed in by hand in run_full_analysis.py:144-228 (no kappa rule in code).',
  K_treatment='"up to scalar" read as c*delta f (4.2); the hand-built C contains no K component.'),
 test_range='joint: '+Q(r,'run_full_analysis.py','left_null = M.T.nullspace()')+' projects the symbolic gb right-hand side on the left nullspace and solves for gb.',
 computation='run_full_analysis.py (run_full_analysis: C and gamma entered by hand, equations, rank, cokernel). Other committed scripts: verify_all_n.py, verify_rigorous.py, verify_triviality.py (the three fail when run, see argument_issues), solve_osp22.py, analyze_system.py, exact_solvability.py, check_const_eqs.py, compare_c.py, analytical_osp.py, test_jacobi.py, test_corrected_algebra.py. Hard-coded: '+Q(r,'run_full_analysis.py','"triviality_condition": "gb = 0 for all parameters",')+' ; gamma entries typed in (lines 144-228). verification_artifacts.json holds counts and a sample of constraints only (no structure constants or gamma).',
 reported_numbers=Q(r,PRF,'| $C(2) \\cong \\mathfrak{osp}(2\\|2)$ | 1 | 4 | 4 | 8 | 32 | 216 | 28 | 188 | 4 |')+' ; rank M 28/168/516 = reference rank A; all gb forced to 0 => 28->32 pattern (sign=none K=drop) in effect (rank[A|G] not printed).',
 rerun=dict(command='timeout 600 python3 run_full_analysis.py (also verify_all_n.py, verify_rigorous.py, verify_triviality.py, test_corrected_algebra.py)',exit_code='run_full_analysis.py 0 (535s, within 600 limit); verify_all_n.py 1; verify_rigorous.py 1; verify_triviality.py 1; test_corrected_algebra.py 0 (90s, prints Jacobi errors = 0 for n=1,2,3)',versions=VER,result='verification_artifacts.json: all numeric fields and all_gb_zero_required identical to committed; differences only in computation_time_seconds and the order/representatives in unique_constraints_sample (set ordering).'),
 argument_issues=[dict(quote=Q(r,PRF,'$\\gamma_{gb}$ was verified to satisfy the graded 2-cocycle condition'),
   contradicts='The only cocycle check is in verify_all_n.py:250-280, after '+Q(r,'verify_all_n.py','assert jac_err == 0')+'. Run (copy, exit 1): "Jacobi check: 72 errors." then AssertionError, so the cocycle check is never reached (same in the Worker session, turn2.jsonl.gz event 56).'),
  dict(quote=Q(r,PRF,'The undeformed Lie superalgebra bracket $[\\cdot, \\cdot]_0$ was rigorously tested for all'),
   contradicts='verify_rigorous.py prints "Jacobi identity check on undeformed bracket: 72 errors (0 expected)" and crashes with AttributeError; verify_triviality.py crashes (AttributeError); verify_all_n.py reports 72 errors. test_corrected_algebra.py (different implementation from run_full_analysis.py) reports 0 errors (Worker log event 65). No Jacobi check exists inside run_full_analysis.py, so which bracket table the 0-error result refers to is unclear.')],
 consistency_with_data='Not in g_summary.csv. all gb forced to zero in own rerun (K absent): matches reference sign=none (28->32); class "trivial iff gb=0": match. gamma is hand-entered, so correspondence to the definition documents is not checked.',
 notes='Turn1 empty (heredoc denied); turn2 report after reply "No external access..."; turn3 reflection. Worker run of run_full_analysis.py took 464s.'))

# ---------------- b12 ----------------
def b12(commit,first):
    r='b12'
    d=dict(run='thm01-R-gemini37f-b12-C',commit_checked=commit,
     stated_conclusion=Q(r,PRF,'$$ \\gamma_{\\mathrm{gb}} \\sim 0 \\iff \\mathrm{gb}_{\\sigma, j, s} = 0 \\quad \\text{for all } \\sigma, j, s. $$'),stated_conclusion_class='trivial iff gb=0',
     scope='n=1,2,3: table 5 (rank/singular values); general n: Section 6 "Proof of Injectivity for all n" (lines 126-136).',
     declared_reading=dict(gb_parity=Q(r,PRF,'parity-1 parameters'),kappa_sign_handling=Q(r,PRF,'where $\\kappa$ is an odd central parameter ($p(\\kappa) = 1$)')+' ; fast_verify.py:213-240 gamma terms carry no sign for moving kappa => kappa commuting.',
      K_treatment=Q(r,PRF,'central scalars act trivially under the adjoint representation')+' ; code discards scalar_part (fast_verify.py:242 "v0, _ = canonical_to_basis(dict_0)").'),
     test_range='joint: '+Q(r,'fast_verify.py','obstruction_matrix = u_perp.T @ M_gamma')+' (projection of all gb columns on the left complement of im delta; float64 SVD, tolerance 1e-10).',
     computation='fast_verify.py (compute_all_structure; numerical, NumPy), export_artifacts.py (imports fast_verify, writes structure constants), solve_triviality.py and run_investigation.py (exact SymPy; run_investigation output in Worker log event 71 gives rank 28/168/516 and gb=0; not rerun), test_basis.py, test_comm.py. Constant strings: triviality_condition "gb == 0" in results json. No placeholders.',
     reported_numbers=Q(r,PRF,'| $C(2) = \\mathfrak{osp}(2\\mid 2)$ | 1 |')+' rank delta 28/168/516 and obstruction rank 4/8/12 (singular values 3.9986, 5.3596, 6.4547 equal the JSON). Equivalent to 28->32 pattern: matches reference sign=none K=drop.',
     rerun=dict(command='timeout 600 python3 fast_verify.py ; timeout 600 python3 export_artifacts.py (separate copies)',exit_code='0 and 0',versions=VER,result='docs/artifacts/triviality_verification_results.json and C_algebra_structure_constants.json regenerated byte-identical (14s, 15s). '+('Code identical in first and final commit.')),
     argument_issues=[dict(quote=Q(r,PRF,'[N_a, a_1^\\sigma b_j^s]_\\gamma = \\sigma \\cdot \\tfrac{1}{2} a_1^\\sigma b_j^s'),
        contradicts='Undeformed part with N_a = a^+a^- - 1/2 (line 44): '+ORACLE+' gives [N_a, a^+b^+]=+1*a^+b^+ and [N_a, a^-b^+]=-1*a^-b^+ (the sigma/2 version is false). The run own export (C_algebra_structure_constants.json) was not compared.'),
       dict(quote=Q(r,PRF,'the component along $N_a$ in $(\\delta f)(N_a, F^{\\sigma, s}_j)$ vanishes identically because $[N_a, \\mathfrak{g}_{\\bar{0}}] \\subseteq \\mathfrak{sp}(2n)$'),
        contradicts='Line 131 formula for (delta f)(N_a,F) contains the term -f([N_a,F]_0) = -sigma f(F) with f(F) in g_0 (stated at line 132 itself), whose N_a component is not shown to vanish; the argument at line 132 addresses only the first two terms. Also [N_a, g_0] is not claimed zero although so(2) commutes with g_0 (not checked by script).')],
     consistency_with_data='Not in g_summary.csv. own obstruction rank 4n (28->32 pattern), K dropped, kappa commuting: matches reference sign=none K=drop; class: match.',
     notes='Turns: turn1 report, turn2 reflection (no denial). '+('Final commit adds final_reflection.md and supplementary_metrics.md only.' if not first else 'First commit lacks reflection files.')+' final_reflection.md:22 mentions an exact SymPy method; its output is not stored as an artifact (it exists in the Worker log).')
    return d
add(b12('first (f775c71)',True)); d=b12('final (5e9bbb9)',False); d['deliverable_changes_first_to_final']='added final_reflection.md, supplementary_metrics.md; nothing under data, code, proofs changed.'; add(d)

# ---------------- b13 ----------------
r='b13'
add(dict(run='thm01-R-gemini37f-b13-C',commit_checked='final (5345d7a; first = final)',
 stated_conclusion=Q(r,PRF,'$$\\mathbf{gb} = 0.$$'),stated_conclusion_class='trivial iff gb=0',
 scope='n=1,2,3: table 6; general n: argued in 5.2 ("imposes contradictory requirements", lines 125-129) without explicit derivation.',
 declared_reading=dict(gb_parity=Q(r,PRF,'$4n$ parity-1 deformation parameters'),kappa_sign_handling=Q(r,PRF,'odd central parameter $\\kappa$ ($p(\\kappa)=1$)')+' ; verify_cn1.py compute_supercommutator carries no kappa sign => commuting.',
  K_treatment=Q(r,PRF,'acts as the zero derivation:')+' ; scalars sc are accumulated and not used (verify_cn1.py:196-219).'),
 test_range='joint: '+Q(r,'fast_verify.py','K_np = U_null.T @ B_np')+' (all gb columns; float64 SVD).',
 computation='verify_cn1.py (build_algebra, compute_supercommutator; main runs n=1,2 only), fast_verify.py (analyze_fast, n=1,2,3), generate_artifacts.py (writes verification_artifacts.json), analyze_system.py. Hard-coded in JSON: "H1_dim_odd": 0 and a "conclusion" string (generate_artifacts.py:19-23). No placeholders.',
 reported_numbers=Q(r,PRF,'| **$n=1$** | $C(2) = \\mathfrak{osp}(2\\|2)$ | 8 | 32 | **28** | 4 | 4 | **4** | $[3.0496, 3.0496, 3.0496, 3.0496]$ | **0** |')+' ; rerun prints identical singular values 3.0496/4.7272/5.9863. 28->32 pattern: matches reference sign=none K=drop.',
 rerun=dict(command='timeout 600 python3 fast_verify.py ; timeout 600 python3 generate_artifacts.py (separate copies)',exit_code='0 and 0',versions=VER,result='fast_verify.py only prints (no files): numerical rank of M 28/168/516, rank K 4/8/12, singular values equal those in the proof. generate_artifacts.py: verification_artifacts.json regenerated byte-identical.'),
 argument_issues=[dict(quote=Q(r,PRF,'= a^+ b_j^+ a^- b_j^- + a^- b_j^- a^+ b_j^+ = J + H_j.'),
   contradicts='The run own engine (verify_cn1.compute_supercommutator, n=1; checks/check_b08_b13_b06_claims.py) gives [F_+eps_+d, F_-eps_-d]_0 = -J + H_1; '+ORACLE+' agrees (H - J).'),
  dict(quote=Q(r,PRF,'\\kappa \\left( \\mathrm{gb}_{-, j, -} F_{+, j, +} - \\mathrm{gb}_{+, j, +} F_{-, j, -} \\right).'),
   contradicts='Run engine gives gamma(F_+eps_+d,F_-eps_-d) = -gb_{-,1,+} F_{+eps-d} - gb_{+,1,-} F_{-eps+d} (different basis elements and parameters).'),
  dict(quote=Q(r,PRF,'All structure constants, basis elements, 2-cocycles, and cohomology matrices have been generated and structured into machine-readable JSON artifacts'),
   contradicts='verification_artifacts.json per-case keys: n, algebra, superdimension, basis, deformation_parameters, cohomology_data, singular_values_K, non_zero_structure_constants_count, non_zero_gamma_entries_count: no structure constants, cocycle or matrices.')],
 consistency_with_data='Not in g_summary.csv. Ranks 28->32 pattern, K dropped, kappa commuting: matches reference sign=none K=drop; class: match.',
 notes='uncommitted: ?? __pycache__/. Cited verify_cn1.py main covers n=1,2 only while proof 6 says n=1,2,3 (n=3 is in fast_verify.py/generate_artifacts.py).'))

# ---------------- b14 ----------------
def b14(commit,first):
    r='b14'
    d=dict(run='thm01-R-gemini37f-b14-C',commit_checked=commit,
     stated_conclusion=Q(r,PRF,'is **trivial if and only if $\\mathrm{gb} = 0$**'),stated_conclusion_class='trivial iff gb=0',
     scope='n=1,2,3 RREF tables (5.1); general n: 4.3 asserts an "overdetermined system" (line 150), no derivation.',
     declared_reading=dict(gb_parity=Q(r,PRF,'$4n$ parity-1 parameters'),kappa_sign_handling=Q(r,PRF,'where $\\kappa$ is an odd central element ($p(\\kappa) = 1$, $\\kappa^2 = 0$)')+' ; scripts/solve_triviality.py:171-193 no sign for kappa => commuting.',
      K_treatment=Q(r,PRF,'any central scalar $\\mathbf{1}$ acts trivially')+' ; reduce_quadratic returns scalar which is ignored ("vec_out, _ =").'),
     test_range='joint: '+Q(r,'scripts/solve_triviality.py','M_aug = sp.Matrix.hstack(M_delta_sp, M_gamma_sp)')+' (RREF; pivots in gamma columns).',
     computation='scripts/solve_triviality.py (analyze_cn1_deformation, exact sympy rref), scripts/export_data.py (data/*.json), scripts/verify_cn1.py, scripts/verify_cocycle.py, scripts/test_bracket.py, scripts/inspect_details.py. Flags is_always_trivial / is_never_trivial_for_nonzero_gb are computed. No placeholders.',
     reported_numbers=Q(r,PRF,'| **$C(2) = \\mathfrak{osp}(2\\|2)$** | 8 (4 \\| 4) | 32 | 4 | **28** | 4 | **32** | **4** |')+' (matches reference sign=none K=drop 28->32, 168->176).',
     rerun=dict(command='timeout 600 python3 scripts/solve_triviality.py ; timeout 600 python3 scripts/export_data.py (separate copies)',exit_code='0 and 0',versions=VER,result='scripts/verification_results.json and data/cn1_data_n1,n2,n3.json regenerated byte-identical (7s, <1s).'+' Code identical in both commits.'),
     argument_issues=[dict(quote=Q(r,PRF,'$[E_{2\\delta_k}, E_{-2\\delta_k}]_0 = 2 h_k - \\frac{1}{2}\\mathbf{1}$'),
        contradicts='With E_{+-2d}=1/2(b+-)^2, h=b^+b^-+1/2 (lines 45-46): '+ORACLE+' gives [E_2d,E_-2d]_0 = -h (not 2h-1/2) and {a^+b^+, a^-b^-}_0 = h - Z (not Z + h + 1, same line 85).'),
       dict(quote=Q(r,PRF,'Y^2 = - \\mathrm{gb}_{\\sigma, j, s} \\kappa Y.'),
        contradicts='Line 60 states p(kappa)=1 and kappa central in the sense of docs/math/C_inhomogeneous_definition.md ("even/odd central elements"); with a odd, a kappa = -kappa a, so line 112 (kappa moved past odd a with no sign) is the kappa-commuting reading, not the stated odd one (reading-dependent).'),
       dict(quote=Q(r,PRF,'be the inhomogeneous deformation 2-cocycle'),
        contradicts='Own script scripts/verify_cocycle.py reported violations: turn1.jsonl.gz event 75 "Total 2-cocycle violations: 156"; event 81 "Total Jacobi violations at order kappa: 426" (corrected parity); not mentioned in the proof.')],
     consistency_with_data='Not in g_summary.csv. 28->32, K dropped, kappa commuting: matches reference sign=none K=drop; class: match.',
     notes='Turns: turn1 report, turn2 reflection. '+('Final commit adds final_reflection.md and supplementary_metrics.md only.' if not first else 'First commit lacks reflection files.'))
    return d
add(b14('first (d202ea3)',True)); d=b14('final (540ff32)',False); d['deliverable_changes_first_to_final']='added final_reflection.md, supplementary_metrics.md; nothing under data, scripts, docs changed.'; add(d)

# ---------------- b15 ----------------
r='b15'
add(dict(run='thm01-R-gemini37f-b15-C',commit_checked='final (a9e4373; first = final)',
 stated_conclusion=Q(r,PRF,'**if and only if all deformation parameters vanish identically**'),stated_conclusion_class='trivial iff gb=0',
 scope='n=1,2,3 (4); general n: Step 3 "By the discrete Dynkin/oscillator automorphisms ... an isomorphic subsystem" (line 144) generalizes the single-parameter derivation at n general, j general.',
 declared_reading=dict(gb_parity='not stated (line 54 "odd exchange relations ... parameterized by the matrix gb").',kappa_sign_handling=Q(r,PRF,'$\\kappa$ is an odd central parameter ($p(\\kappa) = 1$, $\\kappa^2 = 0$)')+' ; algebra_engine.py:171-192 no kappa sign => commuting.',
  K_treatment=Q(r,PRF,'any central terms appearing in the product of oscillators vanish identically in the adjoint representation')+' ; '+Q(r,'algebra_engine.py','Scalars/central terms are dropped for adjoint rep')),
 test_range='joint: '+Q(r,'solve_triviality.py','sol_all = sp.solve(equations, all_vars, dict=True)')+' with gb and phi unknown together; plus the hand derivation for one parameter j (Eq.1-5).',
 computation='algebra_engine.py (get_basis, compute_supercommutator_bracket), solve_triviality.py (analyze_triviality, exact sp.solve), generate_artifacts.py (artifacts/*.json); calc_commutator.py, inspect_diagonal.py, inspect_gamma.py, minimal_proof.py, test_algebra.py, verify_basis.py. Hard-coded: '+Q(r,'generate_artifacts.py','"is_unconditionally_trivial": False,')+' and the strings triviality_condition / cohomology_conclusion; gb_constraints are computed.',
 reported_numbers=Q(r,PRF,'| $n = 1$ | $C(2) = \\mathfrak{osp}(2\\|2)$ | $4 \\mid 4$ ($8$) | 4 | 32 | 112 | $\\mathbf{gb} \\equiv \\mathbf{0}$ |')+' (equation counts equal artifacts: 112/1400/6960). No ranks reported; joint solve gives gb=0 (28->32 pattern: matches reference sign=none K=drop).',
 rerun=dict(command='timeout 600 python3 solve_triviality.py ; timeout 600 python3 generate_artifacts.py (separate copies)',exit_code='0 and 0',versions=VER,result='solve_triviality.py only prints (no files; "NO SOLUTION for arbitrary gb" then joint solution gb=0 for n=1,2,3, equations 112/1400/6960, 33s). generate_artifacts.py: artifacts/verification_C2,C3,C4.json and verification_summary.json regenerated byte-identical.'),
 argument_issues=[dict(quote=Q(r,PRF,'Each artifact contains full basis specifications, structure constants, deformed bracket matrices'),
   contradicts='artifacts/verification_C*.json keys: algebra, n, superdimension, basis, gb_parameter_count, gb_parameters, phi_parameter_count, equation_count, triviality_result, sample_structure_constants (first 15 pairs), sample_gamma_brackets (first 15): no full structure constants, no coboundary evaluations.')],
 consistency_with_data='Not in g_summary.csv. Data gb=0 forced, K dropped, kappa commuting: matches reference sign=none K=drop; class: match. Eq.1-4 (proof 101-128) and the gamma values quoted there agree with the run own engine and are consequences of its full system (agent computation using the run engine, checks/check_b15_equations.py, n=1,j=1): rows match.',
 notes='uncommitted: ?? __pycache__/. Step 3 (generalization to all parameters/n by automorphisms) was not checked by script.'))

with open(OUT,'w') as f:
    for r in recs: f.write(json.dumps(r,ensure_ascii=False)+'\n')
print(len(recs),'records written')
