# Agent computation (extractor): check hand-algebra claims in b12, b13, b14 proofs using an explicit
# representation: fermions a+=[[0,1],[0,0]], a-=[[0,0],[1,0]] (2x2, {a+,a-}=1), bosons b+=x*, b-=d/dx on polynomials.
# Operators act on 2-component vectors (f(x), g(x)) of sympy expressions. Undeformed (kappa=0) algebra only.
import sympy as sp
x = sp.symbols('x')
f = sp.Function('f')(x); g = sp.Function('g')(x)
V = sp.Matrix([f, g])
def Aplus(v):  return sp.Matrix([v[1], 0])
def Aminus(v): return sp.Matrix([0, v[0]])
def Bplus(v):  return v*x
def Bminus(v): return v.applyfunc(lambda e: sp.diff(e, x))
ops = {'a+':Aplus,'a-':Aminus,'b+':Bplus,'b-':Bminus}
def op(*names):  # product, rightmost acts first
    def run(v):
        for n in reversed(names): v = ops[n](v)
        return v
    return run
def lin(*terms):  # terms: (coeff, op)
    return lambda v: sum((c*o(v) for c,o in terms), sp.zeros(2,1))
I = lambda v: v
def comb(A,B,sgn): return lambda v: A(B(v)) + sgn*B(A(v))   # sgn=-1 commutator, +1 anticommutator
def eq(A,B): return sp.simplify(A(V)-B(V)) == sp.zeros(2,1)
half = sp.Rational(1,2)
N  = lin((1,op('a+','a-')),(-half,I))            # J / N_a = a+a- - 1/2
H  = lin((1,op('b+','b-')),(half,I))             # h/H = b+b- + 1/2
Fpp = op('a+','b+'); Fmm = op('a-','b-'); Fp = op('a+','b+')
res = {}
# b12:129 claim [N_a, a^sigma b] = sigma*(1/2) a^sigma b
res['b12 [N_a,F++] = +1*F++'] = eq(comb(N,Fpp,-1), Fpp)
res['b12 [N_a,F++] = +1/2*F++ (claimed sigma/2)'] = eq(comb(N,Fpp,-1), lin((half,Fpp)))
res['b12 [N_a,F-+] = -1*F-+'] = eq(comb(N,op('a-','b+'),-1), lin((-1,op('a-','b+'))))
# b13:119 claim {F++,F--}_0 = J + H_j ; computed alternative H - J
anti = comb(Fpp,Fmm,+1)
res['b13 {F++,F--} = J + H (claimed)'] = eq(anti, lin((1,N),(1,H)))
res['b13 {F++,F--} = H - J'] = eq(anti, lin((1,H),(-1,N)))
# b14:85 claims
E2p = lin((half,op('b+','b+'))); E2m = lin((half,op('b-','b-')))
res['b14 [E2d,E-2d] = 2h - 1/2 (claimed)'] = eq(comb(E2p,E2m,-1), lin((2,H),(-half,I)))
res['b14 [E2d,E-2d] = -h'] = eq(comb(E2p,E2m,-1), lin((-1,H)))
res['b14 {F++,F--} = Z + h + 1 (claimed)'] = eq(anti, lin((1,N),(1,H),(1,I)))
res['b14 {F++,F--} = h - Z'] = eq(anti, lin((1,H),(-1,N)))
for k,v in res.items(): print(v, '|', k)
# b08 proof lines 141,147: [w,E_{+-2delta}]_0 for w in span of odd generators (explicit representation)
Fpm = op('a+','b-'); Fmm_=op('a-','b-'); Fmp=op('a-','b+')
res2 = {}
res2['[a+b-, E2d] = +a+b+  (engine sign; proof line 141 has minus)'] = eq(comb(Fpm,E2p,-1), Fpp)
res2['[a+b+, E-2d] = -a+b- (engine sign; proof line 147 has plus)'] = eq(comb(Fpp,E2m,-1), lin((-1,Fpm)))
for k,v in res2.items(): print(v,'|',k)
