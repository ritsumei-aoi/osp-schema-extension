# Agent computation (extractor): compare regenerated files in a scratch rerun dir with the committed copy.
import sys, os, json, filecmp
orig, new = sys.argv[1], sys.argv[2]
def walk(d):
    out=[]
    for r,ds,fs in os.walk(d):
        ds[:] = [x for x in ds if x not in ('.git',)]
        for f in fs: out.append(os.path.relpath(os.path.join(r,f), d))
    return sorted(out)
def diffs(a,b,path=''):
    if type(a)!=type(b): yield (path,'type'); return
    if isinstance(a,dict):
        for k in sorted(set(a)|set(b), key=str):
            if k not in a or k not in b: yield (path+'/'+str(k),'missing'); continue
            yield from diffs(a[k],b[k],path+'/'+str(k))
    elif isinstance(a,list):
        if len(a)!=len(b): yield (path,'len %d vs %d'%(len(a),len(b))); return
        for i,(x,y) in enumerate(zip(a,b)): yield from diffs(x,y,path+'[%d]'%i)
    else:
        if a!=b:
            if isinstance(a,float) and isinstance(b,float) and abs(a-b)<1e-9: yield (path,'float within 1e-9'); return
            yield (path,'%r vs %r'%(a,b))
fo, fn = walk(orig), walk(new)
print('only in committed:', [f for f in fo if f not in fn and not f.endswith('.pyc')])
print('only in rerun:', [f for f in fn if f not in fo and not f.endswith('.pyc')])
for f in fo:
    if f in fn and not f.endswith('.pyc'):
        p1,p2=os.path.join(orig,f),os.path.join(new,f)
        if not filecmp.cmp(p1,p2,shallow=False):
            if f.endswith('.json'):
                try:
                    d=list(diffs(json.load(open(p1)),json.load(open(p2))))
                    print('DIFF json',f,'n_diffs',len(d),d[:6])
                except Exception as e: print('DIFF json',f,'error',e)
            else: print('DIFF (non-json)',f)
        else:
            if f.endswith('.json') or f.endswith('.out'): print('identical bytes',f)
