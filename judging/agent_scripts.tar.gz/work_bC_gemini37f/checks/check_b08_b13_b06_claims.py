# Agent computation (extractor): compare proof statements with each run's own engine / data (n=1 unless noted).
import sys, json, sympy as sp
# ---- b08: proof lines 132-136 (gamma(H0, .)), 141,147,154 ([w,Y]_0) ----
sys.path.insert(0,'thm01-R-gemini37f-b08-C-final/verification')
from verify_c_algebra import get_algebra
be,names,par,gbs,S,G=get_algebra(1)
g=lambda s,s2: gbs[(s,1,s2)]
print('b08 names',names)
print('b08 gamma(H_0,E_+2d1)=',G[('H_0','E_+2d1')])
print('b08 gamma(H_0,E_-2d1)=',G[('H_0','E_-2d1')])
print('b08 gamma(H_0,h_1)   =',G[('H_0','h_1')])
c={n_:sp.Symbol('c_'+n_) for n_ in ['E_+e+d1','E_+e-d1','E_-e+d1','E_-e-d1']}
def wbr(Y):
    out={}
    for fn,cc in c.items():
        for k,v in S[(fn,Y)].items(): out[k]=out.get(k,0)+cc*v
    return {k:sp.simplify(v) for k,v in out.items() if sp.simplify(v)!=0}
for Y in ['E_+2d1','E_-2d1','h_1']: print('b08 [w,%s]_0 ='%Y, wbr(Y))
# ---- b13: proof line 121: gamma({F++,F--}) ----
sys.path.insert(0,'thm01-R-gemini37f-b13-C-final')
import verify_cn1 as v13
bas=v13.build_algebra(1); bd={b[0]:b for b in bas}
gv={(a,1,s):sp.Symbol(f'gb_{a}_1_{s}') for a in '+-' for s in '+-'}
b0,g1,_,_=v13.compute_supercommutator(bd['F_+eps_+d_1'],bd['F_-eps_-d_1'],gv,bd,1)
print('b13 [F_+eps_+d,F_-eps_-d]_0 =',{k:v for k,v in b0.items() if v!=0})
print('b13 gamma(F_+eps_+d,F_-eps_-d) =',{k:v for k,v in g1.items() if v!=0})
# ---- b06: proof line 110 gamma(F_{+,j,s},F_{+,k,s'}) vs artifacts_verification.json (n=1,2) ----
d=json.load(open('thm01-R-gemini37f-b06-C-final/artifacts_verification.json'))
gg=d['n=1']['gamma_gb']
for key in ['gamma(F_+_1+,F_+_1+)','gamma(F_+_1+,F_+_1-)','gamma(F_+_1-,F_+_1+)']:
    print('b06',key,gg.get(key))
gg2=d['n=2']['gamma_gb']
print('b06 n=2 gamma(F_+_1+,F_+_2-)',gg2.get('gamma(F_+_1+,F_+_2-)'))
