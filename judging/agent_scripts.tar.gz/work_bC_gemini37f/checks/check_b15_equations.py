# Agent computation (extractor): compare the hand-derived equations Eq.1-Eq.4 and the gamma values in
# thm01-R-gemini37f-b15-C docs/issues/mathematical_proof.md (lines 101-128) with the run's own engine
# (algebra_engine.py, copied to scratch). n=1, j=1. Prints actual rows of (delta f - gamma)(X,Y)_k = 0.
import sys, sympy as sp
sys.path.insert(0, 'thm01-R-gemini37f-b15-C-final')
from algebra_engine import get_basis, compute_supercommutator_bracket
n=1
basis=get_basis(n); names=[b[0] for b in basis]; dim=len(basis)
idx={nm:i for i,nm in enumerate(names)}
gb={}
for s_ in '+-':
    for s in '+-':
        gb[(s_,1,s)]=sp.Symbol(f'gb_{s_}_1_{s}')
ev=[i for i,b in enumerate(basis) if b[1]==0]; od=[i for i,b in enumerate(basis) if b[1]==1]
phi={}
for j in ev:
    for i in od: phi[(i,j)]=sp.Symbol(f'phi[{names[i]}<-{names[j]}]')
for j in od:
    for i in ev: phi[(i,j)]=sp.Symbol(f'phi[{names[i]}<-{names[j]}]')
tab={}; gam={}
for i in range(dim):
    for j in range(dim):
        tab[(i,j)],gam[(i,j)]=compute_supercommutator_bracket(basis[i],basis[j],names,gb)
def Xf(i,j):
    res={k:0 for k in range(dim)}
    for k in (od if basis[j][1]==0 else ev):
        for bn,c in tab[(i,k)].items(): res[idx[bn]]+=phi[(k,j)]*c
    return res
def fX(i,j):
    res={k:0 for k in range(dim)}
    for bn,c in tab[(i,j)].items():
        m=idx[bn]
        for k in (od if basis[m][1]==0 else ev): res[k]+=c*phi[(k,m)]
    return res
def row(X,Y,K):
    i,j,k=idx[X],idx[Y],idx[K]
    px,py=basis[i][1],basis[j][1]
    a=Xf(i,j)[k]; b=Xf(j,i)[k]; c=fX(i,j)[k]
    d=(-1)**px*a-(-1)**((px+1)*py)*b-c
    return sp.expand(d-gam[(i,j)].get(K,0))
print('names',names)
print('[F++,F-+]_0 =',tab[(idx['F_a+_b1+'],idx['F_a-_b1+'])])
print('gamma(F++,F++) =',gam[(idx['F_a+_b1+'],idx['F_a+_b1+'])])
print('gamma(E++,F++) =',gam[(idx['E_bp_1_bp_1'],idx['F_a+_b1+'])])
print('gamma(J0,E++)  =',gam[(idx['J0'],idx['E_bp_1_bp_1'])])
print('gamma(F++,F-+) =',gam[(idx['F_a+_b1+'],idx['F_a-_b1+'])])
print('ROW (F++,F++) comp F++:', row('F_a+_b1+','F_a+_b1+','F_a+_b1+'))
print('ROW (E++,F++) comp E++:', row('E_bp_1_bp_1','F_a+_b1+','E_bp_1_bp_1'))
print('ROW (J0,E++) comp F-+:', row('J0','E_bp_1_bp_1','F_a-_b1+'))
print('ROW (F++,F-+) comp F-+:', row('F_a+_b1+','F_a-_b1+','F_a-_b1+'))
# Is each claimed equation a consequence of the full system?  Build full system and test with sympy.
eqs=[]
for i in range(dim):
    for j in range(i,dim):
        for k in range(dim):
            r=row(names[i],names[j],names[k])
            if r!=0: eqs.append(r)
allv=list(phi.values())+list(gb.values())
M,_=sp.linear_eq_to_matrix(eqs,allv)
print('system rows',len(eqs),'rank',M.rank())
def in_rowspace(vec):
    return sp.Matrix.vstack(M,vec.T).rank()==M.rank()
phi_=lambda a,b: phi[(idx[a],idx[b])]
claims={
 'Eq1: phi[J0<-F++]+phi[E+-<-F++] = -gb+1+': phi_('J0','F_a+_b1+')+phi_('E_bp_1_bm_1','F_a+_b1+')+gb[('+',1,'+')],
 'Eq2: 2phi[E+-<-F++]-phi[F-+<-E++] = 2gb+1+': 2*phi_('E_bp_1_bm_1','F_a+_b1+')-phi_('F_a-_b1+','E_bp_1_bp_1')-2*gb[('+',1,'+')],
 'Eq3: 2phi[F--<-J0]-phi[F-+<-E++] = 2gb+1+': 2*phi_('F_a-_b1-','J0')-phi_('F_a-_b1+','E_bp_1_bp_1')-2*gb[('+',1,'+')],
 'Eq4: phi[E+-<-F++]-phi[J0<-F++]-phi[F-+<-E++] = -gb+1+': phi_('E_bp_1_bm_1','F_a+_b1+')-phi_('J0','F_a+_b1+')-phi_('F_a-_b1+','E_bp_1_bp_1')+gb[('+',1,'+')],
}
for nm,e in claims.items():
    v=sp.Matrix([sp.Poly(e,*allv).coeff_monomial(a) for a in allv])
    print('in row space of system:',in_rowspace(v),'|',nm)
