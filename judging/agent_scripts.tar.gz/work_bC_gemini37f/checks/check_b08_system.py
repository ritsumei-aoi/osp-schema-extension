# Agent computation (extractor): in b08's own engine (n=1), solve the sub-system used in proof Steps 3-5:
# [w,Y]_0 = gamma(H_0,Y) for Y in {E_+2d1, E_-2d1, h_1}, unknown w = sum c_i F_i, unknown gb.
import sys, sympy as sp
sys.path.insert(0,'thm01-R-gemini37f-b08-C-final/verification')
from verify_c_algebra import get_algebra
be,names,par,gbs,S,G=get_algebra(1)
F=['E_+e+d1','E_+e-d1','E_-e+d1','E_-e-d1']
c={f:sp.Symbol('c_'+f) for f in F}
eqs=[]
for Y in ['E_+2d1','E_-2d1','h_1']:
    lhs={}
    for f in F:
        for k,v in S[(f,Y)].items(): lhs[k]=lhs.get(k,0)+c[f]*v
    for k in set(lhs)|set(G[('H_0',Y)]):
        eqs.append(sp.simplify(lhs.get(k,0)-G[('H_0',Y)].get(k,0)))
unk=list(c.values())
sol=sp.solve(eqs,unk,dict=True)
print('equations',eqs)
print('solution for c in terms of gb (gb free):',sol)
gbl=list(gbs.values())
print('gb forced to zero by this subsystem alone?', sp.solve(eqs,unk+gbl,dict=True))
