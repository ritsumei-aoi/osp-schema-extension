#!/bin/bash
# usage: runit.sh <dir> <script> <logname>
cd "$1" || exit 99
s=$(date +%s)
timeout 600 python3 "$2" > "../logs/$3.out" 2>&1
e=$?
echo "EXIT $e ELAPSED $(( $(date +%s)-s ))s" >> "../logs/$3.out"
