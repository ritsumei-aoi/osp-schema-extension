import json,sys
data=json.load(open(sys.argv[1]))
for k,(a,b) in {'C(2)':(28,32),'C(3)':(168,176),'C(4)':(516,528)}.items():
    t=data[k]['triviality']
    print(k, t['all_trivial'], t['rank_delta'], t['rank_delta_plus_gamma'], (t['all_trivial']==False and t['rank_delta']==a and t['rank_delta_plus_gamma']==b))
