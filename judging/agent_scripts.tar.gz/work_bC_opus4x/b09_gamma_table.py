import sys; sys.path.insert(0,'opus46-b09')
import numpy as np
import verify_triviality as v
names,par,sc=v.build_osp22()
g=v.compute_gamma(sc,par,np.array([1.,0,0,0]))
for a,b in [(0,4),(1,4),(2,4),(4,4),(0,1),(0,2)]:
    print(f"gamma({names[a]},{names[b]}) =", {names[k]:float(c) for k,c in enumerate(g[a,b]) if abs(c)>1e-12})
