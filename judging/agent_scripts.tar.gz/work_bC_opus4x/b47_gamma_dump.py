import sys; sys.path.insert(0,'opus47-b01/artifacts')
import verify_C_triviality as v
basis, gb, structure, gamma = v.compute_gamma(1)
names=[b[0] for b in basis]; par=[b[1] for b in basis]
print(names)
for i in range(len(names)):
    for j in range(i,len(names)):
        if par[i]==1 and par[j]==1:
            vec=gamma[i][j]
            print(f"gamma({names[i]},{names[j]}) =", {names[k]:str(c) for k,c in enumerate(vec) if c!=0}, "| struct:", {names[k]:str(c) for k,c in enumerate(structure[i][j]) if c!=0})
for i in range(len(names)):
    for j in range(len(names)):
        if par[i]==0 and par[j]==0 and any(c!=0 for c in gamma[i][j]):
            print(f"even-even gamma({names[i]},{names[j]}) =", {names[k]:str(c) for k,c in enumerate(gamma[i][j]) if c!=0})
