import json, sys
for r in json.load(open(sys.argv[1])):
    print('====', r['run'], 'n=%d' % r['n'])
    if 'error' in r: print('  ERROR', r['error']); continue
    s = r['structure_constants_vs_realization']; print('  sc_vs_real:', s['rel'], '%d/%d' % (s['match'], s['ref']), 'miss', s['missing'], 'extra', s['extra'], 'differ', s['differ'])
    print('  gamma:', r['gamma_file'], 'pairs', r.get('gamma_pairs_recorded'), 'nonK', r.get('gamma_entries_nonK'), 'K', r.get('gamma_entries_K'), 'conf', r.get('gamma_antisym_conflicts'))
    for k, v in r['gamma_cmp'].items():
        t = v['total']; print('   %-10s %-30s m %d/%d miss %d extra %d diff %d (neg %d) worker %d' % (k, v['relations'], t['match'], t['ref'], t['missing'], t['extra'], t['differ'], t['differ_negated'], t['worker']))
    print('  cob:', r['coboundary_file'], 'cols', r.get('coboundary_phi_columns'), 'Krows', r.get('coboundary_K_rows'), 'conf', r.get('coboundary_antisym_conflicts'))
    if 'coboundary_columns_vs_independent' in r: print('   vs indep', r['coboundary_columns_vs_independent'])
    for k, v in r['rank'].items():
        if 'rankA' in v: print('   rank %-28s A=%d [A|G]=%d G=%d triv %d/%d cols %d' % (k, v['rankA'], v['rankAG'], v['rankG'], v['n_dirs_trivial'], len(v['per_direction_increase']), v['n_cols']))
        else: print('   rank %-28s %s' % (k, v))
