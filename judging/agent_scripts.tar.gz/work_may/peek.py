import json, sys
def show(o, p='', depth=0, maxd=6):
    if isinstance(o, dict):
        for k, v in o.items():
            if isinstance(v, (dict, list)):
                print('  '*depth + f'{p}.{k}: {type(v).__name__}[{len(v)}]')
                if depth < maxd: show(v, p+'.'+k, depth+1)
            else:
                s = json.dumps(v); print('  '*depth + f'{p}.{k} = {s[:150]}')
    elif isinstance(o, list):
        if o:
            print('  '*depth + f'{p}[0] = {json.dumps(o[0])[:400]}')
            if len(o) > 1: print('  '*depth + f'{p}[1] = {json.dumps(o[1])[:400]}')
            if isinstance(o[0], (dict,)) and depth < maxd and not any(k in o[0] for k in ('X','Y')):
                show(o[0], p+'[0]', depth+1)
show(json.load(open(sys.argv[1])))
