import json
R="../jroot/final/thm01-R-gemini38f-b08-G"
g=json.load(open(f"{R}/data/C_1_gamma.json")); par=g["parity"]
ee=[t for t in g["inhomogeneous_deformation"]["gamma_terms"] if par[t["X"]]==0 and par[t["Y"]]==0]
for t in ee: print(t["X"],t["Y"],'->',t["Z"],t["param"],t["coeff"])
print('H_2 with E_2del1_m entries:',[t for t in ee if {t["X"],t["Y"]}=={"H_2","E_2del1_m"}])
e=json.load(open(f"{R}/data/C_1_evaluated.json"))
print(list(e)); 
ev=[t for t in e["evaluated_gamma"]["terms"] if {t["X"],t["Y"]}=={"H_2","E_2del1_m"}]
print('evaluated H_2,E_2del1_m',ev)
