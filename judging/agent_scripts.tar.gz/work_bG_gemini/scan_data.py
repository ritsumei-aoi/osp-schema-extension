import json,sys,glob,os
root=sys.argv[1]
def walk(o,acc):
    if isinstance(o,dict):
        for k,v in o.items():
            if k in('Z','target') and v in('K','kappa'): acc[v]=acc.get(v,0)+1
            walk(v,acc)
    elif isinstance(o,list):
        for v in o: walk(v,acc)
for r in sorted(glob.glob(root+'/thm01-R-gemini*-G')):
    out=[]
    for n in (1,2,3):
        for kind in ('gamma','coboundary','structure','evaluated'):
            for f in glob.glob(f'{r}/data/C_{n}_{kind}*.json'):
                try: d=json.load(open(f))
                except Exception as e: out.append((os.path.basename(f),'ERR')); continue
                acc={};walk(d,acc)
                out.append((os.path.basename(f),acc))
    print(os.path.basename(r)); print('  ',[o for o in out if o[1]])
