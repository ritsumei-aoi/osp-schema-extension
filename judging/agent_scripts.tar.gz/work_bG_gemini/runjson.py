import json,sys
B="<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/runs/batch/"
for run in sys.argv[1:]:
    r=json.load(open(B+run+"/run.json"))
    print(run,r['status'],'turns',[(t['turn'],t['seconds'],t.get('timed_out'),t.get('is_error')) for t in r['turns']],'fixed',r['fixed_replies'],'denial',r['denial_replies'],'unc',r['uncommitted'],'ncommits',len(r['commits']),'search',r['search_web'],'outside',r['outside_refs'])
    for d in r['denied']: print('   denied',d['log'],d['tool'],d['input'][:100].replace('\n',' '))
