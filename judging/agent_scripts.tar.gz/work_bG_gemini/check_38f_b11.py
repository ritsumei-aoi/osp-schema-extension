import json
R="../jroot/final/thm01-R-gemini38f-b11-G"
g=json.load(open(f"{R}/data/C_1_gamma.json"))
for t in g["gamma_coefficients"]:
    if (t["X"],t["Y"]) in (("H_1","H_2"),("H_1","E_eps1_del1_pp")): print(t)
