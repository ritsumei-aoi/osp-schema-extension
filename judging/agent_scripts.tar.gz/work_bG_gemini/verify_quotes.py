import json,glob,os,re,sys
JR="/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final"
bad=0
def walk(o,run,path=""):
    global bad
    if isinstance(o,dict):
        if 'quote' in o and 'loc' in o and isinstance(o['quote'],str):
            loc=o['loc']
            m=re.match(r'^(.*?):(\d+)(?:-\d+)?$',loc)
            if not m: print(run,'BADLOC',loc); bad+=1; return
            f=f"{JR}/{run}/{m.group(1)}"
            if not os.path.exists(f): print(run,'NOFILE',loc); bad+=1; return
            lines=open(f,errors='replace').read().split('\n')
            ln=int(m.group(2))
            win=' '.join(lines[max(0,ln-2):ln+4])
            norm=lambda s:re.sub(r'\s+',' ',s)
            for part in o['quote'].split('...'):
                part=part.strip()
                if part and norm(part) not in norm(win):
                    print(run,'MISMATCH',loc,repr(part[:80])); bad+=1
        for k,v in o.items(): walk(v,run)
    elif isinstance(o,list):
        for v in o: walk(v,run)
for f in sorted(glob.glob(os.path.dirname(os.path.abspath(__file__))+'/recs/*.json')):
    d=json.load(open(f)); walk(d,d['run'])
print('bad',bad)
