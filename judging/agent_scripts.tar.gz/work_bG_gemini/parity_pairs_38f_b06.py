import json,collections
R="../jroot/final/thm01-R-gemini38f-b06-G"
for n in (1,2,3):
    g=json.load(open(f"{R}/data/C_{n}_gamma.json"))
    par=g["parity"]; c=collections.Counter()
    for t in g["inhomogeneous_deformation"]["gamma_coefficients"]:
        c[(par[t["X"]],par[t["Y"]])]+=1
    print(n,dict(c))
