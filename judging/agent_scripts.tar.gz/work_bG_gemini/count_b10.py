import json,sys
R=sys.argv[1]
for n in (1,2,3):
    e=json.load(open(f'{R}/data/C_{n}_evaluated.json')); c=json.load(open(f'{R}/data/C_{n}_coboundary.json')); g=json.load(open(f'{R}/data/C_{n}_gamma.json'))
    print(n,'evaluated entries',len(e['evaluated_deformation']),'gamma entries',len(g['inhomogeneous_deformation']['gamma_constants']),'phi params',len(c['linear_map_f']['parameters']),'coboundary keys',[ (k,len(v) if isinstance(v,(list,dict)) else v) for k,v in c.items()])
