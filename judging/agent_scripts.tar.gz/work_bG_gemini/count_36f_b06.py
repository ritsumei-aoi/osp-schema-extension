import json
R="../jroot/final/thm01-R-gemini36f-b06-G"
for n in (1,2,3):
    c=json.load(open(f"{R}/data/C_{n}_coboundary.json"))
    print(n,'map_parameters',len(c["coboundary_structure"]["map_parameters"]),'coboundary terms',len(c["coboundary_structure"]["coboundary_coefficients"]))
