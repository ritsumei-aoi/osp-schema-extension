import json
R="../jroot/final/thm01-R-gemini37f-b07-G"
tot=0
for n in (1,2,3):
    g=json.load(open(f"{R}/data/C_{n}_gamma.json"))
    k=len(g["inhomogeneous_deformation"]["gamma_structure"]); tot+=k
    print(n,'gamma entries',k)
print('total',tot)
