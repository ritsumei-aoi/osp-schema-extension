import json,os
D=os.path.dirname(os.path.abspath(__file__))
def save(d):
    json.dump(d,open(f"{D}/recs/{d['run']}.json",'w'),ensure_ascii=False,indent=1)
def q(quote,loc): return {"quote":quote,"loc":loc}
def qn(quote,loc,note): return {"quote":quote,"loc":loc,"note":note}
