#!/bin/bash
r=$1; cd /private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/$r
echo "######## $r I08 response"
s=$(grep -n -m1 -E "^#+ *Response" docs/issues/I08.md | cut -d: -f1); [ -z "$s" ] && s=1
awk -v s=$s 'NR>=s{printf "%d: %s\n",NR,substr($0,1,420)}' docs/issues/I08.md
echo "######## reading statements I03-I07"
grep -n -i -E "parity|odd|even |supercomm|scalar|\bK\b|sign" docs/issues/I0[3-7].md | grep -v -E ":- \[" | cut -c1-260 | head -${2:-25}
