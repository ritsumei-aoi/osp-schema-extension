# numbers copied from thm01-R-gemini36f-b02-G docs/issues/I08.md:42-44 (eqs, rank M)
for n,(eqs,rk) in {1:(288,28),2:(3610,168),3:(20230,516)}.items(): print(n,'left-kernel dim = eqs - rank =',eqs-rk)
print(512+6859+39304)
