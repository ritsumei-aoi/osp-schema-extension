import json, sys
sys.path.insert(0, "/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_interactive_facts")
from lib import q, loc

rows = []
def L(R, rel, phrase):
    return loc(R, rel, phrase).split(":")[1]

# ------------------------------------------------------------ sonnet46-A (A2)
R = "thm01-R-sonnet46-A"
I08 = "docs/issues/done/issue_261006_08.md"
FR = "docs/issues/final_reflection.md"
rows.append({
 "run": R, "commit_checked": "final (339aa4a)",
 "stated_conclusion": q(R, I08, "**Conclusion**: The gb-deformation of $C(n+1)$ is never trivial", "Conclusion: The gb-deformation of C(n+1) is never trivial for any nonzero choice of parameters. The necessary and sufficient condition for triviality is gb = 0 (no deformation). This is confirmed for n = 1, 2, 3 and conjectured to hold for all n >= 1."),
 "stated_conclusion_class": "trivial iff gb=0",
 "scope": {"n123": q(R, I08, "**Evidence**: Confirmed for $n = 1, 2, 3$ by two independent methods", "Confirmed for n = 1, 2, 3 by two independent methods: 1. Symbolic K-obstruction analysis ... 2. Full linear algebra: rank(U_perp^T B) = 4n = n_gb in all cases"),
           "general_n": q(R, I08, "**Predicted pattern") if False else q(R, I08, "### 8. Structural Pattern (toward general n)", "Structural Pattern (toward general n): K-term count approximately quadratic (11, 43, 91), g-obstruction count linear (2n)")},
 "declared_reading": {"a_parity_gb": "not stated",
                      "b_sign_handling": "data/C_1_gamma.json sign_convention 'Option_A', defining_relation '[bj^s, a1^sigma] = -gb_{sigma,j,s} * kappa'; no statement on kappa commuting signs",
                      "c_K": q(R, I08, "where $K$ is the even central element from the extended algebra", "K is the even central element from the extended algebra A = V + CK + Ck. ... Therefore the coboundary ... has zero K-component for all X, Y. Thus any K-component of gamma cannot be matched by delta f")},
 "test_range": {"summary": "Joint over all gb: (i) K-components, every gb appears in some K entry (counts 11/43/91); (ii) g-component system: rank(U_perp^T B) = 4n over the full 4n-column gamma map (covers all combinations); (iii) gb=+1 profile: rank A = 28 < rank [A|b] = 29.",
                "evidence": q(R, I08, "Let $B$ be the matrix mapping gb-vector to", "Let B be the matrix mapping gb-vector to gamma_g (g-components of gamma), and A the coboundary matrix ... The condition gamma_g in Im(A) for a given gb requires (I - A A^+) B gb = 0")},
 "computation": {"code": ["src/build_C_gamma.py (gamma)", "src/build_C_coboundary.py (delta f)", "src/build_C_evaluated.py", "src/build_C_structure_constants.py", "src/verify_C_structure.py"],
                 "rank_computation": "No committed triviality script (src/ has no C_triviality); the ranks in I08 have no committed code.",
                 "evidence": q(R, FR, "For each computational claim I wrote Python scripts", "For each computational claim I wrote Python scripts that enumerate structure constants and check algebraic identities symbolically over Z (no floating point)"),
                 "hardcoded_or_placeholder": "none found in src"},
 "reported_numbers": {"reported": "rank(A) 28/168/516; phi 32/176/528; rank(U_perp^T B) 4/8/12; K terms 11/43/91; gb=1: rank A 28 < rank [A|b] 29 (I08 sections 2, 4, 5)",
                      "vs_reference": "rank(A) equals reference. K-term counts 11/43/91 equal the number of Z='K' entries in data/C_n_gamma.json (checked, n=1,2,3).",
                      "vs_g_summary": "g_summary non-K and K-kept: 28->32 (0/4 dirs trivial) n=1, 168->176 n=2: consistent with rank(U_perp^T B)=4n for the non-K part. rank [A|b]=29 for a single profile is not in g_summary (not checked)."},
 "argument_issues": [
   {"quote": "(E^-_{eps-delta_1}, H_1, H_2): -2 gb_{mp1} ; (E^+_{-eps+delta_1}, H_1, H_2): -2 gb_{pm1}", "loc": loc(R, I08, "| $(E_{\\varepsilon-\\delta_1}^-, H_1, H_2)$"),
    "contradicts": "(a/c) data/C_1_gamma.json has X=E_eps1_del1_pm, Y=H_1, Z=H_2 with gb_key gb_pm_1 (coeff -2) and X=E_eps1_del1_mp with gb_mp_1; and the same report line " + L(R, I08, "| $(E_{\\varepsilon-\\delta_1}^-, H_1)$") + " pairs E^-_{eps-delta_1} (= E_pm) with gb_{+,1,-}. The two gb names in the Cartan-mixing table are swapped relative to the data. (The data also contain a third (E_pp, H_1, H_2) = -2 gb_pp entry, which is present in the coboundary support and not listed.)"},
   {"quote": q(R, I08, "**Interpretation**: The gb deformation corresponds to non-trivial elements", "The gb deformation corresponds to non-trivial elements of the second Lie superalgebra cohomology H^2(g, M), where M is the extended module containing the central element K.")["quote"], "loc": loc(R, I08, "**Interpretation**: The gb deformation corresponds"),
    "contradicts": "(a/b) M is not defined in docs/math and no cohomology computation exists in the run (no cocycle check, no code)."},
   {"quote": q(R, I08, "**Mathematical reason**: The Cartan subalgebra structure", "(delta f)(E_{eps +- delta_j}, H_1) unable to produce off-diagonal Cartan components H_k for k >= 2. ... do not mix in the image of delta f for these generator pairs.")["quote"], "loc": loc(R, I08, "**Mathematical reason**: The Cartan subalgebra structure"),
    "contradicts": "(a) asserted without derivation; the only computation is the rank statement in section 4. For n=1 the 'H_k, k>=2' component is H_2 itself (section 5 line " + L(R, I08, "- **2 additional entries**") + ")."},
   {"quote": q(R, FR, "For each computational claim I wrote Python scripts", "symbolically over Z (no floating point)")["quote"], "loc": loc(R, FR, "For each computational claim I wrote Python scripts"),
    "contradicts": "(a) coefficients in data/C_n_gamma.json are rationals (e.g. '-1/2'), the scripts use Fraction, and no script computes the I08 ranks (src/ list)."}],
 "consistency_with_data": "stated class 'trivial iff gb=0' matches g_summary data_implies n1/n2 = 'trivial iff gb=0 / trivial iff gb=0'. K kept (Layer 2 has Z='K' entries); the conclusion also holds without K (g-part rank 28->32), and the run states both obstructions.",
 "notes": ["The I08 file contains a Manager correction cycle (lines " + L(R, I08, "## Correction Cycle") + "-185) quoting an earlier flawed K argument ('map f: g -> g + CK produces zero K-component'); that sentence is no longer in the committed report body (current text: lines " + L(R, I08, "**Why this is an obstruction**") + "-54 restricts f to g -> g).",
           "docs/issues/issue_correction.md.completed targets I09: it lists four factual errors of the first reflection (tool approvals, number of correction cycles, reason for the I08 correction, 'trivial' vs 'iff gb=0'); the committed reflection (final_reflection.md:9-13, 21) is the corrected version, which the spec says to judge as is.",
           "Calibration agrees: I08 conclusion trivial iff gb=0; reflection had factual errors later corrected (see above)."],
})

# ------------------------------------------------------------ sonnet46-A1
R = "thm01-R-sonnet46-A1"
I08 = "docs/issues/done/issue_261007_08.md"
FR = "docs/issues/done/final_reflection.md"
rows.append({
 "run": R, "commit_checked": "final (16db3a5; run still in I09 per inventory/g_summary)",
 "stated_conclusion": q(R, I08, "> For C(n+1) = osp(2|2n) with the inhomogeneous deformation parametrized by", "the deformation gamma is trivial (there exists an odd f: g -> g with gamma = delta f) **if and only if all gb_{sigma,j,s} = 0**."),
 "stated_conclusion_class": "trivial iff gb=0",
 "scope": {"n123": q(R, I08, "- Verified for n = 1, 2, 3 by exact rational arithmetic.", "Verified for n = 1, 2, 3 by exact rational arithmetic."),
           "general_n": q(R, I08, "**Predicted pattern for general n**", "Predicted pattern for general n: The K-constraint rank should equal 4n for all n >= 1, since each of the 4n parameters gb_{sigma,j,s} appears as the sole coefficient in at least one K-entry of gamma (namely, gamma(H_1, E_{eps_1-delta_j,sigma s})^K = +-gb_{sigma,j,s} ...)")},
 "declared_reading": {"a_parity_gb": "not stated",
                      "b_sign_handling": "not stated in I08 or reflection; g_summary: gamma data '=none' (no sign) relative to reference",
                      "c_K": {"quotes": [q(R, I08, "Since f maps g → g (within the Lie superalgebra, not into K)", "Since f maps g -> g (within the Lie superalgebra, not into K) and all structure constants in Schema 1 stay within g, the coboundary (delta f) can never produce a K-component."),
                                         q(R, FR, "Recognizing that K = Σ_j b_j^+ b_j^- + const is central but not in g", "Recognizing that K = sum_j b_j^+ b_j^- + const is central but not in g - and therefore must be tracked as a separate unknown rather than silently discarded")],
                              "schema1": "data/C_1_structure.json:" + L(R, "data/C_1_structure.json", "identified with scalar 1 in all applications") + " 'K ... identified with scalar 1 in all applications'; K kept as a separate unknown in Schema 2 (Z='K' entries)"}},
 "test_range": {"summary": "Joint over all gb: (i) K-constraint matrix rank over the 4n gb columns; (ii) full augmented system [M|N] (non-K part): rows where the M-block vanishes give additional gb constraints (13/26/39 rows per my run of the script). Three profiles (all_plus, diagonal, anti_diagonal) are shown as illustrations.",
                "evidence": q(R, "src/C_triviality.py", "Algorithm:", "1. K-constraint check ... 2. Augmented linear system: solve M.phi = N.gb over Q for any remaining constraints ... 3. Row-reduce [M | N]")},
 "computation": {"code": ["src/C_triviality.py: analyze_K_constraints, analyze_full_system, _row_reduce_square, _find_consistency_constraints", "src/C_gamma.py (identify_extended, K as extra unknown)", "src/C_coboundary.py", "src/C_evaluated.py", "src/C_generators.py"],
                 "hardcoded_or_placeholder": "none found"},
 "reported_numbers": {"reported": "K entries 20/84/180; K-rank 4/8/12 (full); rank(M) 28/168/516; deficit 4/8/12 (I08 sections 2, 3)",
                      "vs_reference": "rank(M)=rank A equals reference 28/168/516; K-rank 4n consistent with the K-kept jump (28->32, 168->176).",
                      "vs_script_output": "My execution of src/C_triviality.py in a scratch copy (not field 8) printed exactly these numbers, plus 'Additional gb constraints from non-K part: 13 / 26 / 39' and rows 214 / 2752 / 13982; the I08 report does not give these counts.",
                      "vs_g_summary": "g_summary: 28->32 (non-K) and 28->32 (K kept), 0/4 dirs trivial: consistent."},
 "argument_issues": [
   {"quote": q(R, I08, "b_j^- · b_j^+ = K − b_j^+ · b_j^-", "b_j^- . b_j^+ = K - b_j^+ . b_j^-    (in U(A)) ... introduces the central element K = sum_j b_j^+ b_j^- + 1/2 into gamma(X,Y)")["quote"], "loc": loc(R, I08, "b_j^- · b_j^+ = K − b_j^+ · b_j^-"),
    "contradicts": "(a/c) the run's Schema 1 gives the CCR [b_i^-, b_j^+] = delta_ij (data/C_1_structure.json oscillator_relations 'conjugate_pair') and K identified with scalar 1 (data/C_1_structure.json:" + L(R, "data/C_1_structure.json", "identified with scalar 1 in all applications") + "), i.e. b^-b^+ = b^+b^- + 1; the reflection itself says 'b^- b^+ = 1 + b^+ b^-' (" + FR + ":" + L(R, FR, "CCR reordering identity") + "). The I08 line writes the opposite sign for b^+b^- and identifies K with a number operator plus 1/2 (line " + L(R, I08, "introduces the central element K") + ")."},
   {"quote": q(R, I08, "The rank deficit of M equals exactly **4n = gb_count**", "The rank deficit of M equals exactly 4n = gb_count in every case. This means the left null space of the coboundary operator delta: C^1(g,g) -> C^2(g,g) has dimension exactly 4n")["quote"], "loc": loc(R, I08, "The rank deficit of M equals exactly"),
    "contradicts": "(c) the table above it defines the deficit as phi_count - rank(M) (32-28, 176-168, 528-516), i.e. dim ker of M on phi-space; the left null space of M has dimension (rows - rank) (e.g. 214 - 28 for n=1 per script output). Repeated at lines " + L(R, I08, "- The coboundary operator δ: C^1_odd(g,g) → C^2(g,g) has rank deficiency exactly 4n") + " and in the reflection (" + FR + ":" + L(R, FR, "This unified the") + ")."},
   {"quote": q(R, I08, "**Predicted pattern for general n**", "each of the 4n parameters gb_{sigma,j,s} appears as the sole coefficient in at least one K-entry of gamma (namely, gamma(H_1, E_{eps_1-delta_j,sigma s})^K = +-gb_{sigma,j,s} ...)")["quote"], "loc": loc(R, I08, "**Predicted pattern for general n**"),
    "contradicts": "(a) data/C_1_gamma.json has K entries with Y/X = H_1 only for gb_p_1_m and gb_m_1_m (coefficient 1 / -1); gb_p_1_p and gb_m_1_p occur in K entries with H_2, E_2del (e.g. (H_2,E_pp) 1/2), as the report's own table shows (lines " + L(R, I08, "| (H_1, E_eps1_del1_pm) |") + "-" + L(R, I08, "| (H_2, E_eps1_del1_mp) |") + ")."},
   {"quote": q(R, FR, "The test suite (5 test files, 61 tests total", "The test suite (5 test files, 61 tests total across all issues, all passing)")["quote"], "loc": loc(R, FR, "The test suite (5 test files, 61 tests total"),
    "contradicts": "(a) tests/ contains 4 files (test_C_coboundary.py, test_C_evaluated.py, test_C_gamma.py, test_C_generators.py) and pytest --collect-only in a scratch copy collects 30 tests."},
   {"quote": q(R, FR, "Rather than empirically checking specific gb profiles", "Rather than empirically checking specific gb profiles, I set up the full rational linear algebra problem")["quote"], "loc": loc(R, FR, "Rather than empirically checking specific gb profiles"),
    "contradicts": "(c) I08 section 4 (line " + L(R, I08, "**Non-trivial cases (all three tested profiles)**") + ") presents the profiles all_plus, diagonal, anti_diagonal as the concrete non-trivial evidence."}],
 "consistency_with_data": "stated class 'trivial iff gb=0' matches g_summary data_implies n1/n2 = 'trivial iff gb=0 / trivial iff gb=0'. K kept as separate unknown. The run's own non-K system also forces gb = 0 (13/26/39 extra constraints; g_summary 28->32), so the conclusion is not K-dependent for this data, although the report presents the K obstruction as 'primary' and the non-K system as 'confirmation'.",
 "notes": ["Run is still in I09 (inventory/g_summary status 'in progress (I09)'); docs/issues/issue_open.md is an empty I09 template while docs/issues/done/final_reflection.md already exists in the committed copy; judged as is.",
           "Calibration item 'claims g-component constraints are redundant' is not found in the committed copy (grep for 'redundan': none); 'K = sum b+b- + 1/2' and 'b-b+ = K - b+b-' are in I08 (issues above); 'Section 5' of the calibration corresponds to I08 section 5 'Root Cause Analysis'.",
           "The calibration statement that the data alone also give 28->32 is confirmed by g_summary and by this script's output (additional non-K constraints)."],
})

json.dump(rows, open("/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_interactive_facts/part4.json", "w"), ensure_ascii=False, indent=1)
print(len(rows), "rows")
