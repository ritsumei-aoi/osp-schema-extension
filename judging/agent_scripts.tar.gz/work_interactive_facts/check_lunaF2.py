import json
R='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/thm01-R-luna-F/data/'
for n in (1,2,3):
    ev=json.load(open(R+f'C_{n}_evaluated_all_plus.json'))['structure_constants']
    print(n,[e for e in ev if e['X']=='E_eps1_del1_pp' and e['Y']=='H_1' and e['Z']=='K'])
