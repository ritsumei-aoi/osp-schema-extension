import json, sympy as sp
from fractions import Fraction
R='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/thm01-R-luna-F/data/'
def rk(rows):
    M=[[Fraction(int(x.p),int(x.q)) if hasattr(x,'p') else Fraction(x) for x in r] for r in rows]
    rank=0
    if not M: return 0
    nc=len(M[0])
    for c in range(nc):
        p=None
        for i in range(rank,len(M)):
            if M[i][c]!=0: p=i;break
        if p is None: continue
        M[rank],M[p]=M[p],M[rank]
        pv=M[rank][c]
        M[rank]=[x/pv for x in M[rank]]
        for i in range(len(M)):
            if i!=rank and M[i][c]!=0:
                f=M[i][c]; M[i]=[a-f*b for a,b in zip(M[i],M[rank])]
        rank+=1
    return rank
for n in (1,2,3):
    cb=json.load(open(R+f'C_{n}_coboundary.json'))['coboundary_coefficients']
    ev=json.load(open(R+f'C_{n}_evaluated_all_plus.json'))['structure_constants']
    gm=json.load(open(R+f'C_{n}_gamma.json'))['inhomogeneous_deformation']['gamma_coefficients']
    phis=sorted({t['parameter'] for e in cb for t in e['terms']})
    gbs=sorted({e['parameter'] for e in gm})
    keys=sorted({(e['X'],e['Y'],e['Z']) for e in cb}|{(e['X'],e['Y'],e['Z']) for e in gm})
    nonK=[k for k in keys if k[2]!='K']; Kk=[k for k in keys if k[2]=='K']
    ki={k:i for i,k in enumerate(keys)}
    A={k:{} for k in keys}
    for e in cb:
        for t in e['terms']: A[(e['X'],e['Y'],e['Z'])][t['parameter']]=Fraction(t['coeff'])
    G={k:{} for k in keys}
    for e in gm: G[(e['X'],e['Y'],e['Z'])][e['parameter']]=G[(e['X'],e['Y'],e['Z'])].get(e['parameter'],0)+Fraction(e['coeff'])
    rowsA=[[sp.Rational(A[k].get(p,0)) for p in phis] for k in nonK]
    rowsAG=[[sp.Rational(A[k].get(p,0)) for p in phis]+[sp.Rational(G[k].get(g,0)) for g in gbs] for k in nonK]
    rowsAGK=[[sp.Rational(A[k].get(p,0)) for p in phis]+[sp.Rational(G[k].get(g,0)) for g in gbs] for k in keys]
    print('n',n,'phi',len(phis),'gb',len(gbs),'rank A',rk(rowsA),'rank[A|G] nonK',rk(rowsAG),'rank[A|G] incl K rows',rk(rowsAGK),
          'K records evaluated',sum(1 for e in ev if e['Z']=='K' and Fraction(e['kappa_coeff'])!=0),
          'rank gb->K',rk([[sp.Rational(G[k].get(g,0)) for g in gbs] for k in Kk]))
    if n==1:
        Q=['E_eps1_del1_pp','E_eps1_del1_pm','E_eps1_del1_mp','E_eps1_del1_mm']
        phi={}
        def setf(inp,outs):
            for o,c in outs.items(): phi[f'phi__{o}__from__{inp}']=Fraction(c)
        setf('H_1',{q:-1 for q in Q}); setf('H_2',{q:1 for q in Q})
        setf('E_2del1_p',{Q[0]:-2,Q[2]:-2}); setf('E_2del1_m',{Q[1]:-2,Q[3]:-2})
        setf(Q[0],{'H_1':1,'H_2':1}); setf(Q[1],{'H_1':1,'H_2':1}); setf(Q[2],{'H_1':-1,'H_2':-1}); setf(Q[3],{'H_1':-1,'H_2':-1})
        bad=0
        gam={(e['X'],e['Y'],e['Z']):Fraction(e['kappa_coeff']) for e in ev}
        for k in nonK:
            val=sum(c*phi.get(p,0) for p,c in A[k].items())
            if val!=gam.get(k,Fraction(0)): bad+=1
        print(' witness f mismatching rows (nonK):',bad,'of',len(nonK))
