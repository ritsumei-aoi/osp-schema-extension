import json
J='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/'
for run,key in (('thm01-R-luna-A','gamma_structure'),('thm01-R-luna-F','gamma_coefficients')):
    for n in (1,2):
        g=json.load(open(J+f'{run}/data/C_{n}_gamma.json'))['inhomogeneous_deformation'][key]
        print(run,n,[(e['Z'],e.get('coeff'),e.get('parameter')) for e in g if e['X']=='H_1' and e['Y']=='E_eps1_del1_pm'])
print('--- luna-G, luna-r2-G ("=none" in g_summary) ---')
for run in ('thm01-R-luna-G','thm01-R-luna-r2-G'):
    for n in (1,2,3):
        d=json.load(open(J+f'{run}/data/C_{n}_gamma.json'))['inhomogeneous_deformation']['gamma_coefficients']
        print(run,n,[(e['Z'],e.get('coeff'),e.get('parameter')) for e in d if e['X']=='H_1' and e['Y']=='E_eps1_del1_pm'])
