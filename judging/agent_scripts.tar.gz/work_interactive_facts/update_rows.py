import json, re
B = "<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/"
OUT = B + "judging/facts/interactive.jsonl"
LUNA = B + "runs/thm01-R-luna-F/copilot_session/86f9680b-c87a-4e59-9bd1-f3ff4016e385/transcript.md"
SON = B + "runs/thm01-R-sonnet46-F/claude_session/84e42fc6-71ea-45e0-84f9-58d489a5c11b.md"
SC = "scratch work_interactive_facts/"

norm = lambda t: re.sub(r"\s+", " ", t).strip()
def lines(p): return open(p, encoding="utf-8").read().split("\n")
def Q(path, phrase, ts, rel, quote=None, start=0):
    L = lines(path)
    P = norm(phrase)
    for i in range(start, len(L)):
        if not L[i].strip(): continue
        chunk = norm(" ".join(L[i:i+4]))
        if chunk.startswith(P) or P in norm(L[i]):
            return {"quote": quote or phrase, "loc": f"{rel}#{ts} (line {i+1})"}
    raise AssertionError(phrase)

LR = "runs/thm01-R-luna-F/copilot_session/86f9680b-c87a-4e59-9bd1-f3ff4016e385/transcript.md"
SR = "runs/thm01-R-sonnet46-F/claude_session/84e42fc6-71ea-45e0-84f9-58d489a5c11b.md"
T8L = "2026-10-03T09:25:06.324Z"
T8S1 = "2026-10-06T04:35:30.334Z"
T8S2 = "2026-10-06T05:02:59.761Z"

# ------------------------------------------------------------------ luna-F
luna = {
 "run": "thm01-R-luna-F", "commit_checked": "final (32e91c8); step-8 text taken from the conversation log",
 "stated_conclusion": Q(LUNA, "**Conjecture:** For any rank", T8L, LR, "Conjecture: For any rank \\(n\\), arbitrary scalar gb parameters produce a deformation that is a coboundary in the adjoint/scalar quotient; there are no additional gb constraints for adjoint triviality. If central \\(K\\) coefficients must also match literally, the necessary condition is that all gb parameters vanish."),
 "stated_conclusion_class": "conditional/other",
 "stated_conclusion_class_note": "Two-branch conclusion in the one reply: K treated as scalar ('up to scalars', adjoint) -> 'all gb trivial'; K matched literally -> 'trivial iff gb=0'. The reply presents the first as the answer to the documented criterion ('it does not obstruct triviality under the documented \"up to scalar\" criterion'). Human approval of the report: " + LR + "#2026-10-03T09:43:08.333Z.",
 "scope": {
   "n123": Q(LUNA, "The equal ranks show that", T8L, LR, "The equal ranks show that **every noncentral gamma column lies in the image of \\(\\delta\\)** for all three tested ranks. Thus every linear combination of the gb parameters—including the all-plus assignment—is a coboundary after passing to the adjoint/scalar quotient."),
   "general_n": Q(LUNA, "**Conjecture:** For any rank", T8L, LR, "The first claim is supported by exact rational rank calculations for \\(n=1,2,3\\); its extension to all \\(n\\) remains a conjecture.", start=740)},
 "declared_reading": {
   "a_parity_gb": Q(LUNA, "3. Parity conflict: There is no mathematical error in the document.", "2026-10-03T07:03:41.855Z", LR, "Each gb parameter is an ordinary scalar, so the term gb·κ correctly has parity 1. (human reply to the Worker's question; the Worker then treats gb as scalar)"),
   "b_sign_handling": Q(LUNA, "2. Sign conventions: We choose Option A (follow the reference exactly).", "2026-10-03T07:03:41.855Z", LR) | {"note": "Option A = [b,a]_gamma = -gb*kappa; data are graded ('=super' in g_summary)."},
   "c_K": [Q(LUNA, "I analyzed the noncentral basis coefficients separately from the scalar", T8L, LR, "I analyzed the noncentral basis coefficients separately from the scalar \\(K\\) component, since the stated triviality criterion is **in the adjoint representation, up to scalars**."),
           Q(LUNA, "which no Layer 4 basis-valued coboundary can reproduce.", T8L, LR, "Since \\(K=1\\) is central, this term vanishes in the adjoint representation; it does **not** obstruct triviality under the documented “up to scalar” criterion. If instead one requires literal equality including the central scalar component, the all-plus deformation is nontrivial.", start=768)]},
 "test_range": "joint (+ profiles: all-plus witness). The reply forms the rank of [A | gamma columns for every gb parameter] against rank A (noncentral part) and the rank of the gb-to-K map, so all linear combinations are covered; the K part is also tested jointly (rank 4n). The transcript.md shows the tool code only truncated; my script reproduces the numbers (agent computation: " + SC + "check_lunaF.py): rank A 28/168/516, rank [A|G] excluding K 28/168/516, rank [A|G] including K rows 32/176/528.",
 "computation": {"code": ["src/C_gamma.py", "src/C_coboundary.py", "src/evaluate_C_structure.py", "src/C_generators.py (generators)"],
                 "rank_computation": "one-off sympy/Fraction scripts in the session (tool calls at 2026-10-03T09:23:09Z-09:24:45Z in transcript.md); not committed",
                 "hardcoded_or_placeholder": "none found"},
 "reported_numbers": {
   "reported": Q(LUNA, "| C(2) | 4 | 32 | 28 | 28 | 20 | 4 |", T8L, LR, "C(2): gb 4, f params 32, rank A 28, rank [A|gamma] excl. K 28, K-records 20, rank gb->K 4; C(3): 8, 176, 168, 168, 84, 8; C(4): 12, 528, 516, 516, 180, 12"),
   "vs_reference": "rank A equals the reference 28/168/516; rank [A|G] excluding K = rank A matches the reference for K dropped / supercommuting (28, 168, 516).",
   "agent_computation": "check_lunaF.py (scratch): all reported numbers reproduced (K records evaluated 20/84/180; rank gb->K 4/8/12; with K rows included 32/176/528).",
   "vs_g_summary": "g_summary n=1: non-K 28->28 (4/4 dirs trivial), K kept 28->32 (0/4); n=2: 168->168 / 168->176. Consistent."},
 "argument_issues": [],
 "argument_checks_passed": ["witness f for C(2) (reply, same message) reproduces all 212 non-K rows of the all-plus gamma (agent computation, check_lunaF.py: 0 mismatches)", "'(E_{eps+delta_1}, H_1) -> K with kappa-coefficient +1' present in data/C_n_evaluated_all_plus.json for n=1,2,3 (agent computation, check_lunaF2.py)", "gamma(E_{eps+delta_1},E_{eps+delta_1}) = 2 E_{eps+delta_1} present in the evaluated data (kappa_coeff 2)"],
 "consistency_with_data": "Both branches of the stated conclusion equal g_summary data_implies n1/n2 = 'all gb trivial (K dropped) / trivial iff gb=0 (K kept)'. Declared treatment: gb ordinary scalar, graded signs, K handled both ways; no mismatch found.",
 "notes": ["Reflection lines in the copy (final_reflection.md:11, 21, 29) restate the K distinction.",
           "Calibration agrees: gamma records K; in step 8 the Worker analysed the non-K part (K 'up to scalars') and also states the K-literal conclusion. Calibration says the Worker 'dropped K'; the reply keeps both readings."],
}

# ------------------------------------------------------------------ sonnet46-F
son = {
 "run": "thm01-R-sonnet46-F", "commit_checked": "final (e3b8d11); step-8 text taken from the conversation log (first report, human correction, revised report)",
 "stated_conclusion": Q(SON, "Then γ is cohomologous to zero (i.e., γ = δf for some odd linear f: g → g)", T8S2, SR, "CONJECTURE. Let n ≥ 1 and γ be the 2-cocycle on osp(2|2n) defined by the inhomogeneous deformation [b_j^s, a_1^σ]_γ = −gb_{σ,j,s}·κ. Then γ is cohomologous to zero (i.e., γ = δf for some odd linear f: g → g) if and only if all gb_{σ,j,s} = 0.", start=2700),
 "stated_conclusion_class": "trivial iff gb=0",
 "stated_conclusion_also": [Q(SON, "1. γ_eval (all gb=1) is NOT trivial for n=1,2,3.", T8S2, SR, "γ_eval (all gb=1) is NOT trivial for n=1,2,3. The linear system A·φ=b is inconsistent in all three cases (exact arithmetic, RREF).", start=2780)],
 "scope": {
   "n123": [Q(SON, "1. γ_eval (all gb=1) is NOT trivial for n=1,2,3.", T8S2, SR, "n=1,2,3: all-ones profile inconsistent; single-gb test only for n=1", start=2780),
            Q(SON, "Single-gb subsystem test for n=1", T8S2, SR, "Single-gb subsystem test for n=1 (one parameter active, all others zero): ... 19, 13, 19, 19 inconsistent equations", start=2690)],
   "general_n": Q(SON, "7. Conjecture: γ ∉ Im(δ) for all n ≥ 1 and all nonzero gb profiles.", T8S2, SR, "Conjecture: γ ∉ Im(δ) for all n ≥ 1 and all nonzero gb profiles. The inhomogeneous deformation of osp(2|2n) represents a genuinely non-trivial class in H²(g, g)."),
   "note": "Structural-obstruction count 2(n-1) is a prediction for n>=4 ('For general n the prediction is {H_2, …, H_n}')."},
 "declared_reading": {
   "a_parity_gb": "not stated in the step-8 reports; the Worker's own context summary says 'κ is odd (parity 1), gb parameters have parity 1' (" + SR + " line 1035, compaction summary). No human parity decision found in the log.",
   "b_sign_handling": Q(SON, "2. Sign convention: Please proceed with Option A.", "2026-10-06T02:14:49.672Z", SR, "2. Sign convention: Please proceed with Option A. It exactly matches the minus sign in the mathematical definition ..."),
   "c_K": [Q(SON, "where K is the identity operator (the central scalar", T8S1, SR, "FIRST report (Section VI): a_1^+a_1^− − b_1^+b_1^− = H_1 + 2H_2 + K (n=1) ... K is the identity operator ... the coboundary CANNOT produce a K-component. Therefore any γ with a nonzero K-coefficient ... is necessarily outside the image of δ.", start=2063),
           Q(SON, "H_2 is an independent basis element of C(2)", T8S2, SR, "REVISED report (the one approved): no K section; root cause stated as isotropic root + coroot identity (Sections III-IV). K is not mentioned in the revised conclusion.", start=2498)],
   "c_K_data": "Schema 1: 'K = 1 (scalar identification)'; Schema 2 data contain no Z='K' entries (g_summary 'not recorded')."},
 "test_range": "profiles: all-ones (n=1,2,3) + per-direction (n=1 only; four single-gb systems). Joint rank over all gb is not computed in the log. Agent computation (scratch check_s46F.py using the run's own rref): joint rank [A|G] = 32 for n=1 (rank A 28) and 176 for n=2 (rank A 168); n=3 not computed.",
 "computation": {"code": ["src/triviality_search.py (rref over Fractions; all-ones profile)", "single-gb runs: ad-hoc python in the session (tool call 2026-10-06T04:30:10Z), not committed", "src/C_gamma.py", "src/C_coboundary.py", "src/C_evaluated.py"],
                 "hardcoded_or_placeholder": "none found"},
 "reported_numbers": {
   "reported": Q(SON, "  1 │    32    │   212  │    28   │    4     │   NO    │     70     │      0", T8S2, SR, "n=1: phi 32, rows 212, rank 28, null 4, incons 70, struct. obstr. 0; n=2: 176, 2750, 168, 8, 380, 2; n=3: 528, 13980, 516, 12, 838, 4; single-gb n=1: 19, 13, 19, 19", start=2500),
   "agent_computation": "check_s46F.py (scratch, imports the run's triviality_search): all reproduced (rank 28/168/516, null 4/8/12, inconsistent 70/380/838, gamma-only rows 0/2/4, single-gb 19/13/19/19 for gb_a1m_b1m, a1m_b1p, a1p_b1m(13), a1p_b1p). 'H_2 appears as Z in 12 gamma entries and 28 coboundary entries (n=1)': reproduced. Coboundary support of (H_1,E_pm) has no Z=H_k, k>=2 (n=2,3): reproduced. Schema 1 data: [H_1,E_pm] has no entry (zero) and [E_pm,E_mp] -> H_1 only, n=1,2,3 (check_s46F_struct.py).",
   "vs_reference": "rank A equals reference 28/168/516.",
   "vs_g_summary": "g_summary non-K 28->32 (0/4), n=2 168->176; the run's gamma data differ from the no-sign reference (miss 5/50 n=1, 21/292 n=2, extra 1)."},
 "argument_issues": [
   {"quote": Q(SON, "The last Cartan generator H_{n+1} has coefficient 0 in each case", T8S2, SR, "The last Cartan generator H_{n+1} has coefficient 0 in each case (it involves b_n^+ b_n^− with a constant term, and the constant term of the kappa polynomial is zero since the deformation does not shift the vacuum energy at first order).", start=2740)["quote"], "loc": SR + "#" + T8S2 + " (line " + "2743)",
    "contradicts": "(cross-run data, agent computation scratch check_ref_H1Epm.py) gamma(H_1,E_eps1_del1_pm) in thm01-R-luna-r2-G data (K recorded, g_summary '=none') has H_{n+1} coefficients 2 (n=1: H_2:2; n=2: H_3:2; n=3: H_4:2) and a K entry 1. The run's own Schema 2 omits them (n=1: only H_1 and E_2del1_m). The obstruction rows (E_pm,H_1;H_k) it finds for n>=2 and the n=1 vs n>=2 distinction ('no structural obstructions for n=1') depend on this omitted component; the report attributes the n=1 absence to the Cartan solver's 'N=2 path', not to the missing constant term."},
   {"quote": "(d) The gamma vector b is linear in gb. The inhomogeneous consistency conditions reduce to linear equations ... Since each of the four standard basis directions of gb-space is inconsistent (as verified for n=1), the only consistent profile is gb = 0.", "loc": SR + "#" + T8S2 + " (line 2778)",
    "contradicts": "(c/a) The set of consistent gb is a linear subspace, but a subspace can contain no coordinate direction and still be nonzero; the inference needs the joint rank. The log contains no joint rank computation; (agent computation, check_s46F.py) the joint rank [A|G]=32 > rank A=28 (n=1) and 176 > 168 (n=2) supports the claim for those n."},
   {"quote": "null_dim(A) = 4n for all n ∈ {1, 2, 3}, matching the number of gb deformation parameters exactly. ... suggests a complementary pairing: any hypothetical triviality certificate f would be unique only up to a 4n-dimensional space of 'invisible' maps, the same count as the deformation parameters.", "loc": SR + "#" + T8S2 + " (line 2716)",
    "contradicts": "(a) null_dim = phi columns - rank(A), the kernel of A on phi-space; the number of gamma directions outside the image is rank[A|G] - rank(A) (g_summary +4/+8). The 'complementary pairing' is asserted without derivation (the first report added 'outer derivations ... one dimension per gb', removed in the revision)."},
   {"quote": "First report: 'there is no H_2 independent of H_1' (n=1); '... H_1 − 2H_2 + 2H_3 − 2H_4 + 2H_5 + K (n=3)'", "loc": SR + "#" + T8S1 + " (Sections IV, VI, VII)",
    "contradicts": "(a) data/C_1_structure.json lists H_1 and H_2 and C_3 has H_1..H_4 (check_s46F.py output: even basis H lists). Human flagged this at " + SR + "#2026-10-06T04:57:26.274Z; the revised report corrects it (history, not a defect of the revised text)."}],
 "consistency_with_data": "stated class 'trivial iff gb=0' matches g_summary data_implies n1/n2 'trivial iff gb=0 / trivial iff gb=0' (and my joint rank 32>28, 176>168). The revised report's mechanism (structural obstruction in Z=H_k components, K not used) rests on gamma entries that differ from the reference gamma (g_summary miss 5 of 50 at n=1, 21 of 292 at n=2).",
 "notes": ["Two step-8 reports exist: first at " + SR + "#" + T8S1 + " (K=1 central-element mechanism, factual errors), human correction at #2026-10-06T04:57:26.274Z, revised at #" + T8S2 + " (K removed from root cause), approved at #2026-10-06T05:09:50.457Z.",
           "The step-8 text is not in the committed workspace; the final reflection (final_reflection.md:32) acknowledges the two corrected errors."],
}

rows = [json.loads(l) for l in open(OUT)]
new = []
CONV = "'quote' fields are verbatim or condensed with '...' (condensed ones may write LaTeX in ASCII; fields named summary/note/agent_computation/evidence-description are paraphrases). 'loc' = file:line (or <log file>#<timestamp>) where the passage starts; paths relative to $JROOT/final/<run>/ (F-run logs: REV/runs/...). Computed facts come from scripts saved in $JROOT/../work_interactive_facts/ (check_*.py); 'not checked' otherwise."
REPL = [
 ("checked by hand against Cn1_definition.md: correct.", "n=1 case b^+b^- = -H_2 - 1/2 verified by script (agent computation, check_osc.py); general n not checked."),
 ("(matches my hand check against Cn1_definition.md)", "(n=1 case b^+b^- = -H_2 - 1/2 verified by agent computation check_osc.py; general n not checked)"),
 ("(my hand computation; not run code)", "(agent computation, n=1, scratch check_osc.py: {a^+b^+,a^-b^-} = -H_1-2H_2 holds exactly; the version with +K does not)"),
 ("{a^+b^+,a^-b^-} = -H_1-2H_2 (my hand computation)", "{a^+b^+,a^-b^-} = -H_1-2H_2 (agent computation, n=1, scratch check_osc.py; the script's values {H1:1,H2:1} and {H1:1,H2:-1} fail the same check)"),
 ("= H_1 exactly (my hand computation)", "= H_1 exactly (agent computation, n=1, scratch check_osc.py; H_1-2H_2 fails)"),
 ("(my hand computation)", "(agent computation, n=1, scratch check_osc.py)"),
 ("([H_2,b^+] = -b^+ for H_2 = -b^+b^- - 1/2)", "(agent computation check_osc.py: [H_2,a^+b^+] = -a^+b^+)"),
 ("Direct evaluation from the oscillator realization in docs/math/Cn1_definition.md", "Direct evaluation (agent computation, n=1, scratch check_osc.py) from the oscillator realization in docs/math/Cn1_definition.md"),
]
for r in rows:
    if r["run"] == "thm01-R-luna-F": r = luna
    elif r["run"] == "thm01-R-sonnet46-F": r = son
    r["quote_convention"] = CONV
    s = json.dumps(r, ensure_ascii=False)
    for a, b in REPL: s = s.replace(a, b)
    new.append(json.loads(s))
with open(OUT, "w", encoding="utf-8") as f:
    for r in new: f.write(json.dumps(r, ensure_ascii=False) + "\n")
print(len(new))
s = open(OUT).read()
print("hand left:", len(re.findall(r"hand (computation|check)|by hand|checked by hand", s)))
