import json, sys
sys.path.insert(0, "/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_interactive_facts")
from lib import q, loc

rows = []

# ---------------------------------------------------------------- luna-A
R = "thm01-R-luna-A"
I08 = "docs/issues/done/issue_261003_08.md"
I05 = "docs/issues/done/issue_261003_05.md"
FR = "docs/issues/done/final_reflection.md"
rows.append({
 "run": R, "commit_checked": "final (877a1c5 per inventory; g_summary lists 877a1c5)",
 "stated_conclusion": q(R, I08, "Hence the necessary and sufficient condition on the", "Hence the necessary and sufficient condition on the gb parameters is **no condition beyond their allowed scalar values**: every assignment is trivial."),
 "stated_conclusion_class": "all gb trivial",
 "scope": {
   "n123": q(R, I08, "and 3, respectively, **all**", "For n=1, 2, and 3, respectively, **all** gb assignments are trivial; the necessary and sufficient condition is simply that the parameters are arbitrary scalars"),
   "general_n": q(R, I08, "For every bosonic rank", "conjecture that the entire 4n-dimensional gamma family is contained in the coboundary image ... The rank formula and image containment for general n remain conjectural beyond those computed ranks."),
 },
 "declared_reading": {
   "a_parity_gb": {"quotes": [q(R, I05, "Please confirm whether the intended resolution is to treat the `gb`", "Worker asks: treat the gb parameters as even scalars (recommended ...)"),
                              q(R, FR, "the human clarified that `gb` is", "the human clarified that `gb` is even while kappa is odd")],
                   "note": "The human decision itself is not in the committed files (only the Worker's question and its later retelling). Schema 2 records parameter_parity 0 (src/C_gamma_generator.py:" + loc(R, "src/C_gamma_generator.py", '"parameter_parity": 0').split(":")[1] + ")."},
   "b_sign_handling": {"quote": "sign_rule 'graded' in every gamma/evaluated/coboundary record; Schema 2 stores relation as [b,a]_gamma - [b,a]_0 = -gb*kappa", "loc": loc(R, "src/C_gamma_generator.py", '"sign_rule": "graded"')},
   "c_K": {"quotes": [q(R, I05, "Human review approved restricting gamma outputs", "Human review approved restricting gamma outputs to the Schema 1 Lie basis and quotienting out scalar K=1 components."),
                      q(R, "src/C_gamma_generator.py", '"policy": "project modulo scalar K')],
           "note": "I08 report itself never mentions K or the scalar quotient (grep K in issue_261003_08.md: no occurrences). K components are discarded in the data (no Z='K' entries)."},
 },
 "test_range": {"summary": "Joint test over all gb: rank of [A|G] with G the full 4n-column gamma map vs rank A, so every linear combination of gb is covered; plus one explicit witness f for the all-plus profile for n=1,2,3.",
                "evidence": q(R, I08, "A:\\phi\\longmapsto", "exact rational linear maps A: phi -> delta f, G: gb -> gamma ... one row for every ordered basis triple. condition is G gb in im A")},
 "computation": {
   "code": ["src/C_gamma_generator.py (gamma, exact normal ordering)", "src/C_coboundary_generator.py (delta f coefficients)", "src/C_evaluated_generator.py (evaluated profile)", "src/C_generators.py (Schema 1)"],
   "rank_computation": "No committed script for the I08 rank comparison; the reflection states it was an unsaved one-off.",
   "evidence": q(R, FR, "The I08 sparse", "The I08 sparse rank comparison was run as an exact one-off analysis rather than saved as a reusable repository script"),
   "hardcoded_or_placeholder": "none found in src for gamma/delta f; values come from generators."},
 "reported_numbers": {
   "reported": q(R, I08, "| C(2) | 512 | 32 | 4 | 28 | 28 | 4 |", "C(2): rows 512, phi 32, gb 4, rank A 28, rank [A|G] 28, rank G 4; C(3): 6859,176,8,168,168,8; C(4): 39304,528,12,516,516,12"),
   "vs_reference": "Match the spec reference for the K-dropped / supercommuting case (28/28, 168/168, 516/516). K-kept ranks (32/176/528) are not applicable because the run's data contain no K entries.",
   "vs_g_summary": "g_summary: n=1 28->28 (4/4 dirs trivial), n=2 168->168 (8/8); n=3 not in g_summary. Matches."},
 "argument_issues": [
   {"quote": "\"generated_by\": \"build_C_gamma_schema.py\" (data/C_1_gamma.json:" + loc(R, "data/C_1_gamma.json", "build_C_gamma_schema.py").split(":")[1] + ") and \"build_C_structure_constants.py\" (data/C_1_structure.json:" + loc(R, "data/C_1_structure.json", "build_C_structure_constants.py").split(":")[1] + ")",
    "contradicts": "src/ contains C_gamma_generator.py and C_generators.py; the two named scripts do not exist in the copy (metadata only)."}],
 "consistency_with_data": "stated class 'all gb trivial' matches g_summary data_implies n1/n2 = 'all gb trivial / all gb trivial' (K dropped / K kept; K not recorded in this run's gamma). Declared treatment (gb even, kappa supercommuting, K dropped) is the 'even gb' reading.",
 "notes": ["Conclusion is K-independent in the sense of test (b): K was dropped before the test; had K been kept the conclusion would be 'iff gb=0' (spec reference ranks 28->32).",
           "Human decisions (even gb, K quotient, profile choice) are stated only second-hand in the run's files."],
})

# ---------------------------------------------------------------- luna-F
R = "thm01-R-luna-F"
rows.append({
 "run": R, "commit_checked": "final (32e91c8)",
 "stated_conclusion": {"quote": None, "loc": None, "note": "No Step 8 report/triviality file exists in the committed copy (chat-driven run: step 8 text was delivered in conversation). Only the reflection mentions the analysis."},
 "stated_conclusion_class": "none",
 "stated_conclusion_class_note": "Closest committed text: final_reflection.md says the report 'distinguished the noncentral adjoint result from scalar K terms' and that the 'all-rank triviality conjecture' is unproven; direction of the conjecture is not stated in files.",
 "scope": {"quotes": [q(R, "final_reflection.md", "The general conjecture was limited", "The general conjecture was limited to evidence for n=1, 2, and 3. The report identified it as a conjecture, not a proof for arbitrary n."),
                      q(R, "final_reflection.md", "Separate experimentally verified", "...A symbolic proof ... would be the next step before elevating the all-rank triviality conjecture to a theorem.")]},
 "declared_reading": {
   "a_parity_gb": q(R, "final_reflection.md", "the researcher clarified that each gb parameter is an ordinary scalar", "the researcher clarified that each gb parameter is an ordinary scalar and that the combined gb-kappa term is odd"),
   "b_sign_handling": "not stated in files; data gamma is '=super' per g_summary (graded signs).",
   "c_K": {"quotes": [q(R, "final_reflection.md", "Scalar `K` outputs required", "Scalar `K` outputs required distinguishing strict coefficient equality from equality in the adjoint representation."),
                      q(R, "final_reflection.md", "I analyzed both literal equality", "I analyzed both literal equality and equality modulo scalars in the adjoint representation and stated the distinction in the final report.")],
           "code": ["src/C_gamma.py:" + loc(R, "src/C_gamma.py", 'gamma_realizations["K"]').split(":")[1] + " (K added as a gamma label)", "src/C_gamma.py:" + loc(R, "src/C_gamma.py", '"central_outputs": ["K"]').split(":")[1] + " (central_outputs K recorded)"]}},
 "test_range": "not in committed files (no triviality script, no rank output). Committed evaluated data is all-plus only (data/C_n_evaluated_all_plus.json).",
 "computation": {"code": ["src/C_gamma.py (gamma incl. K)", "src/C_coboundary.py", "src/evaluate_C_structure.py", "src/C_generators.py"],
                 "rank_computation": "no committed code; reflection says SymPy was used for exact linear-system analysis",
                 "evidence": q(R, "final_reflection.md", "SymPy for exact linear-system", "SymPy for exact linear-system analysis"),
                 "hardcoded_or_placeholder": "none found"},
 "reported_numbers": {"reported": "none in committed files", "vs_g_summary": "g_summary (from the run's data): n=1 non-K 28->28 (4/4 dirs trivial), K kept 28->32 (0/4); n=2 168->168 / 168->176."},
 "argument_issues": [],
 "consistency_with_data": "stated class is 'none' in the copy, so no comparison possible. g_summary data_implies n1/n2 = 'all gb trivial (K dropped) / trivial iff gb=0 (K kept)'; this run's gamma records K (gamma K '=super').",
 "notes": ["Calibration item 'in step 8 the Worker itself dropped K up to scalar; also states the K-kept reading's conclusion' cannot be checked: step 8 text is not in the copy.",
           "Reflection mentions the report 'distinguished' the K terms; the two conclusions (K dropped: all trivial; K kept: iff gb=0) are exactly the two data_implies values."],
})

# ---------------------------------------------------------------- luna-G
R = "thm01-R-luna-G"
I08 = "docs/issues/I08.md"
I05 = "docs/issues/I05.md"
rows.append({
 "run": R, "commit_checked": "final (004a063)",
 "stated_conclusion": q(R, I08, "The evidence therefore supports the necessary-and-sufficient", "The evidence therefore supports the necessary-and-sufficient condition that the deformation is trivial only for the zero gb matrix, for each tested rank."),
 "stated_conclusion_class": "trivial iff gb=0",
 "scope": {"n123": q(R, I08, "the symbolic central-obstruction matrices have ranks 4/4", "the symbolic central-obstruction matrices have ranks 4/4, 8/8, and 12/12 for n=1,2,3, respectively, so their common zero condition forces every gb parameter to vanish."),
           "general_n": q(R, I08, "data-supported conjecture under the literal formal-coefficient", "this is a data-supported conjecture under the literal formal-coefficient convention documented in I05, not a parity-consistent theorem")},
 "declared_reading": {
   "a_parity_gb": q(R, I05, "The source defines `gb` and `κ` as odd", "The source defines gb and kappa as odd, but their product is even while the mixed bracket of an even boson and odd fermion must be odd."),
   "b_sign_handling": q(R, I05, "chose the latter to complete the no-gate task", "following the literal exchange relation while treating parameter names as formal coefficient labels ... the generated data does not infer additional signs from parameter parity"),
   "c_K": q(R, I05, "than discard those terms, I record them as target `K`", "Rather than discard those terms, I record them as target K, the central identity already defined by Schema 1 and equal to 1.")},
 "test_range": {"summary": "Only the K components of gamma: rank of the symbolic kappa*K coefficient matrix (4n columns, one per gb). The non-K part of gamma was not compared with delta f. Per-direction/all-plus profile tests of the non-K part are not in I08.",
                "evidence": q(R, I08, "It forms the exact rational matrix from all", "It forms the exact rational matrix from all kappa K-valued gamma coefficients and computes its rank.")},
 "computation": {"code": ["src/C_triviality.py: analyze_rank (K-matrix rank via _matrix_rank)", "src/C_gamma.py", "src/C_coboundary.py", "src/C_evaluate.py"],
                 "rank_computation": "src/C_triviality.py:" + loc(R, "src/C_triviality.py", "obstruction_rank = _matrix_rank").split(":")[1],
                 "hardcoded_or_placeholder": "none found"},
 "reported_numbers": {"reported": q(R, I08, "`python src/C_triviality.py` reported central-obstruction", "central-obstruction ranks 4/4, 8/8, and 12/12; all three all-+1 profiles had a nonzero central mismatch"),
                      "vs_reference_and_g_summary": "K-matrix rank 4n is consistent with the spec's K-kept jump 28->32 (+4), 168->176 (+8). The run reports no rank A or [A|G]. g_summary (run's own data, no-sign convention): non-K 28->32 and K-kept 28->32 for n=1; 168->176 n=2 (0 dirs trivial)."},
 "argument_issues": [],
 "consistency_with_data": "stated class 'trivial iff gb=0' matches g_summary data_implies n1/n2 = 'trivial iff gb=0 / trivial iff gb=0' (K dropped / K kept). Declared K treatment: kept as target K. Test (b): conclusion is not K-dependent for the run's own data (dropping K still gives 28->32), although the run's argument uses only K.",
 "notes": ["Run states its conclusion is conditional on the literal formal-coefficient convention (I08 and final_reflection.md).",
           "Calibration agrees: K kept and used as the only argument; no comparison of non-K part."],
})

# ---------------------------------------------------------------- luna-r2-G
R = "thm01-R-luna-r2-G"
rows.append({
 "run": R, "commit_checked": "final (6c5ed08)",
 "stated_conclusion": q(R, I08, "$\\mathrm{gb}_{a_1^\\sigma,b_j^s}$ is zero.** Necessity", "the deformation is trivial if and only if every gb_{a1^sigma,bj^s} is zero. Necessity follows from the four isolated K witnesses for each j"),
 "stated_conclusion_class": "trivial iff gb=0",
 "scope": {"n123": q(R, I08, "This pattern is checked for n=1,2,3", "This pattern is checked for n=1,2,3; its extension to all n is a conjecture based on the rank-independent root-pair pattern and Cartan identity."),
           "general_n": "same line: conjecture"},
 "declared_reading": {
   "a_parity_gb": q(R, I05, "assigns odd parity to both `gb` and `kappa`", "assigns odd parity to both gb and kappa, but their product is used as the right-hand side of a mixed commutator between an even and odd oscillator. Those parity statements are inconsistent."),
   "b_sign_handling": q(R, I05, "coefficient and not asserting parity consistency", "I followed the explicitly given [relation], treating gb as a formal coefficient and not asserting parity consistency."),
   "c_K": q(R, I05, "with `K` included where a scalar", "expressed in the matching Schema 1 basis, with K included where a scalar ...")},
 "test_range": {"summary": "Only the K components: one isolated K witness per gb parameter (4n witnesses), plus an all-plus K component count. No joint rank, no non-K comparison, no per-direction non-K test in I08.",
                "evidence": q(R, I08, "has an isolated central-component witness", "checks that Layer 4 has no K output ... and that each of the 4n parameters has an isolated central-component witness")},
 "computation": {"code": ["src/C_triviality.py", "src/C_gamma.py", "src/C_coboundary.py", "src/C_evaluate.py"], "hardcoded_or_placeholder": "none found"},
 "reported_numbers": {"reported": q(R, I08, "| C(2) | 4 | 60 | 10 | 4 |", "C(2): 4 params, 60 gamma terms, 10 nonzero all-plus K components, 4 witnesses; C(3): 8, 334, 42, 8; C(4): 12, 932, 90, 12"),
                      "vs_reference_and_g_summary": "No rank A / [A|G] reported. Witness table (E_2del_p,E_eps_del_pm: +1/2 gb_{a+,b+} K etc.) matches data/C_1_gamma.json K entries (checked n=1)."},
 "argument_issues": [],
 "consistency_with_data": "stated class 'trivial iff gb=0' matches g_summary data_implies n1/n2 'trivial iff gb=0 / trivial iff gb=0'. K kept. Own-data non-K part is also non-coboundary (28->32) but not examined.",
 "notes": ["Same structure as luna-G, no non-K comparison.", "Derived identity b_j^+b_j^- = sum_{k>j} H_k - H_{n+1} - K/2 (I08) checked by hand against Cn1_definition.md: correct."],
})

# ---------------------------------------------------------------- luna-r3-G
R = "thm01-R-luna-r3-G"
rows.append({
 "run": R, "commit_checked": "final (6a6273e)",
 "stated_conclusion": q(R, I08, "This is the general conjecture for all", "gb_{a1^sigma,bj^s} = 0 for every sigma,s in {+,-}, 1<=j<=n ... This is the general conjecture for all n>=1: the zero deformation is trivial, and every nonzero parameter profile is non-trivial."),
 "stated_conclusion_class": "trivial iff gb=0",
 "scope": {"n123": q(R, I08, "The symbolic comparison returned zero-dimensional", "The symbolic comparison returned zero-dimensional trivial parameter spaces for C(2), C(3), and C(4): respectively 0/4, 0/8, and 0/12 allowed independent parameters."),
           "general_n": q(R, I08, "This is the general conjecture for all", "This is the general conjecture for all n>=1 ... The universal per-index obstruction pattern supplies the necessity argument")},
 "declared_reading": {
   "a_parity_gb": q(R, "docs/issues/I05.md", "the source calls each `gb` parameter odd", "the source calls each gb parameter odd but writes the mixed relation with an odd kappa in a way that leaves the right-hand parity ambiguous"),
   "b_sign_handling": q(R, "docs/issues/I05.md", "factored $\\kappa$ to the left", "I followed the displayed exchange relation literally and factored kappa to the left using supercentral signs"),
   "c_K": q(R, "docs/issues/I05.md", "recorded with `Z: \"K\"` in Schema 2", "Some resulting scalar contractions are recorded with Z: \"K\" in Schema 2, where K is the declared central identity")},
 "test_range": {"summary": "Joint symbolic system over all coordinates (K and non-K rows, 4n gb symbols against all phi): src/compare_C_triviality.py builds the sparse linear system with gb symbolic and eliminates; reports 0/4, 0/8, 0/12 free parameters. Because K rows are in the system the result is K-dependent (the K rows alone give the 4n constraints).",
                "evidence": q(R, "src/compare_C_triviality.py", "_reduce_equations(rows, len(map_parameters))", "equations, certificates = _reduce_equations(rows, len(map_parameters))")},
 "computation": {"code": ["src/compare_C_triviality.py: analyze_triviality (joint sparse elimination)", "src/C_gamma_generator.py", "src/C_coboundary_generator.py", "src/evaluate_C_gamma.py"], "hardcoded_or_placeholder": "none found"},
 "reported_numbers": {"reported": "trivial parameter dimension 0/4, 0/8, 0/12; central witnesses; all_plus_trivial=False (I08).",
                      "vs_g_summary": "g_summary (run's own data): non-K only 28->30 (2/4 directions trivial), K kept 28->32 (0/4); n=2: 168->172 (4/8) vs 168->176. The run's stated rule 'iff gb=0' matches the K-kept value, but with K dropped g_summary gives 'partial'."},
 "argument_issues": [],
 "consistency_with_data": "stated class 'trivial iff gb=0' matches g_summary K-kept value and mismatches the K-dropped value ('partial': 2/4 directions trivial for n=1, 4/8 for n=2). The conclusion is K-dependent (test b).",
 "notes": ["Its own non-K data differ from the no-sign reference by negation in 26/50 entries (g_summary 'diff neg 26'); the partial triviality of the non-K part may come from that sign convention.",
           "I08 does not state that the non-K part alone leaves 2 of 4 directions trivial; it only reports the joint (K included) result."],
})

json.dump(rows, open("/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_interactive_facts/part1.json", "w"), ensure_ascii=False, indent=1)
print(len(rows), "rows")
