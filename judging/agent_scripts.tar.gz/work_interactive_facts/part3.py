import json, sys
sys.path.insert(0, "/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_interactive_facts")
from lib import q, loc

rows = []
I08 = "docs/issues/I08.md"
FRG = "docs/issues/final_reflection.md"
NOCAL = ""

def L(R, rel, phrase):
    return loc(R, rel, phrase).split(":")[1]

# ------------------------------------------------------------ sonnet46-F
R = "thm01-R-sonnet46-F"
TS = "src/triviality_search.py"
rows.append({
 "run": R, "commit_checked": "final (e3b8d11)",
 "stated_conclusion": {"quote": None, "loc": None,
     "note": "No Step 8 report exists in the committed copy (chat-driven run). The only committed conclusion text is the script's printed string for the all-plus profile: 'CONCLUSION: The deformation is NON-TRIVIAL for all n=1,2,3.' (" + loc(R, TS, "CONCLUSION: The deformation is NON-TRIVIAL") + ")."},
 "stated_conclusion_class": "none",
 "stated_conclusion_class_note": "No report; script text concerns the all-gb=+1 profile only.",
 "scope": {"quotes": [q(R, "final_reflection.md", "**Step 8 (triviality analysis):**", "Setting up the exact rational linear system and identifying structural obstructions (gamma_eval rows with zero coboundary) ... The null-space dimension pattern null_dim = 4n was a satisfying unexpected finding.")]},
 "declared_reading": {
   "a_parity_gb": "not stated in committed files (data/C_1_gamma.json: kappa_parity 1 only)",
   "b_sign_handling": q(R, "src/C_gamma.py", "Sign convention (Option A", "Sign convention (Option A, from C_inhomogeneous_definition.md): [b_j^s, a_1^sigma]_gamma = -gb_{sigma,j,s} * kappa"),
   "c_K": "not stated; gamma data record no K entries (g_summary: 'not recorded'); Schema 1 says K = 1 'not included as an independent basis element' (data/C_1_structure.json central_elements)."},
 "test_range": {"summary": "Only the all-plus (gb=+1) profile; no per-direction or joint-rank test in committed code.",
                "evidence": q(R, TS, "The deformation gamma (Layer 3, all gb=1) is trivial iff", "The deformation gamma (Layer 3, all gb=1) is trivial iff there exists an odd linear map f ...")},
 "computation": {"code": [TS + ": rref (exact Fraction elimination), analyze, compare_support", "src/C_gamma.py", "src/C_evaluated.py", "src/C_coboundary.py", "src/C_generators.py", "src/verify_C_*.py"],
                 "hardcoded_or_placeholder": "none found"},
 "reported_numbers": {"reported": "none in committed files except script output. My execution of src/triviality_search.py in a scratch copy (not field 8): phi 32/176/528, rank(A) 28/168/516, null dim 4/8/12, rows 212/2750/13980, Consistent NO for n=1,2,3, 'structural obstruction' rows 0/2/4.",
                      "vs_reference": "rank(A) equals the reference 28/168/516.",
                      "vs_g_summary": "g_summary non-K 28->32 (0/4 dirs trivial), n=2 168->176."},
 "argument_issues": [],
 "consistency_with_data": "no stated class in the copy. Script output 'NON-TRIVIAL' for all-plus matches g_summary data_implies 'trivial iff gb=0' (both K variants).",
 "notes": ["Reflection (lines " + L(R, "final_reflection.md", "**Blocker 2") + ") says the first Step 8 report contained two factual errors (about H_2 for n=1, H_5 for n=3) that were corrected; neither the first nor the corrected report is in the copy.",
           "Calibration (gamma data with 41/50 agreement, 5 missing entries vs reference) is from g_summary: miss 5, extra 1, diff 4 (not negated)."],
})

# ------------------------------------------------------------ sonnet46-G
R = "thm01-R-sonnet46-G"
rows.append({
 "run": R, "commit_checked": "final (4c82fc5)",
 "stated_conclusion": q(R, I08, "> **Conjecture**: The inhomogeneous deformation", "Conjecture: The inhomogeneous deformation gamma(gb) of C(n+1) = osp(2|2n) is trivial (a coboundary) if and only if gb = 0 (all 4n deformation parameters vanish)."),
 "stated_conclusion_class": "trivial iff gb=0",
 "scope": {"n123": q(R, I08, "1. Every individual gb direction is non-trivial", "Evidence: 1. Every individual gb direction is non-trivial (symbolic analysis, n=1,2,3). 2. The coboundary operator rank = n_phi - 4n ... leaving exactly 4n directions outside Image(delta)."),
           "general_n": "same section: stated as a conjecture ('Conjecture')."},
 "declared_reading": {"a_parity_gb": "not stated", "b_sign_handling": "not stated (data are '=none' relative to the no-sign reference per g_summary)",
                      "c_K": "not stated in I08; K absent from the run's gamma data (g_summary 'not recorded'). Schema doc: 'K ... identified with scalar 1 ... Not a basis element' (docs/json_schema_specification.md:" + L(R, "docs/json_schema_specification.md", "Even central identity element; identified with scalar 1") + ")."},
 "test_range": {"summary": "(i) all-plus profile (gb=+1); (ii) each of the 4n gb parameters individually (gamma column in Image(A)?). No joint/combination test, no random or mixed-sign profile.",
                "evidence": q(R, I08, "Solvability ↔ triviality. The symbolic analysis checks each individual gb-parameter direction.", "The symbolic analysis checks each individual gb-parameter direction.")},
 "computation": {"code": ["src/C_triviality.py: solve_linear_system, analyze_triviality (all-plus), analyze_general_gb (per direction)", "src/C_gamma.py", "src/C_coboundary.py", "src/C_evaluate.py", "src/C_generators.py"],
                 "outputs": "data/C_triviality_report.json (committed)", "hardcoded_or_placeholder": "none found"},
 "reported_numbers": {"reported": q(R, I08, "| 1 | C(2) = osp(2\\|2) | 28 | 32 | 111 | **NO** |", "rank(A) 28/168/516, phi params 32/176/528, rows 111/1392/7027 (sparse triples), all-plus 'NO'"),
                      "vs_reference": "rank(A) equals reference 28/168/516. No [A|G] rank reported.",
                      "vs_g_summary": "g_summary: n=1 28->32 (0/4 dirs trivial), n=2 168->176 (0/8): consistent with 'each direction non-trivial'."},
 "argument_issues": [
   {"quote": q(R, I08, "**Key structural observation**: `rank(A) = n_phi - 4n`", "rank(A) = n_phi - 4n, i.e., kernel(delta) has dimension 4n = number of gb parameters. This is not a coincidence — it reflects a deep symmetry")["quote"], "loc": loc(R, I08, "**Key structural observation**: `rank(A) = n_phi - 4n`"),
    "contradicts": "(c) line " + L(R, I08, "2. The coboundary operator rank = n_phi - 4n") + " uses the same number to say 'leaving exactly 4n directions outside Image(delta)'. n_phi - rank(A) is the dimension of the kernel of A (on phi-space); the number of gamma directions outside Image(A) is rank[A|G] - rank(A) (g_summary: +4 / +8). The 'not a coincidence' relation is asserted without derivation."},
   {"quote": q(R, I08, "**Contrast with B(0,n)**", "The analogous conjecture for B(0,n) (see `docs/drafts/aoi2026_triviality_osp1_2n.tex`) states the deformation is also non-trivial.")["quote"], "loc": loc(R, I08, "**Contrast with B(0,n)**"),
    "contradicts": "(cited document not in copy) docs/drafts/ does not exist in the copy (docs/ has issues, math, json_schema_specification.md); the path appears only as a reference in docs/math/B0n_definition.md:" + L(R, "docs/math/B0n_definition.md", "aoi2026_triviality_osp1_2n.tex") + ". No file in the copy states any B(0,n) triviality conjecture."},
   {"quote": q(R, I08, "The required combination cannot be achieved because", "the epsilon-type generators introduce 4n independent constraints (one per gb direction) that exceed the effective degrees of freedom of f after the Jacobi conditions are imposed.")["quote"], "loc": loc(R, I08, "The required combination cannot be achieved because"),
    "contradicts": "(a) no code or data in the run computes 'effective degrees of freedom of f after the Jacobi conditions'; the script only does per-direction solvability."}],
 "consistency_with_data": "stated class 'trivial iff gb=0' matches g_summary data_implies 'trivial iff gb=0 / trivial iff gb=0' (n=1,2). Run's test range (individual directions, all-plus) does not cover combinations, but g_summary joint rank (28->32) also gives 'iff gb=0'. K not recorded.",
 "notes": ["Calibration agrees: only individual directions and all-plus; kernel/image confusion; cites an unread document.",
           "Reflection (" + FRG + ":" + L(R, FRG, "Triviality analysis**") + ") repeats 'all 4n gb directions are non-trivial, with rank(A) = n_phi - 4n'."],
})

# ------------------------------------------------------------ sonnet46-r2-G
R = "thm01-R-sonnet46-r2-G"
rows.append({
 "run": R, "commit_checked": "final (289e034)",
 "stated_conclusion": q(R, I08, "> The inhomogeneous deformation of C(n+1) = osp(2|2n) defined by the gb matrix", "The inhomogeneous deformation of C(n+1) = osp(2|2n) defined by the gb matrix is trivial (= a coboundary delta f) **if and only if all gb parameters are zero**."),
 "stated_conclusion_class": "trivial iff gb=0",
 "scope": {"n123": q(R, I08, "- Computational evidence for n = 1, 2, 3 showing each individual gb contribution is non-trivial", "Computational evidence for n = 1, 2, 3 showing each individual gb contribution is non-trivial"),
           "general_n": q(R, I08, "**Conjecture (Non-triviality of C(n+1) deformation):**", "Conjecture (Non-triviality of C(n+1) deformation)")},
 "declared_reading": {"a_parity_gb": "not stated", "b_sign_handling": "not stated", "c_K": "not stated; K absent from the run's data (g_summary 'not recorded'); Schema 1 K identified with scalar 1 and excluded."},
 "test_range": {"summary": "all-plus (gb=+1) and each gb parameter individually; no combinations.",
                "evidence": q(R, I08, "2. **Per-gb** (symbolic): Is each individual gb component in the coboundary image?", "Two analyses performed: 1. Specific (all gb = +1) 2. Per-gb (symbolic): Is each individual gb component in the coboundary image?")},
 "computation": {"code": ["src/C_triviality.py: build_triviality_system, gaussian_elimination, analyze_triviality_specific, analyze_general_triviality", "src/C_gamma.py", "src/C_coboundary.py", "src/C_evaluate.py"], "hardcoded_or_placeholder": "none found"},
 "reported_numbers": {"reported": q(R, I08, "| 1 | C(2) = osp(2\\|2) | 212 | 32 | 28 | 4 | **NO** |", "constraints 212/2748/13976, phi 32/176/528, rank 28/168/516, null dim 4/8/12"),
                      "vs_reference": "ranks equal reference 28/168/516 (rank of A).",
                      "vs_g_summary": "g_summary: 28->32 (0/4 dirs) / 168->176 (0/8). The run's gamma is missing 11/50 (n=1) and 68/292 (n=2) entries of the no-sign reference (g_summary 'miss')."},
 "argument_issues": [
   {"quote": q(R, I08, "2. **Coboundary kernel**", "The image of delta is (4n(2n^2+n+1) - 4n) = 4n(2n^2+n) dimensional")["quote"], "loc": loc(R, I08, "2. **Coboundary kernel**"),
    "contradicts": "(a/c) For n=1 this gives 12; the run's own table (line " + L(R, I08, "| 1 | C(2) = osp(2\\|2) | 212 |") + ") and script give rank 28/168/516, while the formula evaluates to 12 (n=1), 80 (n=2), 252 (n=3)."},
   {"quote": q(R, I08, "3. **Specific inconsistency**", "In a coboundary delta f, any contribution to [X,X] requires [X, f(X)] - [X, f(X)] - f([X,X]) = -f([X,X]), which cannot generate a nonzero term proportional to X itself when [X,X] = 0.")["quote"], "loc": loc(R, I08, "3. **Specific inconsistency**"),
    "contradicts": "(b) docs/math/C_coboundary_definition.md formula (delta f)(X,Y) = (-1)^{p(X)}[X,f(Y)] - (-1)^{(p(X)+1)p(Y)}[Y,f(X)] - f([X,Y]); for odd X=Y the first two terms are -[X,f(X)] - [X,f(X)] = -2[X,f(X)], not [X,f(X)] - [X,f(X)]."},
   {"quote": "| (E_2del1_p, E_eps1_del1_mm, H_2) | 2 | ... | (E_2del1_p, E_eps1_del1_pm, E_2del1_p) | -1 |", "loc": loc(R, I08, "| (E_2del1_p, E_eps1_del1_mm, H_2) | 2 |"),
    "contradicts": "(a) data/C_1_evaluated.json has no entry with X = E_2del1_p and Y in {E_eps1_del1_mm, E_eps1_del1_pm}; the entries with X = E_2del1_p are Y in {E_eps1_del1_pp, E_eps1_del1_mp, H_1} (checked by script). The third table row (E_mm,E_mm,E_mm)=-2 is present."},
   {"quote": q(R, I08, "- The null space dimension 4n = |odd generators|", "The null space dimension 4n = |odd generators|, indicating the obstruction space is isomorphic to the odd part of the algebra")["quote"], "loc": loc(R, I08, "- The null space dimension 4n = |odd generators|"),
    "contradicts": "(a) null dim = phi columns - rank(A) (kernel of A on phi-space), not a count of obstructions; the obstruction count is rank[A|G] - rank(A) (g_summary +4 / +8). No derivation of 'isomorphic'."},
   {"quote": q(R, I08, "**Contrast with B(0,n):**", "This scalar self-interaction can potentially be absorbed into a redefinition (trivial deformation). The CAR pair in C(n+1) does not admit such a redefinition, making all deformations non-trivial.")["quote"], "loc": loc(R, I08, "**Contrast with B(0,n):**"),
    "contradicts": "(b/literature) docs/math/B0n_definition.md:114-120 describes a_0^2 -> 1/2 + kappa*sum gb b_j^s but states nothing about triviality or redefinitions; no file in the copy supports 'can be absorbed' or 'does not admit such a redefinition'."}],
 "consistency_with_data": "stated class 'trivial iff gb=0' matches g_summary data_implies (both 'trivial iff gb=0'). Run's gamma data deviates from the reference (miss 11/50, 68/292) but ranks 28->32 hold.",
 "notes": ["Calibration: 'gamma misses Cartan components' - g_summary shows miss 11 (n=1), 68 (n=2) entries; not verified here which Z are missing.",
           "Calibration 'wrong image dimension and delta f formula' = issues 1 and 2 above."],
})

# ------------------------------------------------------------ sonnet46-r3-G
R = "thm01-R-sonnet46-r3-G"
rows.append({
 "run": R, "commit_checked": "final (ddcc3e5)",
 "stated_conclusion": q(R, I08, "The inhomogeneous deformation of C(n+1) = osp(2|2n) defined by the 4n parameters", "is trivial (i.e., equivalent to the undeformed algebra by an automorphism) **if and only if all gb parameters are zero**: gamma(gb) is trivial <=> gb_{sigma,j,s} = 0 for all sigma, j, s."),
 "stated_conclusion_class": "trivial iff gb=0",
 "scope": {"n123": q(R, I08, "1. **Symbolic evidence**:", "For each of the 4n gb parameters, the corresponding Gamma_l not in Im(delta), verified exactly over Q for n=1,2,3."),
           "general_n": q(R, I08, "**Corollary**:", "The space of non-trivial deformation classes for C(n+1) is 4n-dimensional, generated by the independent directions Gamma_{gb_{sigma,j,s}}.")},
 "declared_reading": {"a_parity_gb": q(R, "docs/issues/I05.md", "- Parity: 1 (odd parameters, consistent with kappa being odd)", "Parity: 1 (odd parameters, consistent with kappa being odd)"),
                      "b_sign_handling": "not stated beyond adopting the document's relation (final_reflection.md:" + L(R, FRG, "One minor ambiguity: the sign convention") + ")",
                      "c_K": q(R, FRG, "and correctly handling the scalar K=1 term", "correctly handling the scalar K=1 term (which cancels in valid Lie algebra brackets)")},
 "test_range": {"summary": "each gb direction individually (Gamma_l in Im(delta)?) plus four profiles (zero, all +1, all +1 except gb_p_1_p = 0, sigma-antisymmetric +-1); no random or joint-rank test over combinations.",
                "evidence": loc(R, "src/C_triviality.py", "def analyze_triviality_conditions") + " (profiles at lines " + L(R, "src/C_triviality.py", "# Test 1: zero gb") + "-" + L(R, "src/C_triviality.py", "# Test 4: gb with sigma") + ")"},
 "computation": {"code": ["src/C_triviality.py: solve_triviality, analyze_triviality_conditions, symbolic_triviality_conditions (per direction)", "src/C_gamma.py", "src/C_evaluated.py", "src/C_coboundary.py", "src/C_generators.py"],
                 "outputs": "data/triviality_report.json (committed)", "hardcoded_or_placeholder": "none found"},
 "reported_numbers": {"reported": q(R, I08, "| 1 | 28 | 32 | 4 (= 4n) | All 4 gb = 0 |", "rank(delta) 28/168/516, dim(phi) 32/176/528, 'obstruction count' 4/8/12"),
                      "vs_reference": "ranks equal the reference rank A (28/168/516).",
                      "vs_g_summary": "g_summary: 28->32 / 168->176 (0 dirs trivial). The run's own report json: all four directions 'in_image': false, n=1."},
 "argument_issues": [
   {"quote": q(R, I08, "The null space dimension of δ equals 4n", "The null space dimension of delta equals 4n = dim(Im(gamma)/Im(delta o gamma)), which is exactly the number of gb parameters. This means each gb parameter contributes an independent cohomology class in H^2(g,g).")["quote"], "loc": loc(R, I08, "The null space dimension of δ equals 4n"),
    "contradicts": "(a) the script's null_dim is n_phi - rank (src/C_triviality.py:" + L(R, "src/C_triviality.py", "null_dim = n_phi - rank") + "), the kernel of delta on phi-space; 'Im(gamma)/Im(delta o gamma)' is not defined and not computed. Cohomology classes in H^2(g,g) are claimed, but the run never checks the cocycle condition."},
   {"quote": q(R, I08, "2. **Linear independence**", "The 4n obstructions are linearly independent (each individual gb creates a distinct non-trivial class).")["quote"], "loc": loc(R, I08, "2. **Linear independence**"),
    "contradicts": "(a) the script tests Gamma_l in Im(delta) one l at a time; it does not compute the rank of the Gamma_l modulo Im(delta). (Fact from g_summary: rank[A|G]-rank(A) = 4n, so the independence is true for the run's data, but it is not what the run computed.)"},
   {"quote": q(R, I08, "3. **Consistency with B(0,n)**", "The analogous statement for B(0,n) = osp(1|2n) is that the 2n parameters gb_{a_0, b_j^pm} each create non-trivial deformations (as established in Bakalov-Sullivan / Aoi 2026).")["quote"], "loc": loc(R, I08, "3. **Consistency with B(0,n)**"),
    "contradicts": "(cited document not in copy / literature) no file in the copy states this B(0,n) result; docs/math/B0n_definition.md:" + L(R, "docs/math/B0n_definition.md", "aoi2026_triviality_osp1_2n.tex") + " only names the .tex (absent from the copy) and Bakalov-Sullivan."},
   {"quote": q(R, I08, "This matches the dimension of the cohomology group", "This matches the dimension of the cohomology group H^2_odd(g,g) relevant for odd deformations of g. The 4n-dimensional obstruction is thus the full H^2 group in this context.")["quote"], "loc": loc(R, I08, "This matches the dimension of the cohomology group"),
    "contradicts": "(a) no computation of H^2 in the run (no cocycle space computed)."},
   {"quote": q(R, I08, "Sample inconsistent equation from the all-ones assignment", "gamma(E_mm,E_mm)[E_mm] = -2 ... -4 phi_{H_1,E_mm} + 2 phi_{H_2,E_mm} = -2 ... However, combined with other constraints ... the system becomes overdetermined")["quote"], "loc": loc(R, I08, "Sample inconsistent equation from the all-ones assignment"),
    "contradicts": "(a) the displayed equation by itself is solvable (e.g. phi_{H_1,E_mm}=1/2); the inconsistency is only in the unexhibited full system."}],
 "consistency_with_data": "stated class 'trivial iff gb=0' matches g_summary data_implies ('trivial iff gb=0' both).",
 "notes": ["Reflection (" + FRG + ":" + L(R, FRG, "N_k = b_k") + ") states N_k = sum H_j - H_{n+1} - K/2 (matches my hand check against Cn1_definition.md) and says K 'cancels in valid Lie algebra brackets'; the run's gamma data do not record K (g_summary), other runs' gamma data contain K terms.",
           "Calibration agrees: directions and 4 profiles; kernel/obstruction confusion; unsupported independence and literature claims."],
})

json.dump(rows, open("/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_interactive_facts/part3.json", "w"), ensure_ascii=False, indent=1)
print(len(rows), "rows")
