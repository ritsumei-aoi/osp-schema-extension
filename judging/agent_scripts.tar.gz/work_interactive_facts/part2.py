import json, sys
sys.path.insert(0, "/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_interactive_facts")
from lib import q, loc

PY = {"python3": "Python 3.14.8", "sympy": "1.14.0 (not imported by any of these scripts unless stated)"}
rows = []
MP = "docs/issues/mathematical_proof.md"
ISS_DEF = "Cn1_definition.md section 2 ('All root generators', lines 36-44 of docs/math/Cn1_definition.md) writes every generator as an oscillator monomial with CAR/CCR relations"

# ------------------------------------------------------------ luna-C
R = "thm01-R-luna-C"
rows.append({
 "run": R, "commit_checked": "final (83f2090; no separate first commit in inventory)",
 "stated_conclusion": q(R, MP, "The supplied definitions do **not** determine necessary", "The supplied definitions do **not** determine necessary and sufficient conditions on the parameters gb_{sigma,j,s}, for n=1,2,3 or in general. In particular, they do not determine whether any nonzero gb configuration gives a trivial deformation."),
 "stated_conclusion_class": "conditional/other",
 "stated_conclusion_class_note": "Declares the question undetermined by the supplied documents; gives no gb condition. (Calibration says 'conditional conclusion depends on K'; in this copy no K-dependent condition is stated.)",
 "scope": {"n123": "no n-specific result; only dimensions/parameter counts (4|4, 11|8, 22|12; 4/8/12 parameters; 32/176/528 odd-map coefficients)",
           "general_n": q(R, MP, "It would therefore be unjustified", "It would therefore be unjustified to report a particular zero/nonzero classification or computational rank as a theorem.")},
 "declared_reading": {
   "a_parity_gb": q(R, MP, "3. The inhomogeneous-deformation document calls the", "The inhomogeneous-deformation document calls the gb parameters odd while naming C as the scalar field. Over an ordinary purely even field C, odd scalar parameters do not exist. There is also a parity mismatch in the displayed relation"),
   "b_sign_handling": "not stated (no sign convention fixed; parity mismatch declared 'must be resolved')",
   "c_K": {"quote": q(R, MP, "The natural precise interpretation", "equality of g-valued bilinear maps, gamma_gb = delta f ... If 'up to scalar' means one global scalar lambda != 0, then it does not change triviality")["quote"], "loc": loc(R, MP, "The natural precise interpretation"),
           "note": "K is not discussed; 'up to scalar' is read as a global scalar factor, not as quotienting a central scalar component."}},
 "test_range": "none (no computation of gamma, delta f or ranks)",
 "computation": {"code": "no computation code", "artifact": "docs/issues/cn1_triviality_artifacts.json (dimensions, parameter labels, odd-map coefficient counts, a textual linear-algebra specification)",
                 "hardcoded_or_placeholder": q(R, MP, "These are metadata and a reproducible computation specification", "These are metadata and a reproducible computation specification, not fabricated numerical calculations: the artifact explicitly marks the structure-constant and gamma matrices as unavailable")},
 "reported_numbers": {"reported": q(R, MP, "It follows that the dimensions for", "dimensions 4|4 (8), 11|8 (19), 22|12 (34); 4,8,12 gb parameters; odd-map coefficient counts 32, 176, 528"),
                      "vs_reference": "Counts 32/176/528 equal the phi-column counts used in the reference ranks (spec: rank A 28/168/516). No ranks reported."},
 "rerun": {"command": "no Worker computation code; cd <scratch copy>/docs/issues && python3 -I -c \"json.load(open('cn1_triviality_artifacts.json'))\"", "exit_code": 0, "result": "JSON parses; nothing regenerated", **PY},
 "argument_issues": [
   {"quote": q(R, MP, "2. The coboundary document gives a formula", "The root and selected oscillator-generator descriptions do not supply this full table.")["quote"], "loc": loc(R, MP, "2. The coboundary document gives a formula"),
    "contradicts": ISS_DEF + "; other runs (e.g. thm01-R-luna-A src/C_generators.py) generate the full structure constants from these documents alone."},
   {"quote": "(task requirement) 'Generate structured data ... representing your structure constants and gamma structures'", "loc": loc(R, "docs/issues/issue_open.md", "Connectivity"),
    "contradicts": "The run produced neither structure constants nor gamma data (artifact marks them unavailable, mathematical_proof.md:60)."}],
 "consistency_with_data": "no g_summary row (C run). Reference ranks imply 'all gb trivial' (K dropped, super) or 'iff gb=0' (otherwise); the run states neither.",
 "notes": ["Deliverables: mathematical_proof.md, cn1_triviality_artifacts.json, final_reflection.md, supplementary_metrics.md."],
})

# ------------------------------------------------------------ luna-r2-C
R = "thm01-R-luna-r2-C"
rows.append({
 "run": R, "commit_checked": "final (3ae4af3)",
 "stated_conclusion": q(R, MP, "The supplied definitions do **not** determine necessary", "The supplied definitions do not determine necessary and sufficient conditions on the gb for the intended equality gamma_gb = delta f. ... There is a definitive conclusion under the literal central-extension reading: ... forces every gb_{sigma,j,s}=0. This is a conditional conclusion about that reading"),
 "stated_conclusion_class": "conditional/other",
 "stated_conclusion_class_note": "Undetermined for the intended adjoint reading; 'gb = 0' only under the literal reading in which the gamma term is central-valued (kappa) and delta f is g-valued, so that equality forces both to vanish. That conditional result depends on treating the deformation term as K/kappa-valued, i.e. it would change if the central components were dropped.",
 "scope": {"n123": q(R, MP, "For each of these ranks, the same coefficient-space", "For each of these ranks, the same coefficient-space ambiguity and missing map remain. ... there is no valid rank-specific linear-system result to report for n=1,2,3."),
           "general_n": "same: no general-n result beyond the conditional literal-reading statement"},
 "declared_reading": {
   "a_parity_gb": q(R, MP, "The listed \\(gb\\)-data consist of", "The listed gb-data consist of 4n odd parameters"),
   "b_sign_handling": "not stated",
   "c_K": q(R, MP, "These are not interchangeable coefficient spaces", "In a central extension, the deformation term is central-valued. In an adjoint extension, kappa g is a copy of the g-module, and in general is not central.")},
 "test_range": "none",
 "computation": {"code": "no computation code", "artifact": "docs/issues/cn1_triviality_verification.json (counts; unavailable tensors marked null)",
                 "hardcoded_or_placeholder": q(R, MP, "explicitly marks the unavailable tensors as", "explicitly marks the unavailable tensors as `null`, rather than fabricating them")},
 "reported_numbers": {"reported": "dimension and parameter-count table (4|4,11|8,22|12; 4,8,12 params)", "vs_reference": "no ranks"},
 "rerun": {"command": "no Worker computation code; python3 -I json.load of docs/issues/cn1_triviality_verification.json", "exit_code": 0, "result": "JSON parses; nothing regenerated", **PY},
 "argument_issues": [
   {"quote": q(R, MP, "For each of these ranks, the same coefficient-space", "The supplied text does not provide enough data to compute structure constants for a homogeneous basis, the entries of gamma_gb, or the matrix of delta on odd linear maps.")["quote"], "loc": loc(R, MP, "The supplied text does not provide enough data") if True else "",
    "contradicts": ISS_DEF + "; other runs derived all three from these documents."}],
 "consistency_with_data": "no g_summary row (C run). The conditional 'gb=0' coincides with the K-kept reference conclusion; the run does not state the K-dropped alternative.",
 "notes": ["Deliverables: mathematical_proof.md, cn1_triviality_verification.json."],
})

# ------------------------------------------------------------ luna-r3-C
R = "thm01-R-luna-r3-C"
rows.append({
 "run": R, "commit_checked": "final (e890c66)",
 "stated_conclusion": q(R, MP, "The supplied definitions do **not** determine a necessary-and-sufficient", "The supplied definitions do not determine a necessary-and-sufficient condition on the 4n parameters for triviality as an adjoint-valued 2-cocycle. ... if gamma_gb is regarded as C kappa-valued and delta f as g-valued, equality in g + C kappa implies that both sides are zero. Consequently, triviality in that literal sense is equivalent to gamma_gb=0"),
 "stated_conclusion_class": "conditional/other",
 "stated_conclusion_class_note": "Same structure as luna-r2-C: undetermined for the adjoint-valued problem; 'gb = 0' (at the level of the exchange relations) only under the literal direct-sum reading. Depends on keeping the central (kappa) component.",
 "scope": {"n123": q(R, MP, "The dimension and parameter counts agree", "all three cases fail the same consistency checks. No n-specific structure constants can remove these type-level contradictions."),
           "general_n": "no general-n result"},
 "declared_reading": {
   "a_parity_gb": q(R, MP, "If the \\(gb\\)'s are meant to be", "If the gb's are meant to be ordinary complex scalars, they are even and the parity equation is consistent only after removing the document's assertion that they are odd parameters."),
   "b_sign_handling": "not stated",
   "c_K": q(R, MP, "3. **Equality modulo a scalar or after projection.**", "Equality modulo a scalar or after projection. A projection, quotient, scalar normalization, or module map must be stated. Different choices can change the kernel and hence the triviality conditions.")},
 "test_range": "none",
 "computation": {"code": ["docs/issues/verify_cn1_artifacts.py: asserts dimension formulas, parity arithmetic (1+1=0) and string flags stored in cn1_triviality_artifacts.json (e.g. status string, 'intended_adjoint_module_map_specified' is False)"],
                 "hardcoded_or_placeholder": "The asserted conclusion flags are stored in the JSON and re-asserted by the script (e.g. data['status'] == 'adjoint_valued_problem_underdetermined_and_definitions_inconsistent'); no gamma, delta f or rank computed.",
                 "evidence": q(R, "docs/issues/verify_cn1_artifacts.py", "adjoint_valued_problem_underdetermined", 'assert data["status"] == ("adjoint_valued_problem_underdetermined_and_definitions_inconsistent")')},
 "reported_numbers": {"reported": "dimension/parameter counts only (table in 'Checks for n=1,2,3')", "vs_reference": "no ranks"},
 "rerun": {"command": "cd <scratch copy>/docs/issues && timeout 600 python3 verify_cn1_artifacts.py", "exit_code": 0,
           "result": "prints JSON {validated_cases [1,2,3], dimension_and_parameter_counts: consistent, declared_parity_assignment: inconsistent, literal_coboundary_target_intersection: zero, adjoint_valued_triviality_decidable_from_inputs: false}; no files regenerated (diff -rq against final copy: none)", **PY},
 "argument_issues": [
   {"quote": q(R, MP, "neither the full structure-constant table in a fixed basis", "The supplied documents give neither the full structure-constant table in a fixed basis nor this map.")["quote"], "loc": loc(R, MP, "neither the full structure-constant table"),
    "contradicts": ISS_DEF + "."}],
 "consistency_with_data": "no g_summary row (C run).",
 "notes": ["Report separately lists the three readings of 'up to scalar' (lines 86-108) and refuses to choose one."],
})

# ------------------------------------------------------------ sonnet46-C
R = "thm01-R-sonnet46-C"
rows.append({
 "run": R, "commit_checked": "final (49db534)",
 "stated_conclusion": q(R, MP, "**The inhomogeneous deformation $\\gamma_{\\mathrm{gb}}$ of", "The inhomogeneous deformation gamma_gb of C(n+1) = osp(2|2n) is trivial if and only if gb = 0."),
 "stated_conclusion_class": "trivial iff gb=0",
 "scope": {"n123": q(R, MP, "\"C2_n1\": {\"algebra\"", "JSON table lists 'trivial iff all gb=0' for n=1,2,3, but only n=1 formulas (Props 2.2, 2.3) are derived in the text"),
           "general_n": q(R, MP, "**Step 5: General $n$.**", "Each j contributes an independent set of 4 parameters ... The different j-sectors decouple because the root system for different j indices involves orthogonal bosonic generators. Therefore all 4n parameters must vanish.")},
 "declared_reading": {
   "a_parity_gb": "not stated (only 'p(gamma(X,Y)) = p(X)+p(Y)+1 since p(kappa)=1', line " + loc(R, MP, "Note: $p(\\gamma_{\\mathrm{gb}}(X,Y))").split(":")[1] + ")",
   "b_sign_handling": q(R, MP, "$$b_j^s \\cdot a_1^\\sigma = a_1^\\sigma", "Lemma 2.1: b_j^s a_1^sigma = a_1^sigma b_j^s - gb kappa (no sign from moving kappa stated)"),
   "c_K": q(R, MP, "(in the adjoint representation, up to scalar $K$-terms)", "gamma_gb = delta f (in the adjoint representation, up to scalar K-terms)")},
 "test_range": "no computation; argument covers only the pair (H_2, E_{eps-delta_j}) in detail (Step 2) and says the other three directions follow 'by the same argument'.",
 "computation": {"code": ["scripts/verify_triviality.py: no linear algebra; static dictionaries and prints"],
                 "hardcoded_or_placeholder": [
                    q(R, "scripts/verify_triviality.py", "# Computed from deformed oscillator algebra", "# Computed from deformed oscillator algebra: b^s a^sigma = a^sigma b^s - gb*kappa  (followed by hard-coded GAMMA_GB_N1 dict)"),
                    q(R, "scripts/verify_triviality.py", "\"conclusion\": \"gb_pm = 0 is necessary for triviality\"", "OBSTRUCTIONS list with the conclusions written as literals"),
                    q(R, "scripts/verify_triviality.py", "params = {f\"gb_{s}{j}{t}\": 0", "triviality_theorem(n): 'triviality_conditions' = a dict of zeros")]},
 "reported_numbers": {"reported": "none (no ranks); report states 'n_params' 4,8,12 in JSON block", "vs_reference": "no ranks"},
 "rerun": {"command": "cp -R run copy to scratch; cd copy; timeout 600 python3 scripts/verify_triviality.py", "exit_code": 0,
           "result": "prints the static dictionaries and the theorem text for n=1,2,3; no output files; scratch tree identical to committed copy afterwards (diff -rq empty). Regenerated stdout reproduces the literals; nothing is computed.", **PY},
 "argument_issues": [
   {"quote": q(R, MP, "The resulting equation for the $H_2$-component", "0 + 0 - phi_{H_2} = -gb_{+,j,-}, giving phi_{H_2} = gb_{+,j,-}. So f(E_{eps-delta_j}) = gb_{+,j,-} H_2 + (other even generators).")["quote"], "loc": loc(R, MP, "The resulting equation for the $H_2$-component"),
    "contradicts": "The same Step 2 derives a solvable equation for the H_2 component, yet the summary (line " + loc(R, MP, "the $\\mathfrak{so}(2)$-Cartan element $H_2$ appears").split(":")[1] + ") says H_2 'cannot be produced by any delta f'; and Step 4 (line " + loc(R, MP, "From the even-odd pair $(H_2, E_{\\varepsilon-\\delta_j})$ the full equation").split(":")[1] + ") asserts 'self-consistent only if gb_{+,j,-} = 0' without derivation."},
   {"quote": q(R, MP, "The bracket $[E_{\\varepsilon+\\delta_j}, E_{-\\varepsilon-\\delta_j}]", "[E_{eps+delta_j}, E_{-eps-delta_j}] = -(H_1 + 2H_2) + K (mod scalar) ... the equation requires -gb_{+,j,+} H_2 from the remaining terms")["quote"], "loc": loc(R, MP, "The bracket $[E_{\\varepsilon+\\delta_j}, E_{-\\varepsilon-\\delta_j}]"),
    "contradicts": "(c) line 130 gives the target as 2 gb_{+,j,-} E_{2 delta_j} (an E_{2delta} component) while this step analyses H_1/H_2 components and gb_{+,j,+}. (b) Direct normal ordering from Cn1_definition.md (a^+b^+ a^-b^- + a^-b^- a^+b^+ = N_b + 1 - N_f) gives exactly -H_1 - 2H_2 with no K term (my hand computation; not run code)."},
   {"quote": "OBSTRUCTIONS: pair ('H2','Eed') gamma {'E2d': '2*gb_pm'} ... conclusion 'gb_pp = 0 is necessary'; pair ('H2','E-ed') gamma {'E2d': '2*gb_mm'} ... conclusion 'gb_mp = 0'", "loc": loc(R, "scripts/verify_triviality.py", "\"pair\": (\"H2\", \"Eed\")"),
    "contradicts": "(c) the stated gamma entries use gb_pm / gb_mm while the conclusion drawn for the same pair names gb_pp / gb_mp; Step 3 of the report (line " + loc(R, MP, "The bracket $[E_{\\varepsilon+\\delta_j}, E_{-\\varepsilon-\\delta_j}]").split(":")[1] + ") names gb_{+,j,+}. The derivation connecting them is not in the files."},
   {"quote": q(R, "final_reflection.md", "Successfully computed explicit", "Successfully computed explicit gamma_gb values from first principles using the deformed oscillator algebra")["quote"], "loc": loc(R, "final_reflection.md", "Successfully computed explicit"),
    "contradicts": "(a) scripts/verify_triviality.py contains the gamma values as literals (GAMMA_GB_N1) and no code computing them; reflection also says (final_reflection.md:" + loc(R, "final_reflection.md", "I used only the Bash tool").split(":")[1] + ") a Python verification script was run: it only prints those literals."}],
 "consistency_with_data": "no g_summary row (C run). Conclusion 'iff gb=0' with K 'modulo scalar K' (K dropped); spec reference for K dropped + supercommuting is 'all gb trivial', for K dropped + non-super (odd gb, no signs) data of other runs gives 28->32 (iff gb=0). The run's gamma entry gamma(H_2,E_{eps+delta_1}) = +2 gb_{+,1,-} E_{2delta_1} equals the value in thm01-R-luna-A data (graded sign, K dropped).",
 "notes": ["Calibration agrees: no computation; values and conclusion written into code; obstruction argument handles the -f([H_2,E]) term by replacing f([H_2,E]) with f(E) and arrives at a solvable equation (line 126-127).",
           "Initial parity note in reflection (final_reflection.md:24) says p(gamma) confusion was corrected."],
})

# ------------------------------------------------------------ sonnet46-r2-C
R = "thm01-R-sonnet46-r2-C"
VA = "docs/issues/verification_artifacts.py"
rows.append({
 "run": R, "commit_checked": "final (079dd8e)",
 "stated_conclusion": q(R, MP, "**Necessary and sufficient condition for triviality of", "No restriction. Every gamma_gb is trivial for all (gb_{sigma,j,s}) in C^{4n}."),
 "stated_conclusion_class": "all gb trivial",
 "scope": {"n123": q(R, MP, "### 4.3 Verification Sketch", "Verification Sketch for C(2), n=1: one pair (H_2, E_{eps+delta_1}), one component"),
           "general_n": q(R, MP, "**Theorem (Universal Triviality).**", "Let g = C(n+1) for n >= 1. Every inhomogeneous deformation gamma_gb parametrized by {gb} in C^{4n} is trivial ... triviality holds for all parameter values.")},
 "declared_reading": {
   "a_parity_gb": "not stated (gb in C^{4n}, ordinary complex numbers)",
   "b_sign_handling": "not stated (parity check only: delta f has parity p(X)+p(Y)+1, line " + loc(R, MP, "**Parity check**").split(":")[1] + ")",
   "c_K": q(R, MP, "The \"up to scalar\" condition acknowledges", "The 'up to scalar' condition acknowledges that two coboundaries differing by a scalar multiple of the identity operator id_g (a central derivation) are identified.") ,
   "c_K_code": q(R, VA, "#   The \"up to scalar\" condition means we drop the scalar 1/2.", "The 'up to scalar' condition means we drop the scalar 1/2.")},
 "test_range": "one sample profile gb=(0.5,0.3,0.7,0.2) and one component of one pair (H_2, E_epd1) for n=1; no joint rank, no direction-wise test, no n=2,3.",
 "computation": {"code": [VA + ": compute_f_odd_generators, compute_gamma_gb_sample, verify_trivial_for_pair (no linear algebra)"],
                 "hardcoded_or_placeholder": [
                    q(R, VA, "results = {\"E_2d1\": -2 * gpm}", "gamma(H2,E_epd1) written as the literal {'E_2d1': -2*gpm}"),
                    q(R, VA, "delta_f_H2_epd1_E2d1 = -4 * alpha_pp + 2 * alpha_pp", "delta f coefficient written as the literal -4*alpha_pp + 2*alpha_pp"),
                    q(R, VA, "\"delta_f_matches\": True", "JSON field delta_f_matches written as the literal True"),
                    q(R, VA, "print(\"Triviality condition: ALWAYS SATISFIED", "unconditional conclusion print")]},
 "reported_numbers": {"reported": "none (no ranks); sample values only (computed=-0.6, expected=-0.6)", "vs_reference": "no ranks"},
 "rerun": {"command": "cp -R run copy to scratch; cd copy; timeout 600 python3 docs/issues/verification_artifacts.py", "exit_code": 0,
           "result": "prints f on odd generators, 'computed=-0.6000, expected=-0.6000, match=True', the unconditional conclusion, and a JSON artifact; stdout saved in work_interactive_facts/out_s46r2C.txt; no files in the copy changed (diff -rq empty). Both 'computed' and 'expected' are -2*gb['gb_+_1_-'] (alpha_pp and gpm read the same key), so the match is by construction.", **PY},
 "argument_issues": [
   {"quote": q(R, MP, "$C(n+1) = \\mathfrak{osp}(2|2n)$ is a **basic classical simple", "analog of Whitehead's second lemma holds: H^2(g; M) = 0 ... Taking M = g with the adjoint action gives H^2(g;g) = 0.")["quote"], "loc": loc(R, MP, "$C(n+1) = \\mathfrak{osp}(2|2n)$ is a **basic classical simple"),
    "contradicts": "(literature claim) No document in the copy states or sources this vanishing statement (docs/math has no such lemma); reflection names it 'Whitehead/Kostant vanishing theorem' (final_reflection.md:" + loc(R, "final_reflection.md", "Whitehead/Kostant").split(":")[1] + "). The run also never checks that gamma_gb is a 2-cocycle (no code)."},
   {"quote": q(R, MP, "$$(\\delta f)(H_2, E_{\\varepsilon+\\delta_1}) = [H_2, f(E_{\\varepsilon+\\delta_1})]", "(delta f)(H_2,E_{eps+delta_1}) = [H_2, f(E)] + [E, f(H_2)] - f(-E) = gb*2*(-2E_{2delta_1}) + [odd terms] + gb*2E_{2delta_1} = -2 gb E_{2delta_1}  checkmark")["quote"], "loc": loc(R, MP, "$$(\\delta f)(H_2, E_{\\varepsilon+\\delta_1}) = [H_2, f(E_{\\varepsilon+\\delta_1})]"),
    "contradicts": "(a/c) The term [E_{eps+delta_1}, f(H_2)] is bracket of two odd elements, hence even (it can have an E_{2delta_1} component), but is labelled '[odd terms]' and dropped; f(H_2) is never defined (report line " + loc(R, MP, "**Even generators** (mapped to odd)").split(":")[1] + " only says 'fixed by the Leibniz condition')."},
   {"quote": "f(E_{eps+delta_k}) = sum_j (gb_{+,j,-} E_{delta_j+delta_k} + gb_{+,j,+} [b_j^- b_k^+]) (report line " + loc(R, MP, "$$f(E_{\\varepsilon+\\delta_k}) = \\sum_j").split(":")[1] + "); f(E_{eps+delta_1}) = gb_{+,1,-}*2E_{2delta_1} (line " + loc(R, MP, "On the coboundary side, with $f(E_{\\varepsilon+\\delta_1})").split(":")[1] + "); f_E_epd1 = {'E_2d1': 2*alpha_pp, 'H2': -alpha_pm} (" + VA + ":" + loc(R, VA, "f_E_epd1 = {").split(":")[1] + ")",
    "loc": loc(R, MP, "$$f(E_{\\varepsilon+\\delta_k}) = \\sum_j"),
    "contradicts": "(c) three different expressions for f(E_{eps+delta_1}): with a gb_{+,1,+} term of non-basis element b^-b^+ (report), without it (verification sketch), with -gb_{+,1,+} H_2 after dropping the scalar (script)."},
   {"quote": "results = {\"H2\": gpp}  # up to scalar (dropping central 1/2 term)  [comment above: '= gpp*b1+b1- ~ gpp*N_b ~ -gpp*H2']", "loc": loc(R, VA, "results = {\"H2\": gpp}"),
    "contradicts": "(c) the comment two lines above gives -gpp*H2, the code writes +gpp."},
   {"quote": "ROOT_EIGENVALUES: E_epd1 (1,-1), E_emd1 (1,1), E_2d1 (0,-2) ... BRACKETS_C2: ('E_emd1','E_mepd1'): {'H1':1,'H2':1}, ('E_epd1','E_memd1'): {'H1':1,'H2':-1}", "loc": loc(R, VA, "ROOT_EIGENVALUES = {"),
    "contradicts": "(b) Direct evaluation from the oscillator realization in docs/math/Cn1_definition.md (H_1 = a^+a^- + b^+b^-): [H_1,a^+b^+] = 2 a^+b^+, [H_1,a^+b^-] = 0, [H_1,(b^+)^2/2] = 2(b^+)^2/2, {a^+b^-,a^-b^+} = H_1, {a^+b^+,a^-b^-} = -H_1-2H_2 (my hand computation). The listed H_1 eigenvalues and odd-odd brackets differ. These dictionaries are not used by the check but are given as 'structure constants of osp(2|2)' (report line " + loc(R, MP, "- Structure constants of").split(":")[1] + ")."},
   {"quote": q(R, "final_reflection.md", "Produced a runnable Python verification script", "Produced a runnable Python verification script that confirmed delta f = gamma_gb for the sample pair (H_2, E_{eps+delta_1}) with n=1")["quote"], "loc": loc(R, "final_reflection.md", "Produced a runnable Python verification script"),
    "contradicts": "(a) see rerun: both sides of the comparison are the same literal -2*gb['gb_+_1_-']; gamma is hard-coded (verification_artifacts.py:" + loc(R, VA, "results = {\"E_2d1\": -2 * gpm}").split(":")[1] + ")."}],
 "consistency_with_data": "no g_summary row (C run). Stated class 'all gb trivial' matches the reference conclusion for the K-dropped / supercommuting reading and mismatches the 'iff gb=0' reading. The run drops scalar terms ('up to scalar'). The run's gamma(H_2,E_{eps+delta_1}) = -2 gb_{+,1,-} E_{2delta_1} has opposite sign to the same entry in thm01-R-luna-A data (+2*gb_a1_p_b1_m, graded convention) and to sonnet46-C's value (cross-run observation only; sign conventions differ).",
 "notes": ["Calibration agrees: no gamma/delta f computed; verification values written into code; relies on Whitehead lemma."],
})

# ------------------------------------------------------------ sonnet46-r3-C
R = "thm01-R-sonnet46-r3-C"
VT = "verify_triviality.py"
rows.append({
 "run": R, "commit_checked": "final (3ed5f21)",
 "stated_conclusion": q(R, MP, "**The inhomogeneous deformation $\\gamma_{gb}$ of $C(n+1)", "The inhomogeneous deformation gamma_gb of C(n+1) = osp(2|2n) is trivial ... if and only if all deformation parameters gb vanish. This result holds for all n >= 1."),
 "stated_conclusion_class": "trivial iff gb=0",
 "scope": {"n123": q(R, MP, "For each $n$, the contradiction in Section 3.3 applies", "For each n, the contradiction in Section 3.3 applies to the sl(2) subalgebra {H_{n+1}, E_{2delta_n}, E_{-2delta_n}} with associated odd generators"),
           "general_n": q(R, MP, "The same contradiction arises:", "For any single nonzero gb_{sigma,j,s}: the Cartan-component constraints ... become overdetermined in the same way.")},
 "declared_reading": {
   "a_parity_gb": q(R, MP, "If the $gb$'s are meant to be ordinary complex scalars", "If the gb's are meant to be ordinary complex scalars, they are even ... (this is in the luna files, not here)") if False else "not stated (gamma-tilde treated as an odd 2-cochain with values in g; kappa odd central, line " + loc(R, MP, "The algebra extends to $L").split(":")[1] + ")",
   "b_sign_handling": "not stated",
   "c_K": q(R, MP, "1. In the oscillator realization, number operators produce constants", "Working up to scalar means we quotient by C.Id when identifying g-valued expressions.")},
 "test_range": "one direction only: gb_{+,1,+}=1, others 0, n=1, via two pairs (F1,H2),(F1,H1) with hard-coded gamma-tilde; n=2,3 are a table of the form 'gb = 0' with no computation; general n by analogy.",
 "computation": {"code": [VT + ": numpy float least squares on a 16x32 system built from hand-typed structure constants and hard-coded gamma-tilde"],
                 "hardcoded_or_placeholder": [
                    q(R, VT, "gt[1, 4, 0] = -1.0;", "gamma_tilde(F1,H1) = -H2 written as a literal (and gt(H1,F1))"),
                    q(R, VT, "gt[1, 4, 1] = 1.0;", "gamma_tilde(F1,H2) = H2 written as a literal"),
                    q(R, VT, "gt[4, 4, 4] = -2.0", "gamma_tilde(F1,F1) = -2 F1 written as a literal"),
                    q(R, VT, "This script checks the coboundary inconsistency for n=1 symbolically.", "docstring says 'symbolically'; the code uses numpy float lstsq (line " + loc(R, VT, "np.linalg.lstsq").split(":")[1] + ")")],
                 "evidence_report_table": q(R, MP, "| 1 | $4\\|4$ | 4 | $gb = 0$ |", "n=1,2,3 rows all 'gb = 0' with 'Same target-space and parity obstructions' (line " + loc(R, MP, "| 1 | $4\\|4$ | 4 | Same").split(":")[1] + ")") if False else "Section 5 table (line " + loc(R, MP, "| 1 | $4\\|4$ | 4 | $gb = 0$ |").split(":")[1] + ") lists n=1,2,3 as 'gb = 0'; only n=1 has any computation"},
 "reported_numbers": {"reported": q(R, "final_reflection.md", "The Python verification script confirmed inconsistency", "residual = 0.6, rank = 6 of a 16 x 32 system"), "vs_reference": "Not comparable with reference ranks (reference rank A = 28 for the full system; this is a 2-pair subsystem). Rerun reproduces rank 6 and residual 0.6."},
 "rerun": {"command": "cp -R run copy to scratch; cd copy; timeout 600 python3 verify_triviality.py", "exit_code": 0,
           "result": "stdout: System shape (16, 32), rank 6, least-squares residual 0.600000, 'INCONSISTENT'; JSON record printed (67 lines). Numerically identical to reflection's reported residual/rank. No output files written (diff -rq empty). numpy 2.4.4.", **PY},
 "argument_issues": [
   {"quote": "{F2,F3} = H1 - 2H2 (mod scalar) (report line " + loc(R, MP, "(\"F2\", \"F3\"): {\"H1\": 1, \"H2\": -2}").split(":")[1] + "; script line " + loc(R, VT, "set_bracket(5, 6").split(":")[1] + ")", "loc": loc(R, VT, "set_bracket(5, 6"),
    "contradicts": "(b) Cn1_definition.md realization: a^+b^- a^-b^+ + a^-b^+ a^+b^- = N_f + N_b = H_1 exactly (my hand computation); the script line itself carries the comment 'mod scalar +1 in H1? adjust'."},
   {"quote": "[H2,F1] = +F1, [H2,F3] = +F3 (script lines " + loc(R, VT, "set_bracket(1, 4, {4:  1})").split(":")[1] + "-" + loc(R, VT, "set_bracket(1, 7, {7: -1})").split(":")[1] + ") while [H2,E2d] = -2 E2d (line " + loc(R, VT, "set_bracket(1, 2, {2: -2})").split(":")[1] + ")", "loc": loc(R, VT, "set_bracket(1, 4, {4:  1})"),
    "contradicts": "(c) F1 = a^+b^+ and E2d = (b^+)^2/2 both carry b^+; with [H2,E2d] = -2E2d the eigenvalue of F1 is -1, not +1 ([H_2,b^+] = -b^+ for H_2 = -b^+b^- - 1/2). Also the report (line " + loc(R, MP, "and $[H_2, E_{\\pm 2\\delta_1}] = \\mp 2E_{\\pm 2\\delta_1}$").split(":")[1] + ") uses [H_2,E_{+2delta}] = -2E."},
   {"quote": "set_bracket(2, 5, {4: 1})  # [E2d, F2] = F1 ; set_bracket(3, 4, {5: -1})  # [Em2d, F1] = -F2", "loc": loc(R, VT, "set_bracket(2, 5, {4:  1})"),
    "contradicts": "(b) with [b^-,b^+] = 1: [(b^+)^2/2, a^+b^-] = -a^+b^+ and [(b^-)^2/2, a^+b^+] = +a^+b^- (my hand computation)."},
   {"quote": "gamma_tilde(F1,H1) = -H2 (report line " + loc(R, MP, "$$\\tilde{\\gamma}(F_1, H_1) \\equiv").split(":")[1] + ", derived by 'Similarly,' at line " + loc(R, MP, "**Bracket $[F_1, H_1]_{\\rm def}$:**").split(":")[1] + ")", "loc": loc(R, MP, "$$\\tilde{\\gamma}(F_1, H_1) \\equiv"),
    "contradicts": "(a/c) The derivation of gamma-tilde(F1,H1) is not shown; the contradiction '-2 = -1' (line " + loc(R, MP, "**Contradiction.**").split(":")[1] + ") depends on it. In thm01-R-luna-A generated data (graded signs, K dropped, same relation [b,a] = -gb kappa) gamma(E_{eps+delta_1}, H_1) = gb_{a+,b+} H_1 + 2 gb_{a+,b-} E_{2delta_1} (no H_2 term), cross-run observation only."},
   {"quote": q(R, MP, "1. The 2-cochain $\\tilde{\\gamma} = \\gamma_{gb}/\\kappa$ is an odd cochain in", "The 2-cochain gamma-tilde is an odd cochain in Z^2_odd(g,g).")["quote"], "loc": loc(R, MP, "1. The 2-cochain $\\tilde{\\gamma} = \\gamma_{gb}/\\kappa$ is an odd cochain in"),
    "contradicts": "(a) no code or derivation checks the cocycle condition."},
   {"quote": q(R, VT, "All structure constants are derived from the oscillator realization", "All structure constants are derived from the oscillator realization in docs/math/.")["quote"], "loc": loc(R, VT, "All structure constants are derived from the oscillator realization"),
    "contradicts": "(a) the constants are typed by hand as literals (set_bracket calls), no oscillator code."}],
 "consistency_with_data": "no g_summary row (C run). Stated class 'iff gb=0' with 'up to scalar' = scalars quotiented (K dropped). Reference: K dropped + supercommuting gives 'all gb trivial'; K dropped + odd gb/no sign (data of luna-G, sonnet46-G etc.) gives 28->32, 'iff gb=0'. The run does not state which sign convention it uses.",
 "notes": ["Calibration agrees: one direction n=1, floating point; n=2,3 table without computation; general n by analogy."],
})

json.dump(rows, open("/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_interactive_facts/part2.json", "w"), ensure_ascii=False, indent=1)
print(len(rows), "rows")
