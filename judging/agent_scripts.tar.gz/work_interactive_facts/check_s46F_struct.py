import json
for n in (1,2,3):
    s=json.load(open(f'thm01-R-sonnet46-F/data/C_{n}_structure.json'))['structure_constants']
    print(n,'[H_1,E_pm]:',[e for e in s if e['X']=='H_1' and e['Y']=='E_eps1_del1_pm'],
          '[E_pm,E_mp]:',[(e['Z'],e['coeff']) for e in s if e['X']=='E_eps1_del1_pm' and e['Y']=='E_eps1_del1_mp'],
          '[E_pm,E_mp] Z=H_k>=2:',[e['Z'] for e in s if e['X']=='E_eps1_del1_pm' and e['Y']=='E_eps1_del1_mp' and e['Z'] in('H_2','H_3')])
