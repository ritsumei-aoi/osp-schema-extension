import json, os, re
J = "/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final"
J = J.replace("5f641591-e209-4556-85bf-", "5f641591-e209-4556-85bf-")  # no-op

def _root():
    p = "/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final"
    return p

ROOT = None
for cand in os.listdir("/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation"):
    pth = f"/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/{cand}/scratchpad/jroot/final"
    if os.path.isdir(pth):
        ROOT = pth

def loc(run, rel, phrase):
    """Return 'rel:line' of the line where phrase starts (matching across line breaks, whitespace-normalised)."""
    path = os.path.join(ROOT, run, rel)
    with open(path, encoding="utf-8") as f:
        lines = f.read().split("\n")
    norm = lambda t: re.sub(r"\s+", " ", re.sub(r"[*`$\\>_{}]", "", t))
    P = norm(phrase).strip()
    for i in range(len(lines)):
        if not norm(lines[i]).strip():
            continue
        chunk = norm(" ".join(lines[i:i+6])).strip()
        if chunk.startswith(P) or (P in norm(lines[i]) ) or (P in chunk and P.split(" ")[0] in lines[i] and chunk.find(P) < len(norm(lines[i]))+1):
            return f"{rel}:{i+1}"
    raise AssertionError(f"phrase not found: {run} {rel} {phrase!r}")

def q(run, rel, phrase, quote=None, maxlen=300):
    """Quote object with verified location. quote defaults to the phrase."""
    l = loc(run, rel, phrase)
    t = (quote or phrase).strip()
    if len(t) > maxlen:
        t = t[: maxlen - 3] + "..."
    return {"quote": t, "loc": l}
