import sys, json
from fractions import Fraction
sys.path.insert(0,'thm01-R-sonnet46-F/src')
import triviality_search as T
D='thm01-R-sonnet46-F/data/'
for n in (1,2,3):
    r=T.analyze(n)
    print('n',n,'phi',r['n_phi'],'rows',r['n_rows'],'rank',r['rank'],'null',r['solution_dim'],'cons',r['is_consistent'],'incons',r['n_inconsistent'],'gamma_only',len(r['rows_gamma_only']))
    g=json.load(open(D+f'C_{n}_gamma.json'))['inhomogeneous_deformation']['gamma_entries']
    pair=[(e['Z'],[(t['gb'],t['scalar']) for t in e['gb_terms']]) for e in g if e['X']=='H_1' and e['Y']=='E_eps1_del1_pm']
    print(' gamma(H_1,E_pm):',pair)
    cob=r['cob_coeffs']
    print(' cob Z for (H_1,E_pm):',sorted(k[2] for k in cob if k[0]=='H_1' and k[1]=='E_eps1_del1_pm'))
    print(' gamma_only rows:',[(k,str(v)) for k,v in r['rows_gamma_only']])
    print(' #gamma entries Z=H_2:',sum(1 for e in g if e['Z']=='H_2'),' #cob entries Z=H_2:',sum(1 for k in cob if k[2]=='H_2'))
    s1=json.load(open(D+f'C_{n}_structure.json')); print(' even basis H:',[b for b in s1['basis']['even'] if b.startswith('H_')])
    # single gb and joint
    gbs=sorted({t['gb'] for e in g for t in e['gb_terms']})
    phi_idx={p:i for i,p in enumerate(r['phi_list'])}
    rows=r['all_rows']; ridx={k:i for i,k in enumerate(rows)}
    A=[[Fraction(0)]*r['n_phi'] for _ in rows]
    for k,c in cob.items():
        for p,v in c.items(): A[ridx[k]][phi_idx[p]]=v
    def cons(bvec):
        pc,ok,sd,inc,M=T.rref(A,bvec); return ok,len(inc),len(pc)
    cols={}
    for e in g:
        for t in e['gb_terms']:
            k=(e['X'],e['Y'],e['Z'])
            if k in ridx:
                cols.setdefault(t['gb'],[Fraction(0)]*len(rows))
                cols[t['gb']][ridx[k]]+=Fraction(t['scalar'])
            else:
                cols.setdefault(t['gb'],[Fraction(0)]*len(rows))
    if n==1:
        for gb in gbs:
            print(' single',gb,cons(cols[gb]))
    # joint: rank of [A|G]
    if n<=2:
        M=[A[i]+[cols[gb][i] for gb in gbs] for i in range(len(rows))]
        pc,ok,sd,inc,MM=T.rref(M,[Fraction(0)]*len(rows))
        print(' joint rank [A|G] =',len(pc),'(rank A =',r['rank'],') note: gamma entries absent from row set are dropped:',sum(1 for e in g for t in e['gb_terms'] if (e['X'],e['Y'],e['Z']) not in ridx))
