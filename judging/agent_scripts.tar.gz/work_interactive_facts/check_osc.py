import sympy as sp
x=sp.symbols('x'); f0=sp.Function('f0')(x); f1=sp.Function('f1')(x)
# state: (f0,f1) ; a+ : (f0,f1)->(0,f0)  a-: (f0,f1)->(f1,0) ; b+ = x*, b- = d/dx
def ap(s): return (sp.Integer(0), s[0])
def am(s): return (s[1], sp.Integer(0))
def bp(s): return (x*s[0], x*s[1])
def bm(s): return (sp.diff(s[0],x), sp.diff(s[1],x))
def comp(*ops):
    def r(s):
        for o in reversed(ops): s=o(s)
        return s
    return r
def add(*terms):
    def r(s):
        out=[sp.Integer(0),sp.Integer(0)]
        for c,o in terms:
            t=o(s); out[0]+=c*t[0]; out[1]+=c*t[1]
        return tuple(out)
    return r
I=lambda s:s
S=(f0,f1)
def eq(A,B): 
    a=A(S); b=B(S); return all(sp.simplify(sp.expand(u-v))==0 for u,v in zip(a,b))
H1=add((1,comp(ap,am)),(1,comp(bp,bm)))
H2=add((-1,comp(bp,bm)),(sp.Rational(-1,2),I))
E2p=add((sp.Rational(1,2),comp(bp,bp))); E2m=add((sp.Rational(1,2),comp(bm,bm)))
Epp=comp(ap,bp); Epm=comp(ap,bm); Emp=comp(am,bp); Emm=comp(am,bm)
def comm(A,B): return add((1,comp(A,B)),(-1,comp(B,A)))
def acomm(A,B): return add((1,comp(A,B)),(1,comp(B,A)))
print('CAR {a-,a+}=1:',eq(acomm(am,ap),I),' CCR [b-,b+]=1:',eq(comm(bm,bp),I))
print('{Epp,Emm} = -H1-2H2:',eq(acomm(Epp,Emm),add((-1,H1),(-2,H2))))
print('{Epm,Emp} = H1:',eq(acomm(Epm,Emp),H1))
print('[H1,Epp]=2Epp:',eq(comm(H1,Epp),add((2,Epp))),' [H1,Epm]=0:',eq(comm(H1,Epm),add((0,I))),' [H1,E2p]=2E2p:',eq(comm(H1,E2p),add((2,E2p))))
print('[E2p,Epm]=-Epp:',eq(comm(E2p,Epm),add((-1,Epp))),' [E2m,Epp]=+Epm:',eq(comm(E2m,Epp),add((1,Epm))))
print('[H2,Epp]=-Epp:',eq(comm(H2,Epp),add((-1,Epp))),' [H2,E2p]=-2E2p:',eq(comm(H2,E2p),add((-2,E2p))),' [H2,Epm]=+Epm:',eq(comm(H2,Epm),Epm))
print('{Epm,Emp}=H1-2H2 (r3-C claim):',eq(acomm(Epm,Emp),add((1,H1),(-2,H2))))
print('{Epm,Emp}=H1+H2 (r2-C claim):',eq(acomm(Epm,Emp),add((1,H1),(1,H2))))
print('{Epp,Emm}=H1-H2 (r2-C claim):',eq(acomm(Epp,Emm),add((1,H1),(-1,H2))))
print('{Epp,Emm}=-H1-2H2+K :',eq(acomm(Epp,Emm),add((-1,H1),(-2,H2),(1,I))))
print('b+b- = -H2 - 1/2 :',eq(comp(bp,bm),add((-1,H2),(sp.Rational(-1,2),I))))
