import json,sys,re
def walk(o):
    if isinstance(o,dict):
        for k,v in o.items():
            if k=='Z': yield v
            elif k in('X','Y'): yield ('XY',v)
            else: yield from walk(v)
    elif isinstance(o,list):
        for x in o: yield from walk(x)
root=sys.argv[1]
for r in sys.argv[2:]:
    for n in (1,2):
        S=json.load(open(f'{r}/data/C_{n}_structure.json'))
        B=set(S['basis']['even'])|set(S['basis']['odd'])
        for kind in ('gamma','coboundary'):
            d=json.load(open(f'{r}/data/C_{n}_{kind}.json'))
            zs=set(); xy=set()
            for v in walk(d):
                if isinstance(v,tuple): xy.add(v[1])
                else: zs.add(v)
            print(r,n,kind,'Z outside basis:',sorted(zs-B),'XY outside basis:',sorted(xy-B)[:8], '#basis',len(B))
