import json,sys
def show(o,p='',d=0):
    if isinstance(o,dict):
        for k,v in o.items():
            if isinstance(v,(dict,list)):
                print('  '*d+f'{k}: {type(v).__name__}[{len(v)}]')
                if d<5: show(v,p+'.'+k,d+1)
            else:
                s=repr(v); print('  '*d+f'{k}: {s[:150]}')
    elif isinstance(o,list):
        if o:
            print('  '*d+'[0]= '+json.dumps(o[0])[:600])
            if len(o)>1: print('  '*d+'[1]= '+json.dumps(o[1])[:400])
            if isinstance(o[0],dict) and d<4:
                pass
for f in sys.argv[1:]:
    print('#####',f); show(json.load(open(f)))
