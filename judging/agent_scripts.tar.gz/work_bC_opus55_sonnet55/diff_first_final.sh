#!/bin/sh
# agent computation: which files differ between first and final copies
J=/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot
for r in $(ls $J/final | grep -E 'opus55-b0[13579]-C|sonnet55-b0[13579]-C'); do echo "=== $r"; diff -rq $J/first/$r $J/final/$r; done
