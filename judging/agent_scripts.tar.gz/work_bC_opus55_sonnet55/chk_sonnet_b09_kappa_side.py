"""agent computation: in thm01-R-sonnet55-b09-C, K (kappa) is the LAST generator in normal order, so the stored gamma is the
coefficient with kappa on the RIGHT. Convert to kappa-LEFT (kappa*Q = (-1)^{p(Q)} Q*kappa, p(Q)=p_i+p_j+1) and re-run the rank test."""
import sys, numpy as np
sys.path.insert(0, '/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_bC_opus55_sonnet55/rerun/thm01-R-sonnet55-b09-C')
import verify_triviality as V
for n in (1, 2, 3):
    params = [(s, j, t) for s in '+-' for j in range(1, n + 1) for t in '+-']
    bs, par, C, _, _ = V.structure(n, {})
    d = len(bs)
    cols, ent = V.delta_f_matrix(d, par, C)
    rows = set(ent); Gs = {}
    for p in params:
        _, _, _, G, S = V.structure(n, {p: 1}); Gs[p] = G
        rows |= {(i, j, k) for (i, j), v in G.items() for k in v}
    rows = sorted(rows); ri = {r: t for t, r in enumerate(rows)}
    D = np.zeros((len(rows), len(cols)))
    for r, dc in ent.items():
        for c, v in dc.items(): D[ri[r], c] += float(v)
    for flip in (False, True):
        Gm = np.zeros((len(rows), len(params)))
        for q, p in enumerate(params):
            for (i, j), v in Gs[p].items():
                s = (-1) ** ((par[i] + par[j] + 1) % 2) if flip else 1
                for k, val in v.items(): Gm[ri[(i, j, k)], q] = s * float(val)
        rD = np.linalg.matrix_rank(D); rDG = np.linalg.matrix_rank(np.hstack([D, Gm])); rG = np.linalg.matrix_rank(Gm)
        print(f"n={n} kappa-{'left (flipped)' if flip else 'right (as stored)'}: rank D={rD} rank G={rG} rank[D|G]={rDG}", flush=True)
