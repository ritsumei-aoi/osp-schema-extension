import json
d=json.load(open('/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/thm01-R-opus55-b05-C/verification/artifacts/summary.json'))
for k,v in d.items():
    print(k,v['coboundary_matrix_shape'],v['coboundary_rank'],v['odd_1cocycle_dim(nullity)'],v['strict_scalar_obstruction_rank'],v['negative_controls'],'%.1e'%max(c['lstsq_residual'] for c in v['per_param_checks'].values()), v['strict_reading_only_gb_zero'])
