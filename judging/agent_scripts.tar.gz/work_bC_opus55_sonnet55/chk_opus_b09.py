import json
R='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/thm01-R-opus55-b09-C/verification/artifacts/'
d=json.load(open(R+'cn1_n1_symmetrized.json'))
B=d['basis']; nm=lambda i:B[int(i)]['name']
print(B[:3]); 
for k,v in d['gamma'].items():
    a,b=k.split(',')
    if a==b and nm(a).startswith('S(a'): print(nm(a),nm(b),{nm(m):x for m,x in v.items()})
print(d['checks'])
for n in (1,2,3):
  for t in ('symmetrized','cn1'):
    e=json.load(open(R+f'cn1_n{n}_{t}.json'))['checks']; print(n,t,e['pairs_with_nonzero_discarded_scalars'],e['pairs_with_kappa_scalar'])
