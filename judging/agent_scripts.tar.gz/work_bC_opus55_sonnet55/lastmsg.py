import json,gzip,sys,os
B='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/runs/batch/'
W=os.path.dirname(os.path.abspath(__file__))
for run in sys.argv[1:]:
    for t in (1,2):
        msgs=[]
        for i,l in enumerate(gzip.open(B+run+f'/turn{t}.jsonl.gz','rt')):
            o=json.loads(l)
            if o.get('type')=='assistant':
                txt=''.join(c.get('text','') for c in o['message']['content'] if c.get('type')=='text')
                if txt.strip(): msgs.append((i+1,txt))
        open(f'{W}/last_{run}_t{t}.txt','w').write(f'line {msgs[-1][0]}\n'+msgs[-1][1] if msgs else 'NONE')
        print(run,t,len(msgs),msgs[-1][0] if msgs else None)
