import json
R='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/thm01-R-opus55-b01-C/verification/artifacts/'
for n in (1,2,3):
    d=json.load(open(R+f'cn1_n{n}.json'))
    print(n,{k:(v['num_nonzero_gamma_pairs'],v['num_pairs_with_scalar_part']) for k,v in d['per_gb_parameter'].items()})
    print(d['checks']['linear_algebra'])
d=json.load(open(R+'cn1_n1.json'))['per_gb_parameter']['gb[a1+,b1+]']
print([g for g in d['gamma'] if g['X']=='a+*a-' and g['Y']=='b1+*b1+'])
print(d['trivialising_f'])
