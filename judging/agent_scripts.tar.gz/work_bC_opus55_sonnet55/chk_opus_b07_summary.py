import json
d=json.load(open('/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/thm01-R-opus55-b07-C/verification/artifacts/summary.json'))
for k,v in d.items():
    nc=v['numerical_checks']
    for r in ('mod_scalar','g_hat'):
        x=nc[r]; print(k,r,x['num_unknowns_odd_f'],x['rank_delta_on_odd_1_cochains'],x['dim_odd_1_cocycles(kernel)'],x['rank_of_gamma_family (injectivity of gb -> gamma)'],x['rank_[delta|gamma_family]'],'%.1e'%x['random_gb_lstsq_residual'],x['negative_control_random_odd_cochain_rank_increases'])
