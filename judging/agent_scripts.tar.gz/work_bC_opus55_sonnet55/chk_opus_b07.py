import json
R='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/thm01-R-opus55-b07-C/verification/artifacts/'
d=json.load(open(R+'C2_n1.json')); print(list(d.keys()))
B=d['basis']; print(B[:2])
nm=lambda i:B[int(i)]['word'] if 'word' in B[0] else B[int(i)]
print(nm(0))
nm=lambda i:'*'.join(B[int(i)]['word'])
sc=d['structure_constants']; print(list(sc.items())[:2])
g=d['gamma_per_unit_gb']; print(list(g.keys()))
k=[k for k in g if '+' in k][0]; print(k)
gg=g[k]
for key,v in gg.items():
    i,j=key.split(',')
    if (nm(i),nm(j)) in (('a+*b1+','b1+*b1-'),('b1+*b1+','a+*b1+')): print(nm(i),nm(j),{(nm(m) if m!='const' else 'const'):x for m,x in v.items()})
# [b1+b1+, b1-b1-]
ib=[i for i in range(len(B)) if '*'.join(B[i]['word'])=='b1+*b1+'][0]; jb=[i for i in range(len(B)) if '*'.join(B[i]['word'])=='b1-*b1-'][0]
print({(nm(m) if m!='const' else 'const'):x for m,x in sc[f'{ib},{jb}'].items()})
print(d['trivialising_map_h_per_unit_gb'].keys())
