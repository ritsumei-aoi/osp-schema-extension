"""agent computation (thm01-R-sonnet55-b01-C): with beta from mathematical_proof.md:26,
beta(a^s) = sum_j(-gb[s,j,-] b_j^+ + gb[s,j,+] b_j^-), compute kappa-coefficient of [b_j^s, a^s' + kappa*beta(a^s')]
= -gb[s',j,s] + [b_j^s, beta(a^s')]  using the run's own Model.vbr (K=1 scalar part of the bracket), for n=1, all unit gb.
Also compare the beta coefficients in code explicit_f (cn1_triviality.py:228-229) with the proof's beta."""
import sys
sys.path.insert(0, '/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_bC_opus55_sonnet55/rerun/thm01-R-sonnet55-b01-C/code')
import cn1_triviality as T
from fractions import Fraction as Fr
n = 1
M = T.Model(n)
for key in M.gb_keys:
    gb = {key: 1}
    # proof beta (line 26)
    out = {}
    for sg in '+-':
        beta = {}
        for j in range(1, n + 1):
            beta[M.idx[f'b{j}+']] = -Fr(gb.get((sg, j, '-'), 0))
            beta[M.idx[f'b{j}-']] = Fr(gb.get((sg, j, '+'), 0))
        for j in range(1, n + 1):
            for s in '+-':
                bidx = M.idx[f'b{j}{s}']
                orig = M.vbr(bidx, M.idx[f'a{sg}'], gb)[1]          # -gb kappa coefficient
                add = sum(c * M.vbr(bidx, w, gb)[0] for w, c in beta.items())  # [b, beta] scalar (K) part
                out[(sg, j, s)] = (orig, add, orig + add)
    print(key, {k: v for k, v in out.items() if v[0] != 0 or v[1] != 0})
# code beta vs proof beta
f_code = T.explicit_f(M, {('+', 1, '+'): 1})
print('code explicit_f(+,1,+):', {M.basis[k]: v for k, v in f_code.items()})
