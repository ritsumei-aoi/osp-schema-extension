import json
R='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/thm01-R-opus55-b03-C/verification/artifacts/'
d=json.load(open(R+'cn1_n1.json'))
B={b['index']:b['monomial'] if 'monomial' in b else b for b in d['basis']}
print(list(d.keys())); print(d['basis'][:3])
c=d['configs']['unit_gb[+,1,+]']
nm=lambda i:d['basis'][int(i)]['monomial']
print({nm(k):{nm(i):v for i,v in x.items()} for k,x in c['explicit_f'].items()}, c['explicit_f_scalar_parts'])
for k,v in c['gamma'].items():
    i,j=k.split(',')
    if nm(i)=='a+*a-' and nm(j)=='b1+*b1+': print(k,{nm(m):x for m,x in v.items()})
for n in (1,2,3):
    d=json.load(open(R+f'cn1_n{n}.json')); print(n,d['delta_on_odd_maps'],d['rank_of_gb_to_gamma_map'])
