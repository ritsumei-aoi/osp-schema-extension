"""agent computation: thm01-R-sonnet55-b07-C computes gamma as a plain coefficient (no sign when kappa passes odd elements).
Multiply gamma(Z_p,Z_q) by (-1)^{p_p+p_q+1} (= kappa moved from right to left) and re-run its rank test (numpy ranks)."""
import sys, numpy as np
sys.path.insert(0, '/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_bC_opus55_sonnet55/rerun/thm01-R-sonnet55-b07-C/artifacts')
import verify_triviality as V
for n in (1, 2, 3):
    M = V.build(n); br0, gam = V.structure(M)
    d, m, bp = len(M['basis']), M['m'], M['bpar']
    L = br0
    sx = np.array([(-1) ** bp[p] for p in range(d)])[:, None, None]
    sy = np.array([[(-1) ** ((bp[p] + 1) * bp[q]) for q in range(d)] for p in range(d)])[:, :, None]
    unk = [(i, j) for j in range(d) for i in range(d) if bp[i] != bp[j]]
    cols = []
    for (i, j) in unk:
        f = np.zeros((d, d)); f[i, j] = 1
        A1 = np.einsum('sq,pst->pqt', f, L); A2 = np.einsum('sp,qst->pqt', f, L); A3 = np.einsum('pqs,ts->pqt', L, f)
        cols.append((sx * A1 - sy * A2 - A3).reshape(-1))
    D = np.array(cols).T
    for flip in (False, True):
        g = gam.copy()
        if flip:
            sgn = np.array([[(-1) ** ((bp[p] + bp[q] + 1) % 2) for q in range(d)] for p in range(d)])
            g = g * sgn[:, :, None, None]
        G = np.array([g[..., k].reshape(-1) for k in range(m)]).T
        print(f"n={n} {'flipped' if flip else 'as stored'}: rank D={np.linalg.matrix_rank(D)} rank G={np.linalg.matrix_rank(G)} rank[D|G]={np.linalg.matrix_rank(np.hstack([D,G]))}", flush=True)
