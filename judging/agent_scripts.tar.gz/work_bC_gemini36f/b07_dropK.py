# agent computation: run b07 solver.py with the 'scalar' target removed from the equation set (K dropped), no other change.
import sys, re
src = open(sys.argv[1] + '/solver.py').read()
old = "all_targets = list(range(dim_total)) + ['scalar']"
assert old in src
src = src.replace(old, "all_targets = list(range(dim_total))")
src = src.split("if __name__ == '__main__':")[0]
ns = {}
exec(compile(src, 'solver_dropK', 'exec'), ns)
for n in (1, 2, 3):
    r = ns['analyze_triviality_for_n'](n, allow_scalar_in_f=False)
    print("DROPK_RESULT", n, "rank_A", r['rank_A'], "num_f_vars", r['num_f_vars'], "gb_conditions", len(r['gb_conditions']), r['triviality_summary'])
