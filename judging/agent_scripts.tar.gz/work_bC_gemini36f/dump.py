import json,gzip,sys
f=sys.argv[1]; lim=int(sys.argv[2]) if len(sys.argv)>2 else 300
for i,l in enumerate(gzip.open(f,'rt')):
    e=json.loads(l)
    ev=e.get('event')
    if ev=='step_update':
        s=e['step_update']
        if s.get('state')=='ACTIVE' and s.get('step_type')=='tool':
            print(i,'TOOL',s['tool_name'],json.dumps(s['tool_info'].get('parameters'),ensure_ascii=False)[:lim])
        elif s.get('step_type') in('agent_response','user_input') and s.get('state')=='DONE':
            print(i,s['step_type'],json.dumps({k:v for k,v in s.items() if k not in('conversation_id','usage')},ensure_ascii=False)[:lim])
    else:
        print(i,ev,json.dumps(e,ensure_ascii=False)[:lim])
