# agent computation: evaluate gamma(F_0, B_pm_j_j) with run b16's own build_cn1_algebra (n=1,2) and print nonzero entries.
import sys
sys.path.insert(0, sys.argv[1])
from scratch.verify_cn1_deformation import build_cn1_algebra
for n in (1, 2):
    basis, C, G, gp = build_cn1_algebra(n)
    names = [b['name'] for b in basis]
    a = names.index('F_0')
    for j in range(1, n+1):
        b = names.index(f'B_pm_{j}_{j}')
        out = {}
        for c in range(len(basis)):
            for p, pn in enumerate(gp):
                v = G[a, b, c, p]
                if v != 0: out[(names[c], pn)] = v
        print("n=%d j=%d gamma(F_0, B_pm_%d_%d) =" % (n, j, j, j), out)
