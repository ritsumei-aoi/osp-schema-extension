import json, build1, build2, build3
from qlib import Q
R={}; [R.update(m.R) for m in (build1,build2,build3)]
# cleanups
for r in R:
    R[r]['issues']=[i for i in R[r]['issues'] if 'no contradiction found' not in i['contradicts'] and 'None found' not in i['contradicts']]
for i in R['b15']['issues']:
    if isinstance(i['quote'],str) and i['quote'].startswith('bracket_odd_odd'):
        i['quote']=Q('b15','scratch/full_solver.py','def bracket_odd_odd(idx_odd1, idx_odd2):')
for r in R:
    for i in R[r]['issues']:
        if isinstance(i['quote'],dict):
            i['loc']=i['quote']['loc']; i['quote']=i['quote']['quote']
INV={'b01':('785ac02','0f5d736'),'b03':('59012fe','beecf2e'),'b05':('a759de0','f540864'),'b07':('7762a7f','8e3d088'),'b09':('bc2b975','58059b1'),'b12':(None,'2c13e6d'),'b13':('95d7cfa','920d772'),'b14':('77b3842','ba44071'),'b15':(None,'2d5406c'),'b16':(None,'b5ca074')}
CAV="Agent scripts reusing a Worker's own code (odd_odd_bracket_check.py, b07_dropK.py, b01_gamma_even_even.py, b16_gamma_check.py, hstack_check.py in work_bC_gemini36f/) are 'agent computation, not validated against the reference'. Reference ranks cited from experiment/scripts/independent_triviality4.py (run at n=1 by agent): rank A=28; [A|G]=32 except kappa=super,K=drop (28, all gb trivial); all runs here code kappa with no sign."
out=[]
def obj(r,commit,first):
    k=R[r]; stated,cls=k['stated']
    o={"run":f"thm01-R-gemini36f-{r}-C","commit_checked":commit,
     "stated_conclusion":stated,"stated_conclusion_class":cls,"scope":k['scope'],
     "declared_reading":k['reading'],"test_range":k['test_range'],"test_range_evidence":k['test_evidence'],
     "computation":k['comp'],"reported_numbers":k['numbers'],
     "rerun":dict(k['rerun'],python3="Python 3.14.8",sympy="1.14.0",numpy="2.4.4",
        scratch="work_bC_gemini36f/rr/%s (copy of final)"%r, applies_to_first=("not run separately; first commit has identical code/data (diff -r), so same result" if first else "n/a")),
     "argument_issues":k['issues'],
     "consistency_with_data":"no g_summary row (C run). "+k['cons'],
     "notes":list(k['notes'])+[CAV],
     "quote_convention":"quotes verbatim substrings (checked by script); loc = file:line relative to $JROOT/final/<run>/; reflection/metric quotes likewise."}
    return o
for r,(f,fin) in INV.items():
    if f:
        o=obj(r,f"first ({f})",True)
        o['notes'].insert(0,"First submission; deliverables (proof, code, data) identical to final commit (diff -r); only reflection/metrics files differ or are added in final.")
        out.append(o)
        o=obj(r,f"final ({fin})",False)
        out.append(o)
    else:
        out.append(obj(r,f"final ({fin}); single commit (first == final)",False))
out_p='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/judging/facts/bC_gemini36f.jsonl'
with open(out_p,'w') as fh:
    for o in out: fh.write(json.dumps(o,ensure_ascii=False)+'\n')
print(len(out),'objects')
for o in out: print(o['run'][-5:],o['commit_checked'][:14],len(o['argument_issues']))
