import sympy as sp
A=sp.Matrix([[1,0],[0,1],[0,0]]); B=sp.Matrix([[0],[0],[1]])
print("A.hstack(B).shape =", A.hstack(B).shape, "(sp.Matrix.hstack(A,B).shape =", sp.Matrix.hstack(A,B).shape, ")")
print("A.hstack(B) == B :", A.hstack(B)==B)
