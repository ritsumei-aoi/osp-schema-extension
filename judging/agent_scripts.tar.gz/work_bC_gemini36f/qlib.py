import json, re
ROOT='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/thm01-R-gemini36f-%s-C/'
P='docs/issues/mathematical_proof.md'
def Q(r, path, text):
    lines=open(ROOT%r+path).read().split('\n')
    for i,l in enumerate(lines,1):
        if text in l:
            assert len(text)<=300, text
            return {"quote":text,"loc":f"{path}:{i}"}
    raise AssertionError((r,path,text))
