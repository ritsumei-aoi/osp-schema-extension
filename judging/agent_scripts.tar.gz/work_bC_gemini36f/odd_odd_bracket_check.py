# agent computation: use run b01's normal-ordering engine (scratch/normal_order.py, vec_helper.py, run_full_solver.elem_to_monomial)
# with all gb = 0 to evaluate the undeformed super-bracket [a+ b_k^s, a- b_l^t]_0 and report its Z = a+a- component.
import sys, sympy as sp
sys.path.insert(0, sys.argv[1] + '/scratch')
from collections import defaultdict
from normal_order import Monomial, multiply_monomials
from vec_helper import get_basis_and_algebra, monomial_to_vec
from run_full_solver import elem_to_monomial
n = 1
even, odd = get_basis_and_algebra(n)
gb = {(s, k, r): sp.Integer(0) for s in '+-' for k in range(1, n+1) for r in '+-'}
Fp = [o for o in odd if o[1] == '+']; Fm = [o for o in odd if o[1] == '-']
for X in Fp:
    for Y in Fm:
        mX, mY = elem_to_monomial(X), elem_to_monomial(Y)
        XY = multiply_monomials(mX, mY, n, gb); YX = multiply_monomials(mY, mX, n, gb)
        tot = defaultdict(lambda: sp.Integer(0))
        for k, c in XY.items(): tot[k] += c
        for k, c in YX.items(): tot[k] += c      # odd-odd: anticommutator
        v0, v1 = monomial_to_vec(tot, even, odd, n)
        nz = {k: c for k, c in v0.items() if c != 0}
        print("[", X, ",", Y, "]_0 =", nz, " | Z-component:", v0[('Z',)])
