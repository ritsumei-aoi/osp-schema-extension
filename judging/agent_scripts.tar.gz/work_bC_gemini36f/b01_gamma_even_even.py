# agent computation: read run b01's committed verification_artifacts.json (written by its normal-ordering engine)
# and list gamma entries for pairs (Z, B_*) with both even.
import json, sys
d = json.load(open(sys.argv[1]))
for key, v in d.items():
    rows = [r for r in v['gamma_gb_sample_evaluations'] if r['X'] == 'Z' and r['Y'].startswith('B_')]
    print(key, "number of (Z,B) entries with nonzero gamma:", len(rows))
    for r in rows[:2]:
        print("   ", r)
