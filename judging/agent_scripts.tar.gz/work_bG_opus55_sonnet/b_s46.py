from build_common import *
import pickle
out=[]
NOTURN2="No turn2.jsonl.gz exists in runs/batch/<run>/ (only turn1.jsonl.gz and run.json); the final reflection was written and committed in turn 1 (docs/issues/final_reflection.md)."
NOK="The run's C_{n}_gamma.json contains no K-labelled entry for n=1,2,3 (agent computation: check_K_absent.py)."
def doc(file,text): return text
H2="C_inhomogeneous_definition.md:31 (task document, in docs/math/ of every copy): 'where $\\gamma: \\mathfrak{g} \\otimes \\mathfrak{g} \\to \\mathfrak{g}$ is a 2-cocycle.'"
AUX="runs/batch/{r}/ also contains check.json and review.md (author-side scribe files); not used here."

# ---------- b01
r='thm01-R-sonnet46-b01-G'
d=base(r)
a1=q(r,'docs/issues/I08.md','Note: The null space dimension of the phi unknowns (free parameters in f) is 0')
d.update({
"stated_conclusion":q(r,'docs/issues/I08.md','if and only if all gb parameters vanish'),
"stated_conclusion_class":"trivial iff gb=0",
"scope":{"n123":q(r,'docs/issues/I08.md','- The pattern holds for n=1,2,3 with no exceptions.'),
 "general_n":q(r,'docs/issues/I08.md','**Conjecture**: For $C(n+1) = \\mathrm{osp}(2|2n)$ with $n \\geq 1$')},
"declared_reading":{
 "a_parity_gb":q(r,'docs/issues/I05.md','**gb matrix design** (4n parameters, parity 1):'),
 "b_sign_handling":q(r,'docs/issues/I05.md','times the remaining monomial to the kappa-coefficient accumulator'),
 "c_K":q(r,'docs/issues/I02.md','Contains `K` (parity 0, identity) and `kappa` (parity 1, nilpotent).'),
 "note":"Commutation of kappa with odd a_1 and the treatment of K in triviality are not stated in I05/I07/I08. "+NOK},
"test_range":{"class":"joint + profiles: all gb=+1",
 "summary":"Numeric solve at all gb=1 (inconsistent) plus symbolic elimination of [M_phi | Gamma_gb] (investigate_general_gb in src/C_triviality.py): zero-M rows give linear conditions on gb (reported 4n distinct, each gb=0).",
 "evidence":q(r,'docs/issues/I08.md','After Gaussian elimination with symbolic gb:')},
"computation":{"code":["src/C_triviality.py (build_linear_system, solve_system_fraction, investigate_general_gb)","src/analyze_conditions.py (normalizes the conditions)","src/C_coboundary.py","src/C_gamma.py","src/C_evaluated.py","src/C_generators.py","src/verify_C_structure.py"],
 "rank_computation":"src/C_triviality.py solve_system_fraction / investigate_general_gb (Fraction Gaussian elimination)",
 "hardcoded_or_placeholder":"none found"},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','| C(2)=osp(2|2), n=1 | 4 | 4 | 32 | 213 | 28 | 0 | **NO** |'),
 "vs_reference_and_g_summary":"rank(A) 28/168/516 equals reference. Rank of [A|G] is not reported as a number (only 'inconsistent'; 74/432/1196 inconsistent equations, 4n independent). "+gs(r)},
"rerun":"not done",
"argument_issues":[
 {"quote":a1['quote'],"loc":a1['loc'],"contradicts":"Same file: "+q(r,'docs/issues/I08.md','Wait, re-reading: the *Null space dimension*')['loc']+" 'Wait, re-reading: the *Null space dimension* (free phi dims) in the general analysis is 4, 8, 12'; and its own table (phi params 32, M rank 28 => 32-28 = 4). Code: src/C_triviality.py solve_system_fraction returns `False, {}, [], rank, inconsistent_rows` for an inconsistent system, so the printed null-space size 0 is an empty placeholder list, not a computed kernel."},
 {"quote":q(r,'docs/issues/I08.md','Equivalently: the cohomology class $[\\gamma_{gb}] \\in H^1(\\mathfrak{g}, \\mathfrak{g})$ is zero')['quote'],"loc":q(r,'docs/issues/I08.md','Equivalently: the cohomology class $[\\gamma_{gb}] \\in H^1(\\mathfrak{g}, \\mathfrak{g})$ is zero')['loc'],
  "contradicts":H2+" (gamma is a 2-cochain; f is the 1-cochain)."}],
"consistency_with_data":"Stated class 'trivial iff gb=0' matches data_implies n1/n2 'trivial iff gb=0 / trivial iff gb=0'. The run's gamma data contain no K (gamma_n1 '=none' vs generator, K absent), so test (b): conclusion is not K-dependent in the run's own data (dropping K changes nothing).",
"notes":[NOTURN2,AUX.format(r=r),"final_reflection.md says the session spanned two context windows (compaction between I07 and I08); the log has one compact boundary."],
"quote_convention":QC})
out.append(d)

# ---------- b02
r='thm01-R-sonnet46-b02-G'
d=base(r)
a=q(r,'docs/issues/I08.md','This is a structural feature of C(n+1) having a larger center than B(0,n)')
d.update({
"stated_conclusion":q(r,'docs/issues/I08.md','is trivial if and only if all gb parameters vanish.'),
"stated_conclusion_class":"trivial iff gb=0",
"scope":{"n123":q(r,'docs/issues/I08.md','confirms rank([A|γ^{(gb)}]) > rank(A) for every gb parameter and every n ∈ {1, 2}.'),
 "general_n":q(r,'docs/issues/I08.md','persists for all n ≥ 1 (since H_2 is always the "extra" Cartan element')},
"declared_reading":{
 "a_parity_gb":q(r,'docs/issues/I05.md','Graded: all gb parameters are even scalars'),
 "b_sign_handling":q(r,'docs/issues/I05.md','Deformed commutation rule: b_j^s · a_1^σ = a_1^σ · b_j^s − gb_{σ,j,s} · κ'),
 "c_K":q(r,'docs/issues/I02.md','K is excluded from basis.'),
 "note":"Commutation of kappa with odd a_1 and the treatment of K in triviality are not stated. "+NOK},
"test_range":{"class":"per-direction (n=1,2 only)",
 "summary":"For each gb parameter separately, rank(A) vs rank([A|gamma^(gb)]) is compared; no joint symbolic elimination; n=3 not computed; the obstruction is shown by one entry (H_1, E_eps1_del1_pm, H_2).",
 "evidence":q(r,'docs/issues/I08.md','Does the vector γ^{(gb)} (coefficients of gb_label in γ) lie in Im(A)?')},
"computation":{"code":["no saved triviality code in src/ or tests/ (src: C_coboundary.py, C_evaluate.py, C_gamma.py, C_generators.py, verify_C_structure.py). The I08 comparison ran as inline `python3 << 'PYEOF'` commands in the session (turn1.jsonl.gz messages 1532, 1600, 1603), output copied into I08."],
 "rank_computation":"inline Fraction Gaussian elimination, not in the repository",
 "hardcoded_or_placeholder":"none found in src/"},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','rank(δ) = 28, phi_params = 32, triples = 111'),
 "vs_reference_and_g_summary":"rank(A) 28 (n=1), 168 (n=2) equal reference; n=3 not reported; rank [A|G] per direction not reported as numbers. "+gs(r)},
"rerun":"not done (no triviality code in the copy)",
"argument_issues":[{"quote":a['quote'],"loc":a['loc'],"contradicts":"docs/math/B0n_definition.md:93 '## 3. Central Extension and the Element κ' and :103 '**Parity**: $p(\\kappa) = 1$' (task document): B(0,n) is also defined with a central kappa."}],
"consistency_with_data":"Stated class 'trivial iff gb=0' matches data_implies 'trivial iff gb=0 / trivial iff gb=0' (g_summary: 0/4 and 0/8 directions trivial). The run's gamma has no K (46 entries vs 50 in the reference, 4 missing), so test (b): not K-dependent in the run's own data.",
"notes":[NOTURN2,AUX.format(r=r),"The 'iff gb=0' conclusion rests on per-direction tests; the run does not test combinations of directions jointly.","The witness (H_1,E_eps1_del1_pm,H_2): gamma coefficient 2*gb_p_1_m and absence of a Z=H_2 key among delta-f entries for that pair were confirmed in data/C_1_gamma.json and data/C_1_coboundary.json (read directly)."],
"quote_convention":QC})
out.append(d)

# ---------- b04
r='thm01-R-sonnet46-b04-G'
d=base(r)
a=q(r,'docs/issues/I08.md','**C(2) (n=1)**: 13 independent constraints, all of the form c * gb_{single_param} = 0:')
b=q(r,'docs/issues/I08.md','**Mathematical interpretation**: The deformation cohomology H^1_odd(C(n+1), C(n+1)) ≅ **0**')
c=q(r,'docs/issues/final_reflection.md','Total Wall Time**: Single session, approximately 45-60 minutes of compute time')
d.update({
"stated_conclusion":q(r,'docs/issues/I08.md','is trivial if and only if all gb parameters are zero:'),
"stated_conclusion_class":"trivial iff gb=0",
"scope":{"n123":q(r,'docs/issues/I08.md','- Verified computationally for n=1,2,3 via Gaussian elimination on the full coboundary system.'),
 "general_n":q(r,'docs/issues/I08.md','**Conjecture**: For C(n+1) = osp(2|2n) with any n ≥ 1')},
"declared_reading":{
 "a_parity_gb":"not stated (no discussion of gb parity in I05/I07/I08; I02 lists only kappa parity 1, K parity 0)",
 "b_sign_handling":q(r,'docs/issues/I05.md','Relation: [b_j^s, a_1^sigma] = -gb_{sigma,j,s} * kappa.'),
 "c_K":q(r,'docs/issues/I02.md','K identified with scalar 1, not in PBW basis.'),
 "note":"Commutation of kappa with odd a_1 not stated. "+NOK},
"test_range":{"class":"joint + profiles: all gb=+1",
 "summary":"C_triviality_full.py row-reduces [A | M_gamma] with gb symbolic (columns) and collects the rows with zero A-part as conditions on gb; also numeric all gb=+1 solve (inconsistent).",
 "evidence":q(r,'docs/issues/I08.md','After row reduction of the augmented system [A | M_gamma] (where gamma = M_gamma * gb):')},
"computation":{"code":["src/C_triviality.py (load_gamma_evaluated, load_coboundary, linear solve at gb=1)","src/C_triviality_full.py (full_triviality_analysis: symbolic-gb row reduction)","src/C_triviality_detail.py","src/C_coboundary.py","src/C_gamma.py","src/C_evaluate.py","src/C_generators.py","src/verify_C_structure.py"],
 "rank_computation":"src/C_triviality_full.py full_triviality_analysis (rank = pivot_row)",
 "hardcoded_or_placeholder":"none found"},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','| 1 | 102 | 32 | 28 | 16 | No |'),
 "vs_reference_and_g_summary":"rank(A) 28/168/516 equals reference; gamma entries (gb=1) 16/128/432 reported. "+gs(r)+" The run's gamma covers 16 of 50 reference entries at n=1 (34 missing) per g_summary."},
"rerun":"not done",
"argument_issues":[
 {"quote":a['quote'],"loc":a['loc'],"contradicts":"Same section lists only 4 conditions (gb_a1p_b1p = 0 ... gb_a1m_b1m = 0) for n=1; 13 linear forms in 4 unknowns cannot be linearly independent. Code src/C_triviality_full.py (unique_constraints block) only de-duplicates identical rows up to sign and prints that count as 'Independent triviality constraints on gb' (no rank is computed). Same for n=2 (25 vs 8 parameters) and n=3 (34 vs 12)."},
 {"quote":b['quote'],"loc":b['loc'],"contradicts":"final_reflection.md: "+q(r,'docs/issues/final_reflection.md','a clean dimensional count: H^1_odd = 4n')['loc']+" 'a clean dimensional count: H^1_odd = 4n' (same run, other value); and "+H2},
 {"quote":c['quote'],"loc":c['loc'],"contradicts":"run.json turns[0].seconds = 2433 (about 41 minutes), timed_out false."}],
"consistency_with_data":"Stated class 'trivial iff gb=0' matches data_implies n1/n2 'trivial iff gb=0 / trivial iff gb=0'. gamma has no K in the run's data (and only 16/50 reference entries), so test (b): not K-dependent in the run's own data.",
"notes":[NOTURN2,"The log contains one harness message 'Output token limit hit. Resume directly' (final reflection counts 1 human intervention).","Three triviality scripts committed with I08."],
"quote_convention":QC})
out.append(d)

# ---------- b07
r='thm01-R-sonnet46-b07-G'
d=base(r)
a=q(r,'docs/issues/final_reflection.md','This is not an artifact of the specific coboundary parametrization')
b=q(r,'docs/issues/final_reflection.md','the gamma computation returns {} for (H, eps_del) brackets')
c=q(r,'docs/issues/I08.md','is trivial (i.e., γ = δf for some odd linear map f: g → g) if and only if all gb parameters are zero')
e=q(r,'docs/issues/final_reflection.md','Total Human Interventions (Nudges/Approvals)**: 2 (one token-limit resume message')
d.update({
"stated_conclusion":c,
"stated_conclusion_class":"trivial iff gb=0",
"scope":{"n123":q(r,'docs/issues/I08.md','**Conjecture** (based on evidence for n=1,2,3):'),
 "general_n":q(r,'docs/issues/I08.md','**Conjecture** (based on evidence for n=1,2,3):')},
"declared_reading":{
 "a_parity_gb":"not stated (only the label; I02 lists kappa parity 1, K parity 0)",
 "b_sign_handling":q(r,'docs/issues/I08.md','the deformed [b_l^t, a_1^σ]_γ = gb·κ produces a κ·(even gen) term'),
 "c_K":q(r,'docs/issues/I02.md','K` (parity 0, identified with scalar 1).'),
 "note":NOK},
"test_range":{"class":"profiles: all gb=+1 (one fixed f, no solving for f)",
 "summary":"f is fixed by hand: f(H_1)=sum gb*E_eps1_delj, all others 0 (src/C_coboundary.py:141 docstring; I07). Layer 4 therefore has no phi unknowns; I08 compares gamma(gb=1) with delta f at gb=1 and lists residual 'constraints' gamma-delta f = 0 per (X,Y,Z). No general odd f is searched.",
 "evidence":q(r,'docs/issues/I08.md','The coboundary is computed for f restricted to f(H_1) only.')},
"computation":{"code":["src/C_triviality.py (compare_structures, analyze_triviality_condition, run_full_analysis: residual gamma - delta f for the fixed f; no solve for f)","src/C_coboundary.py (fixed f at line ~141)","src/C_gamma.py","src/C_evaluate.py","src/C_generators.py","src/verify_C_structure.py"],
 "rank_computation":"no rank/solve computation of delta f over unknown f in the code",
 "hardcoded_or_placeholder":"f is hand-chosen (src/C_coboundary.py:141 `f(H_1) = sum_{j,s} (gb_{a1p,bjs} * E_eps1_delj_{ps} + gb_{a1m,bjs} * E_eps1_delj_{ms})`); grep hit 'dummy' in src/verify_C_structure.py:86 is a variable-name argument (benign)."},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','| 1 | 44 | 52 | 4 | 36 | 44 | 4 |'),
 "vs_reference_and_g_summary":"No ranks reported (gamma/delta-f entry counts only). Reference ranks not comparable. "+gs(r)},
"rerun":"not done",
"argument_issues":[
 {"quote":a['quote'],"loc":a['loc'],"contradicts":"I08.md "+q(r,'docs/issues/I08.md','The coboundary is computed for f restricted to f(H_1) only.')['loc']+": 'The coboundary is computed for f restricted to f(H_1) only.' and I08 "+q(r,'docs/issues/I08.md','Our specific f (H_1 only) is insufficient.')['loc']+": 'Our specific f (H_1 only) is insufficient.'"},
 {"quote":c['quote'],"loc":c['loc'],"contradicts":"I08 "+q(r,'docs/issues/I08.md','Implemented `src/C_triviality.py` to compare Layer 3')['loc']+": f is the single map 'f(H_1) = sum gb E_eps1_delj', f(others)=0 (I08 line "+q(r,'docs/issues/I08.md','However, the constraint pattern already shows that for any f restricted')['loc']+" 'for any f restricted to acting on H_1 only'); the conjecture is stated for 'some odd linear map f: g -> g'."},
 {"quote":b['quote'],"loc":b['loc'],"contradicts":"g_summary.csv: the run's gamma n=1 matches only 16/50 reference entries (miss 26, diff 8); and I05 consistency claims. The run used these gamma entries in the I08 constraint table (n=1: 88 constraints)."},
 {"quote":e['quote'],"loc":e['loc'],"contradicts":"turn1.jsonl.gz contains 4 harness messages 'Output token limit hit' and 1 'continued from a previous conversation' message (agent computation: count of strings in the decompressed log)."}],
"consistency_with_data":"Stated class 'trivial iff gb=0' matches data_implies n1/n2 'trivial iff gb=0 / trivial iff gb=0' for the reference computation on the run's own gamma; the run's own test did not solve for f (fixed f), so its conclusion is not derived from rank([A|G]) of the full coboundary. Test (b): gamma has no K; not K-dependent.",
"notes":[NOTURN2,"Session spanned context compaction (1 compact boundary) and 3 'Output token limit hit' resumes in the log (4 occurrences of the string).","g_summary own-A ranks are blank because the run's Layer 4 is a single fixed f."],
"quote_convention":QC})
out.append(d)

# ---------- b11
r='thm01-R-sonnet46-b11-G'
d=base(r)
a=q(r,'docs/issues/I08.md','`src/_triviality_conditions_v3.py`: Full row-reduction of [Cob | Gam] for n=1.')
b=q(r,'docs/issues/I08.md','while in B(0,n) only specific combinations are constrained')
c=q(r,'docs/issues/final_reflection.md','H¹(C(n+1); C(n+1)) has dimension 4n')
e=q(r,'docs/issues/I08.md','produces a κ contribution through the scalar part of H_2')
d.update({
"stated_conclusion":q(r,'docs/issues/I08.md','if and only if all $4n$ deformation parameters are zero**'),
"stated_conclusion_class":"trivial iff gb=0",
"scope":{"n123":q(r,'docs/issues/I08.md','**Conjecture** (supported by computational evidence for n=1,2,3):'),
 "general_n":q(r,'docs/issues/I08.md','**Conjecture** (supported by computational evidence for n=1,2,3):')},
"declared_reading":{
 "a_parity_gb":"not stated (no discussion in I05/I07/I08)",
 "b_sign_handling":q(r,'docs/issues/I05.md','Since `kappa^2 = 0`, at most one kappa insertion per product is non-zero.'),
 "c_K":q(r,'docs/issues/I02.md','K` (parity 0, scalar identity).'),
 "note":NOK+" I08 attributes the obstruction to 'the scalar part of H_2' (I08 line "+e['loc']+")."},
"test_range":{"class":"per-direction + profiles: all gb=+1 (n=1 joint row reduction only in uncommitted script)",
 "summary":"Committed code solves the system at fixed gb (all gb=1) and tests each single gb=1 direction (_individual_gb_test.py, uncommitted); a joint row reduction of [Cob|Gam] for n=1 is in _triviality_conditions_v3.py (uncommitted). n=2,3: per-direction, 'By linearity' inference stated in I08.",
 "evidence":q(r,'docs/issues/I08.md','**Individual gb tests** (setting one gb=1, rest=0): ALL yield non-trivial deformations for n=1,2,3.')},
"computation":{"code":["src/C_triviality.py (fixed gb, linear solve)","src/C_triviality_analysis.py","src/C_coboundary.py","src/C_gamma.py","src/C_evaluate.py","src/C_generators.py","src/verify_C_structure.py","UNCOMMITTED (not in the copy; listed in run.json): src/_triviality_conditions_v3.py, src/_individual_gb_test.py, src/_triviality_search.py, src/_triviality_witnesses.py, src/_triviality_conditions_full.py, src/_triviality_conditions_v2.py, src/_check_*.py, src/_debug*.py"],
 "rank_computation":"src/C_triviality.py (Fraction elimination at fixed gb); joint/individual conditions in uncommitted scripts",
 "hardcoded_or_placeholder":"none found in committed src/"},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','| 1 | C(2) = osp(2\\|2) | 213 | 28 | 39 | **No** |'),
 "vs_reference_and_g_summary":"rank(Cob) 28/168/516 equals reference; rank [A|G] not reported. "+gs(r)},
"rerun":"not done",
"argument_issues":[
 {"quote":a['quote'],"loc":a['loc'],"contradicts":"run.json uncommitted: '?? src/_triviality_conditions_v3.py' and '?? src/_individual_gb_test.py' (inventory.csv uncommitted); neither file is in the committed copy $JROOT/final/"+r+"/src/. The I08 evidence for 4 independent conditions (n=1) and per-direction tests rests on them."},
 {"quote":b['quote'],"loc":b['loc'],"contradicts":"No file in the copy contains a B(0,n) triviality result (docs/math/B0n_definition.md:8 cites 'docs/drafts/aoi2026_triviality_osp1_2n.tex', absent from the copy; grep 'triv' over docs/math and handover finds no B(0,n) result)."},
 {"quote":c['quote'],"loc":c['loc'],"contradicts":H2},
 {"quote":e['quote'],"loc":e['loc'],"contradicts":"The cited witness is the Z=H_2 component (a basis element) of gamma(E_eps_del1_pm, H_1); the run's C_n_gamma.json has no K-labelled entry (agent computation: check_K_absent.py), so there is no scalar component in the run's data."}],
"consistency_with_data":"Stated class 'trivial iff gb=0' matches data_implies n1/n2 'trivial iff gb=0 / trivial iff gb=0'. gamma has no K (39/50 reference entries at n=1), so test (b): not K-dependent in the run's own data.",
"notes":[NOTURN2,"12 uncommitted files in the workspace (run.json uncommitted, all src/_*.py); none in $JROOT/final.","final_reflection.md says a background computation _triviality_conditions_v2.py 'timed out'; the log shows it invoked via Bash with a 300000 ms timeout and no run_in_background field (message 572)."],
"quote_convention":QC})
out.append(d)
pickle.dump(out,open('s46.pkl','wb')); print(len(out)); print(ERR)
