#!/bin/bash
J=/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final
r=$1; cd $J/$r
echo "== files"; ls docs/issues src data tests 2>/dev/null | tr '\n' ' '; echo
echo "== denials"; python3 /private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/work_bG_opus55_sonnet/pd.py $r | cut -c1-120
echo "== suspicious"; grep -n -i "placeholder\|dummy\|todo\|hard-code\|hardcode\|trivial *= *\(True\|False\)" src/*.py 2>/dev/null | head
echo "== I08"; awk '/^### Response|^## Response/{f=1} f' docs/issues/I08.md | cat -n | cut -c1-700
