import gzip,json,sys
R='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/runs/batch/'
for r in sys.argv[1:]:
    m=[json.loads(l) for l in gzip.open(R+r+'/turn1.jsonl.gz')]
    out=[]
    for i,x in enumerate(m):
        if x.get('type')=='user':
            c=x['message']['content']
            if isinstance(c,str): out.append((i,c[:150]))
            else:
                t=[b.get('text','') for b in c if b.get('type')=='text']
                if t: out.append((i,' '.join(t)[:150]))
    print(r,len(out),out[1:4])
