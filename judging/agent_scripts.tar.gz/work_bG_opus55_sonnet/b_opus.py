from build_common import *
out=[]
NOTURN2="No turn2.jsonl.gz exists in runs/batch/<run>/ (only turn1.jsonl.gz and run.json); the final reflection was written and committed in turn 1 (docs/issues/final_reflection.md)."
DEN="Count of permission_denials in the last record of runs/batch/{r}/turn1.jsonl.gz = {n} (agent computation: pd.py)."
CLS_COND="conditional/other (reading-dependent; headline = all gb trivial, with 'trivial iff gb=0' reported for the strict reading)"

# ---------- opus55-b02
r='thm01-R-opus55-b02-G'
d=base(r)
d.update({
"stated_conclusion":q(r,'docs/issues/I08.md','The necessary and sufficient condition on gb is therefore **empty** (all gb).'),
"stated_conclusion_class":CLS_COND,
"stated_conclusion_note":[q(r,'docs/issues/I08.md','Only under the strict reading'),q(r,'docs/issues/final_reflection.md','Under the strict reading, with $f:g\\to g$ and the κ·1 term required to match, only')],
"scope":{"n123":q(r,'docs/issues/I08.md','Evidence: exact computation for n=1,2,3 on all 8 profiles and symbolically on all of $\\mathbb C^{4n}$'),
 "general_n":q(r,'docs/issues/I08.md','independent of $n$ and constitutes a proof sketch for general $n$')},
"declared_reading":{
 "a_parity_gb":q(r,'docs/issues/I05.md','Adopted: gb are ordinary commuting scalars;'),
 "b_sign_handling":q(r,'docs/issues/I05.md','$\\kappa$ is put on the left ($[X,Y]_\\gamma=[X,Y]_0+\\kappa\\gamma$)'),
 "b_sign_handling_2":q(r,'docs/issues/final_reflection.md','with κ odd and'),
 "c_K":q(r,'docs/issues/I08.md','K` components dropped ("up to scalar" = modulo central terms) — **main reading**'),
 "c_K_2":q(r,'docs/issues/I08.md','| `strict_cent` | all components incl. `K` | $f:g\\to g\\oplus\\mathbb CK$ ($\\phi_K$ free) |')},
"test_range":{"class":"joint + profiles: 8 numeric profiles",
 "summary":"Joint: C_triviality.py Eliminator keeps the right-hand side as linear forms in gb; rows reducing to 0 = l(gb) give the conditions on all gb at once (reported rank 0 for mod_K and strict_cent, 4n for strict). In addition each of the 8 Layer 3 profiles is solved and re-substituted into Layer 4.",
 "evidence":q(r,'docs/issues/I08.md','so that rows reducing to $0=\\ell(\\mathrm{gb})$ give the exact linear conditions on gb;')},
"computation":{"code":["src/C_triviality.py (Eliminator, symbolic-RHS elimination, three modes mod_K/strict/strict_cent, closed-form f check)","src/C_coboundary.py (delta f, phi unknowns)","src/C_gamma.py","src/C_evaluate.py","src/C_osc.py (oscillator algebra)","src/verify_C_structure.py"],
 "rank_computation":"src/C_triviality.py Eliminator.rank / .conditions",
 "hardcoded_or_placeholder":"none found (grep placeholder/dummy/todo/hard-code over src/*.py: no hits)"},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','[mod_K] eqs=110 unknowns=32 rank(delta)=28 gb-condition rank=0'),
 "vs_reference_and_g_summary":"Reported delta ranks 28/168/516 (K dropped or f into g+CK: strict_cent 32/176/528 with K unknowns 36/184/540) equal the reference numbers; kernel dims 4/8/12 reported ('dim ker delta = # unknowns - rank = 4,8,12'). "+gs(r)},
"rerun":"not done",
"argument_issues":[{"quote":q(r,'docs/issues/final_reflection.md','The harness blocked two shell commands')['quote'],"loc":q(r,'docs/issues/final_reflection.md','The harness blocked two shell commands')['loc'],
  "contradicts":DEN.format(r=r,n=4)+" (cat loop on handover docs; python heredoc editing C_generators.py; sed -i on an issue file; python3 src/C_gamma.py > /tmp/i05.log ...)."}],
"consistency_with_data":"Stated class is reading-dependent. Main reading (K dropped / f into g+CK) = 'all gb trivial': matches data_implies 'all gb trivial' (K dropped). Strict reading 'trivial iff gb=0' = data_implies for K kept. Run's own conclusions equal both readings of data_implies (n1 and n2). Declared K treatment: K kept in gamma (Z=K entries, 20/84/180 per I05) but compared 'modulo central terms' in main reading. Test (b): the headline conclusion is K-dependent (the strict reading with K kept flips it).",
"notes":[NOTURN2,"Writes /tmp/i05.log inside a command that was denied (command text only; run.json outside_refs is empty).","Final reflection claims 'Every checker has a negative control' (not checked by me)."],
"quote_convention":QC})
out.append(d)

# ---------- opus55-b04
r='thm01-R-opus55-b04-G'
d=base(r)
d.update({
"stated_conclusion":q(r,'docs/issues/I08.md','1. *(g-valued / L = g ⊕ κg)* The inhomogeneous deformation of C(n+1) is trivial for **all** gb ∈ ℂ^{4n}.'),
"stated_conclusion_class":CLS_COND,
"stated_conclusion_note":[q(r,'docs/issues/I08.md','2. *(strict, generators may only change by g-valued κ-terms)* Trivial ⇔ gb_{σ,j,s} = 0 for all σ, j, s.'),q(r,'docs/issues/I08.md','- Which answer is the "triviality condition" depends on which notion is meant.')],
"scope":{"n123":q(r,'docs/issues/I08.md','gb ∈ ℂ^{4n}. There is no condition on gb. This holds for n = 1, 2, 3 by exact computation, and for all n by the'),
 "general_n":q(r,'docs/issues/I08.md','### 4. Conjecture / theorem (proved for all n, verified exactly for n = 1, 2, 3)')},
"declared_reading":{
 "a_parity_gb":q(r,'docs/issues/I05.md','Adopted (b); recorded in `gb_matrix.parameter_type`.'),
 "b_sign_handling":q(r,'docs/issues/I05.md','κ odd central, κ² = 0'),
 "c_K":q(r,'docs/issues/I08.md','- T3: γ + γ_K K = δf with f g-valued (strict).'),
 "c_K_2":q(r,'docs/issues/I08.md','- T2: γ + γ_K K = δf + δh.')},
"test_range":{"class":"joint + profiles: all_plus, all_minus, row_sign, boson_sign, alternating_j, single_a1p_b1p, zero",
 "summary":"Joint: symbolic right-hand side eliminated exactly ('the span of these forms is exactly the necessary-and-sufficient condition'); T1/T2 conditions none, T3 conditions rank 4n. Profiles solved and substituted back as well.",
 "evidence":q(r,'docs/issues/I08.md','leaves a linear form in gb that must vanish. The span of these forms is **exactly** the necessary-and-sufficient')},
"computation":{"code":["src/C_triviality.py (exact sparse rational elimination; T1/T2/T3; closed-form F check)","src/C_coboundary.py (phi unknowns + central psi)","src/C_gamma.py","src/C_evaluate.py","src/C_oscillator.py","src/verify_C_structure.py"],
 "rank_computation":"src/C_triviality.py (eliminator)",
 "hardcoded_or_placeholder":"none found"},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','== n=1 C(2) = osp(2|2): odd 1-cochains=32, rank δ=28, dim ker δ=4 (dim g_odd=4)'),
 "vs_reference_and_g_summary":"rank delta 28/168/516 with kernel 4/8/12 (n=3: 'odd 1-cochains=528, rank δ=516'); equal to reference (K dropped). With central h: reference K-kept 32/176/528 not stated numerically as ranks (T2 unknowns include psi). "+gs(r)},
"rerun":"not done",
"argument_issues":[],
"consistency_with_data":"Stated headline (g-valued, K dropped) 'all gb trivial' matches data_implies n1/n2 'all gb trivial' (K dropped); strict reading 'trivial iff gb=0' matches data_implies (K kept). Declared K treatment: kept in gamma as kappa*K (central entries 20/84/180 in I05 'central entries=20'), three notions reported. Test (b): headline conclusion is K-dependent in the sense that the K-kept strict reading flips it.",
"notes":[NOTURN2,DEN.format(r=r,n=6)+" The final reflection does not state a count."],
"quote_convention":QC})
out.append(d)

# ---------- opus55-b06
r='thm01-R-opus55-b06-G'
d=base(r)
d.update({
"stated_conclusion":q(r,'docs/issues/I08.md','1. **(Main: trivial up to scalars.)** It is **always trivial**'),
"stated_conclusion_class":CLS_COND,
"stated_conclusion_note":[q(r,'docs/issues/I08.md','2. **(Strict.)** With $f:\\mathfrak g\\to\\mathfrak g$ required, it is trivial **iff gb = 0**.'),q(r,'docs/issues/final_reflection.md','So the deformation is strictly trivial iff gb = 0.')],
"scope":{"n123":q(r,'docs/issues/I08.md','1)–(3) hold for n=1,2,3 by exact computation.'),
 "general_n":q(r,'docs/issues/I08.md','So I expect them to hold for all n.')},
"declared_reading":{
 "a_parity_gb":q(r,'docs/issues/I05.md','so in $[b,a] = -\\mathrm{gb}\\,\\kappa$ the coefficient must be *even*'),
 "b_sign_handling":q(r,'docs/issues/I05.md','κ odd central in $A$ ($x\\kappa = (-1)^{p(x)}\\kappa x$, $\\kappa^2=0$)'),
 "c_K":q(r,'docs/issues/I08.md','| **A** (adopted as the main reading) | $\\mathfrak g \\to \\mathfrak g \\oplus \\mathbb{C}K$ | all, including K | trivial up to central scalars ($K = 1$); this is how I read "up to scalar" |')},
"test_range":{"class":"joint + profiles: all_plus, all_minus, checker, rowsign, single, zero (+16 sign vectors for n=1)",
 "summary":"Joint: symbolic solve with Layer 2 (gamma symbolic in gb), conditions rank 0 (modes A, C) or 4n (mode B). Plus numeric profiles in all 3 modes and closed-form f checked on every unit gb vector.",
 "evidence":q(r,'docs/issues/I08.md','n=1 symbolic mode B: conditions rank 4/4 -> trivial iff gb = 0')},
"computation":{"code":["src/triviality_search.py (modes A/B/C, symbolic Layer 2 solve)","src/gauge_f.py (closed-form f)","src/coboundary.py","src/gamma.py","src/evaluate.py","src/oscalg.py","src/verify_gamma.py","src/verify_C_structure.py"],
 "rank_computation":"src/triviality_search.py",
 "hardcoded_or_placeholder":"none found"},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','n=1 allplus  A:trivial(rank 32/36, null 4, chk 0)'),
 "vs_reference_and_g_summary":"Printed 'rank X/Y' = rank / number of unknowns: mode A (f into g+CK) 32/36, 176/184, 528/540; modes B and C (f into g) 28/32, 168/176, 516/528. Equal to the reference numbers (K kept: 32/176/528; K dropped 28/168/516). "+gs(r)},
"rerun":"not done",
"argument_issues":[{"quote":q(r,'docs/issues/final_reflection.md','Two tool-level permission prompts were declined/blocked: a shell `awk` pipe and a shell heredoc redirect into `tests/`.')['quote'],"loc":q(r,'docs/issues/final_reflection.md','Two tool-level permission prompts were declined/blocked')['loc'],
  "contradicts":DEN.format(r=r,n=4)+" Commands: cat loop on handover docs; three python heredocs (src/C_evaluate.py, src/C_coboundary.py, docs/issues/I08.md edits); no awk pipe and no heredoc into tests/ among them."}],
"consistency_with_data":"Headline (main reading A: f into g+CK, K compared) 'all gb trivial' matches data_implies 'all gb trivial' for K dropped; strict reading 'trivial iff gb=0' matches data_implies for K kept. Declared K treatment: K kept in gamma ('K-entries=20' I05), f into g+CK. Test (b): headline is K-dependent (strict reading flips).",
"notes":[NOTURN2,"Reflection and I08 both state the strict reading result; I08 says 'The main conclusion depends on reading \"up to scalar\" as \"modulo central K\"'.","Run has 70 passed tests (I08 last line)."],
"quote_convention":QC})
out.append(d)

# ---------- opus55-b08
r='thm01-R-opus55-b08-G'
d=base(r)
d.update({
"stated_conclusion":q(r,'docs/issues/I08.md','**Necessary and sufficient condition on gb (adopted reading): none — every gb matrix gives a trivial deformation.**'),
"stated_conclusion_class":CLS_COND,
"stated_conclusion_note":[q(r,'docs/issues/I08.md','strict-g — trivial **iff gb = 0**,')],
"scope":{"n123":q(r,'docs/issues/I08.md','combinations: 0 mismatches.)'),
 "general_n":q(r,'docs/issues/I08.md','### 3. General statement (conjecture → with a proof sketch valid for all n)')},
"declared_reading":{
 "a_parity_gb":q(r,'docs/issues/I05.md','but compute with gb as commuting scalars.'),
 "b_sign_handling":q(r,'docs/issues/I05.md','κ odd central, κ² = 0, κ moved to the left with sign'),
 "c_K":q(r,'docs/issues/I08.md','*Adopted reading*: **mod-K**')},
"test_range":{"class":"per-direction + profiles: 9 profiles per n (all_plus, all_minus, row_sign, col_sign, checkerboard, index_parity, single_p_1_p, random_signs, zero)",
 "summary":"Part B solves gamma = delta f for generic odd f at each profile and for each single gb parameter ('single gb parameters solvable ... strict-g 0/4 ... mod-K 4/4'), floating-point SVD with exact Fraction check of the explicit solution; Part D checks the K identity symbolically in gb. No joint symbolic-RHS elimination.",
 "evidence":q(r,'docs/issues/I08.md','single gb parameters solvable (n=1/2/3): strict-g 0/4, 0/8, 0/12; mod-K 4/4, 8/8, 12/12; strict-gK 4/4, 8/8, 12/12')},
"computation":{"code":["src/C_triviality.py (profiles, generic-f least squares/rank, exact check)","src/C_coboundary.py (f_gb closed form + generic delta f)","src/C_gamma.py","src/C_evaluate.py","src/oscillator.py","src/verify_C_structure.py"],
 "rank_computation":"src/C_triviality.py (float SVD/rank; I08: 'rank 516/517, res 1.0e+00' strict-g, 'rank 516/516, res 1.1e-14' mod-K)",
 "hardcoded_or_placeholder":"none found"},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','n=1: rows=160   unknowns g=32  K=4 ; dim ker δ (g-valued f) = 4  = dim g_odd'),
 "vs_reference_and_g_summary":"kernel dims 4/8/12; strict-g rank 516 -> [A|G] 517 at n=3 (K-kept reference 516 -> 528 are different measures: here rank of b-augmented is 517). Own ranks (g_summary): see below. "+gs(r)},
"rerun":"not done",
"argument_issues":[{"quote":q(r,'docs/issues/final_reflection.md','Two harness permission prompts blocked shell commands')['quote'],"loc":q(r,'docs/issues/final_reflection.md','Two harness permission prompts blocked shell commands')['loc'],
  "contradicts":DEN.format(r=r,n=4)+" Commands: cat loop on handover docs; cat >> docs/json_schema_specification.md heredoc; python heredoc editing I07.md; 'time python3 src/C_triviality.py | tee ...'."}],
"consistency_with_data":"Adopted reading (mod-K) 'all gb trivial' matches data_implies 'all gb trivial' (K dropped); strict-g 'trivial iff gb=0' matches data_implies (K kept). Declared K: kept as separate gamma_K field, compared in 3 readings. Test (b): headline conclusion is K-dependent in the sense that K-kept strict flips it.",
"notes":[NOTURN2,"Per-direction tests are combined with linearity ('same pattern holds for every profile'); no joint rank test of [A|G] over all gb is reported."],
"quote_convention":QC})
out.append(d)

# ---------- opus55-b10
r='thm01-R-opus55-b10-G'
d=base(r)
d.update({
"stated_conclusion":q(r,'docs/issues/I08.md','inhomogeneous deformation of C(n+1) is trivial for all gb. There is no condition on the gb'),
"stated_conclusion_class":CLS_COND,
"stated_conclusion_note":[q(r,'docs/issues/I08.md','(Strict variant: f: g → g with exact equality including the K-part ⇔ gb = 0.)'),q(r,'docs/issues/final_reflection.md','result is "trivial iff gb = 0".')],
"scope":{"n123":q(r,'docs/issues/I08.md','- **Result.** For n = 1, 2, 3 and **every** gb ∈ ℚ^{4n}, the deformation γ is a coboundary:'),
 "general_n":q(r,'docs/issues/I08.md','- **Conjecture (proof sketch for all n in §4; computation for n ≤ 3).**')},
"declared_reading":{
 "a_parity_gb":q(r,'docs/issues/I05.md','Decision: gb are **commuting scalars**;'),
 "b_sign_handling":q(r,'docs/issues/I05.md','normal ordered with κ moved'),
 "c_K":q(r,'docs/issues/I08.md','| `mod_K` (doc\'s "up to scalar") | W ∈ g | φ (f: g→g) |')},
"test_range":{"class":"joint + profiles: 9 Layer 3 profiles + 4n unit vectors",
 "summary":"All targets (9 profiles incl. zero plus the 4n unit gb vectors) are solved at once with an exact sparse eliminator in three readings; solutions re-substituted; trivial dimension per reading listed (13/13, 17/17, 21/21 trivial in mod_K and exact). Unit vectors trivial/non-trivial gives the subspace by linearity.",
 "evidence":q(r,'docs/issues/I08.md','It solves δf = γ for all targets at once with an **exact sparse rational eliminator** (no')},
"computation":{"code":["src/C_triviality.py (exact eliminator, readings mod_K/exact/strict)","src/C_triviality_report.py","src/C_cohomology.py (Z^2_odd vs B^2_odd dims)","src/C_coboundary.py","src/C_gamma.py","src/C_evaluate.py","src/oscillator_algebra.py","src/verify_C_structure.py","src/verify_C_gamma.py","src/verify_C_coboundary.py"],
 "rank_computation":"src/C_triviality.py / src/C_cohomology.py",
 "hardcoded_or_placeholder":"none found"},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','[mod_K] unknowns=32 rank=28 kernel=4  trivial=13/13  non-trivial=[]'),
 "vs_reference_and_g_summary":"ranks 28/168/516 (mod_K, strict), 32/176/528 (exact, K unknowns 36/184/540); equal to reference. Also dim Z^2_odd = B^2_odd = 28/168/516 ('dim H^2_odd=0'). "+gs(r)},
"rerun":"not done",
"argument_issues":[],
"consistency_with_data":"Headline (mod_K / exact) 'all gb trivial' matches data_implies 'all gb trivial' (K dropped); strict 'trivial iff gb=0' matches data_implies (K kept). Declared K: kept (psi unknowns for central part), three readings. Test (b): headline conclusion (doc's 'up to scalar' = mod K) is K-dependent in that the strict K-kept reading flips it.",
"notes":[NOTURN2,DEN.format(r=r,n=5)+" The reflection states 'The only input was the initial instruction.'","Extra data files data/C_{1,2,3}_triviality.json."],
"quote_convention":QC})
out.append(d)

import pickle
pickle.dump(out,open('opus.pkl','wb'))
print(len(out)); print(ERR)
