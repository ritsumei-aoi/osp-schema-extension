import json,sys
R='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/runs/batch/'
r=sys.argv[1]
d=json.load(open(R+r+'/run.json'))
for k,v in d.items():
    if k=='turns':
        for t in v:
            print('turn',t['turn'],{k2:t[k2] for k2 in t if k2 not in('text','usage','result','modelUsage')})
            print('  RESULT:',t.get('result','')[:int(sys.argv[2]) if len(sys.argv)>2 else 3000])
    else: print(k,':',str(v)[:600])
