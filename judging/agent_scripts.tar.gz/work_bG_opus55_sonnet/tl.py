import gzip,json,sys,re
R='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/runs/batch/'
r=sys.argv[1]; pat=re.compile(sys.argv[2]) if len(sys.argv)>2 else None
m=[json.loads(l) for l in gzip.open(R+r+'/turn1.jsonl.gz')]
for i,x in enumerate(m):
    msg=x.get('message',{})
    c=msg.get('content') if isinstance(msg,dict) else None
    if isinstance(c,list):
        for b in c:
            if b.get('type')=='tool_use':
                s=json.dumps(b['input'],ensure_ascii=False)
                if pat is None or pat.search(s): print(i,b['name'],s[:int(sys.argv[3]) if len(sys.argv)>3 else 300])
