import json,csv,os,re
J='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/'
REV='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/'
G={r['run']:r for r in csv.DictReader(open(REV+'judging/g_summary.csv'))}
INV={r['run']:r for r in csv.DictReader(open(REV+'judging/inventory.csv'))}
ERR=[]
def q(run,file,text):
    p=J+run+'/'+file
    for i,l in enumerate(open(p,encoding='utf-8'),1):
        if text in l:
            return {"quote":text,"loc":f"{file}:{i}"}
    ERR.append((run,file,text)); return {"quote":text,"loc":"NOT FOUND"}
def gs(run):
    g=G[run]
    return (f"g_summary.csv (run's own data): gamma vs generator n1 '{g['gamma_n1']}'; reference-A ranks (K dropped / K kept) n1 {g['rank_nonK_n1']} / {g['rank_K_n1']}, n2 {g['rank_nonK_n2']} / {g['rank_K_n2']}; "
            f"own-A n1 {g['ownA_nonK_n1'] or 'n/a'} / {g['ownA_K_n1'] or 'n/a'}, n2 {g['ownA_nonK_n2'] or 'n/a'} / {g['ownA_K_n2'] or 'n/a'}; data_implies n1 '{g['data_implies_n1']}', n2 '{g['data_implies_n2']}' (K dropped / K kept).")
def base(run):
    i=INV[run]
    return {"run":run,"commit_checked":f"final ({i['commit_final']})"}
QC="'quote' fields are verbatim substrings; 'loc' = file:line (first line containing the quote), computed by the extraction script from the run copy $JROOT/final/<run>/. Fields named summary/note/evidence-description/contradicts are paraphrases. 'agent computation' = script saved in the scratch dir work_bG_opus55_sonnet/. Reference ranks: n=1 28 (A) vs 28 (K dropped) or 32 (K kept); n=2 168 vs 168/176; n=3 516 vs 516/528."
RUNDIR='runs/batch/{run}/turn1.jsonl.gz'
