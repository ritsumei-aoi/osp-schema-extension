from build_common import *
import pickle
out=[]
NOTURN2="No turn2.jsonl.gz exists in runs/batch/<run>/ (only turn1.jsonl.gz and run.json); the final reflection was written and committed in turn 1 (docs/issues/final_reflection.md)."
DEN="Count of permission_denials in the last record of runs/batch/{r}/turn1.jsonl.gz = {n} (agent computation: pd.py)."
CLS_COND="conditional/other (reading-dependent; headline = all gb trivial when f may take K values / K ignored, trivial iff gb=0 under the strict reading)"

# ---------- sonnet55-b02
r='thm01-R-sonnet55-b02-G'
d=base(r)
d.update({
"stated_conclusion":q(r,'docs/issues/I08.md','- **(A/B) For C(n+1) the inhomogeneous deformation is trivial for every gb ∈ C^{4n}**'),
"stated_conclusion_class":CLS_COND,
"stated_conclusion_note":[q(r,'docs/issues/I08.md','- **(C, strict reading f: g→g and K-part compared)**: trivial **iff gb = 0** (all 4n parameters vanish).'),q(r,'docs/issues/final_reflection.md','Main conclusion: the deformation is trivial for every gb if f may take values in g⊕CK')],
"scope":{"n123":q(r,'docs/issues/I08.md','**4. Conjecture** (supported for n=1,2,3, with the general mechanism above):'),
 "general_n":q(r,'docs/issues/I08.md','Proof idea (valid for all n)'),
 "caveat":q(r,'docs/issues/I08.md','n ≥ 4 not computed (the argument is n-independent)')},
"declared_reading":{
 "a_parity_gb":q(r,'docs/issues/I05.md','Assumption: gb are numeric scalars, the "parity 1" is carried by κ.'),
 "b_sign_handling":q(r,'docs/issues/I05.md','it anticommutes with the odd a_1^±, commutes with b.'),
 "c_K":q(r,'docs/issues/I08.md','My reading A is the one forced by the oscillator realization (K = 1 ∈ U(A)); reading C is the literal "f: g→g" reading.')},
"test_range":{"class":"per-direction + profiles: all_plus, all_minus, alternating, sigma_p_only, single_first, zero + K-only (rank 4n of gb->gamma_K, reading C)",
 "summary":"General odd f solved (all phi_ij, float lstsq/rank) for every profile and every unit gb vector in readings A/B/C; trivial for all gb follows from solvability of all unit vectors by linearity; the 'iff gb=0' claim rests on the K component map of rank 4n.",
 "evidence":q(r,'docs/issues/I08.md','(cases = all profiles except zero and each of the 4n unit gb-vectors')},
"computation":{"code":["src/C_triviality.py (comparison_matrix, build_operator, solve_reading: numpy matrix_rank / lstsq)","src/C_coboundary.py (f_c from oscillator shift, delta f)","src/C_gamma.py","src/C_evaluate.py","src/C_generators.py","src/C_oscillator.py","src/verify_C_structure.py"],
 "rank_computation":"src/C_triviality.py solve_reading (float, residuals reported 1.9e-14 / 1.6e+01)",
 "hardcoded_or_placeholder":"none found"},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','n=1: reading A unknowns=36  rank=32  kernel_dim=4   max residual (9 γ cases)  1.9e-14'),
 "vs_reference_and_g_summary":"Reported (n=1/2/3): reading A unknowns 36/184/540, rank 32/176/528; readings B and C unknowns 32/176/528, rank 28/168/516; equal to reference (K kept 32/176/528, K dropped 28/168/516). "+gs(r)},
"rerun":"not done",
"argument_issues":[],
"consistency_with_data":"Headline (A/B) 'all gb trivial' matches data_implies 'all gb trivial' (K dropped); strict (C) 'trivial iff gb=0' matches data_implies (K kept). Declared K: kept (Z=K in gamma, f into g+CK in reading A). Test (b): the headline conclusion depends on K treatment (the K-kept strict reading flips it).",
"notes":[NOTURN2,"Final reflection discloses writing helper files to /tmp (outside the repository, against session rule 5): "+q(r,'docs/issues/final_reflection.md','One deviation to disclose:')['loc'],"Untracked scratch/ directory in the workspace (inventory/run.json uncommitted '?? scratch/'); not in the committed copy.",DEN.format(r=r,n=5),"Final reflection says 'the harness twice only asked me to state what I was doing'; no such message found in turn1.jsonl.gz (the log does not contain the harness messages as user text; not checkable)."],
"quote_convention":QC})
out.append(d)

# ---------- sonnet55-b04
r='thm01-R-sonnet55-b04-G'
d=base(r)
d.update({
"stated_conclusion":q(r,'docs/issues/I08.md','1. **(T1/T3) Conjecture A:** for every n >= 1 and **every** gb in `C^{4n}`, `gamma(gb)` is a coboundary'),
"stated_conclusion_class":CLS_COND,
"stated_conclusion_note":[q(r,'docs/issues/I08.md','2. **(T2) Conjecture B:** if f must take values in g (no central component) and the central part of gamma is kept, then the deformation is trivial **iff gb = 0**'),q(r,'docs/issues/I08.md','**Adopted reading for the headline conclusion: T1 (f: g -> g (+) C K)')],
"scope":{"n123":q(r,'docs/issues/I08.md','These are computed facts for n=1,2,3 (exact where stated, see Section 4); the general-n statements are conjectures'),
 "general_n":q(r,'docs/issues/I08.md','the general-n statements are conjectures supported by a structural argument (Section 5)')},
"declared_reading":{
 "a_parity_gb":q(r,'docs/issues/I05.md','Assumption: gb are ordinary numerical scalars multiplying the formal odd kappa'),
 "b_sign_handling":q(r,'docs/issues/I05.md','kappa written on the left of all words'),
 "c_K":q(r,'docs/issues/I08.md','- **Ambiguity 1 (central K):**')},
"test_range":{"class":"joint + profiles: all_plus, alternating, fermion_sign, boson_sign, single_first, zero + K-only (exact rank of gb->gamma_K)",
 "summary":"Part B: unknowns = all odd phi (plus K constants in T1) AND gb (4n) together; the solution set projected to gb gives the trivial subspace dimension (SVD, tol 1e-8), plus exact Fraction rank of gb->gamma_K. Part A compares Layer 3/4 for profiles with c matched to gb.",
 "evidence":q(r,'docs/issues/I08.md','Unknowns: every odd `phi_ij`')},
"computation":{"code":["src/triviality_search.py (comparison + search)","src/C_triviality.py (linear algebra core; committed with I06 per final reflection)","src/C_coboundary.py (f_c odd derivation, 4n parameters)","src/C_gamma.py","src/C_evaluate.py","src/osc_algebra.py","src/C_generators.py","src/verify_C_gamma.py","src/verify_C_structure.py"],
 "rank_computation":"src/triviality_search.py / src/C_triviality.py (SVD null space + exact Fraction rank of K map)",
 "hardcoded_or_placeholder":"none found"},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','n=1: strict (T2)=0/4   gonly (T3)=4/4   const (T1)=4/4'),
 "vs_reference_and_g_summary":"No delta ranks printed; K-map rank 4/8/12 and kernel dims not stated. "+gs(r)+" g_summary own-A ranks 4->4 / 8->8: the run's Layer 4 is the 4n-parameter family f_c, not generic phi."},
"rerun":"not done",
"argument_issues":[],
"consistency_with_data":"Headline (T1/T3) 'all gb trivial' matches data_implies 'all gb trivial' (K dropped); T2 'trivial iff gb=0' matches data_implies (K kept). Declared K: kept as Z=K in gamma, f into g+CK in T1. Test (b): headline is K-dependent (the K-kept strict reading flips it).",
"notes":[NOTURN2,DEN.format(r=r,n=8),"I08 states Layer 4 is built from the same oscillator shift that removes gb and that the general search (Part B) is independent."],
"quote_convention":QC})
out.append(d)

# ---------- sonnet55-b06
r='thm01-R-sonnet55-b06-G'
d=base(r)
d.update({
"stated_conclusion":q(r,'docs/issues/I08.md','is trivial for **every** gb ∈ C^{4n} (no condition on gb)'),
"stated_conclusion_class":"all gb trivial",
"stated_conclusion_note":[q(r,'docs/issues/I08.md','such γ is **non-trivial for every gb ≠ 0** (trivial iff gb = 0).')],
"scope":{"n123":q(r,'docs/issues/I08.md','Evidence: exact for n=1,2,3 (T = whole 4n-dim space, via linearity'),
 "general_n":q(r,'docs/issues/I08.md','so the statement is conjectured (and argued) for all n ≥ 1; a fully written induction/proof for general n is not done.')},
"declared_reading":{
 "a_parity_gb":"label only ('parity 1' in docs/json_schema_specification.md:121); no statement about commuting vs Grassmann-odd gb in I05/I07/I08",
 "a_parity_gb_loc":q(r,'docs/json_schema_specification.md','`parity` 1,')['loc'],
 "b_sign_handling":q(r,'docs/issues/I05.md','κ odd central, so κa = −aκ, κb = bκ, κ² = 0'),
 "c_K":q(r,'docs/issues/I05.md','Option 2 gives γ ∈ g for all pairs (no residual in the exact decomposition) and is the canonical choice'),
 "c_K_2":q(r,'docs/issues/I08.md','- Triviality means: ∃ odd linear f: g → g (g = span of the Schema 1 basis, no K) with γ = δf')},
"test_range":{"class":"joint + profiles: 29 (n=1, incl. all 16 sign vectors), 17 (n=2), 21 (n=3) stored profiles",
 "summary":"gamma linear in gb, so the trivial set T is a subspace determined by the 4n unit vectors (exact rank over Q); classes of restricted f tested (odd->even only, even->odd only, vanishing on Cartan, ...).",
 "evidence":q(r,'docs/issues/I08.md','it is determined exactly by the 4n unit vectors (rank computation over ℚ, no sampling)')},
"computation":{"code":["src/triviality_search.py (trivial_subspace, nullspace, compare_layers, central_residual)","src/gauge_f.py (closed-form f from the gauge shift)","src/coboundary.py","src/gamma.py","src/evaluate.py","src/oscalg.py","src/verify_gamma.py","src/verify_C_structure.py","scripts/close_issue.py and scripts/probe_gauge.py (helper scripts in the repo)"],
 "rank_computation":"src/triviality_search.py trivial_subspace (exact rational elimination)",
 "hardcoded_or_placeholder":"none found"},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','| 1 | 32 | 28 | 4 | 4 of 4 | 0 | 0 | 0 | 4 of 4 |'),
 "vs_reference_and_g_summary":"#odd maps 32/176/528, rank delta 28/168/516 equal reference (K dropped); no K in the run's gamma, so K-kept reference 32/176 is not applicable. "+gs(r)},
"rerun":"not done",
"argument_issues":[],
"consistency_with_data":"Stated class 'all gb trivial' matches data_implies 'all gb trivial / all gb trivial' (K dropped / K kept; the run's gamma has no K: odd generators are Weyl-symmetrised, I05 option 2). Test (b): not K-dependent in the run's own data; I08 section 4(a) states that with normal-ordered odd generators (K appears) the g-valued result is 'trivial iff gb = 0'.",
"notes":[NOTURN2,DEN.format(r=r,n=7),"Extra directories in the copy: docs/responses/ (I01..I08 copies) and scripts/ (close_issue.py, probe_gauge.py); final reflection says probe_gauge.py was left in place.","Run chose Weyl-symmetrised odd generators (I05 'Chose option 2'), which removes K from gamma by construction."],
"quote_convention":QC})
out.append(d)

# ---------- sonnet55-b08
r='thm01-R-sonnet55-b08-G'
d=base(r)
d.update({
"stated_conclusion":q(r,'docs/issues/I08.md','- **(C-E)** For every n ≥ 1 and **every** gb, γ is a coboundary of an odd map f: g → g ⊕ ℂK: there is no condition on gb.'),
"stated_conclusion_class":CLS_COND,
"stated_conclusion_note":[q(r,'docs/issues/I08.md','- **(C-S)** For f restricted to g: γ is a coboundary **iff gb = 0**.'),q(r,'docs/issues/I08.md','I regard (E) as more plausible but cannot confirm from the documents.')],
"scope":{"n123":q(r,'docs/issues/I08.md','Computationally confirmed for n = 1, 2, 3.'),
 "general_n":q(r,'docs/issues/I08.md','The argument is general (not n-specific)')},
"declared_reading":{
 "a_parity_gb":q(r,'docs/issues/I05.md','4n parameters `gb_a_1_{σ}_b_{j}_{s}`, parity 1.'),
 "b_sign_handling":q(r,'docs/issues/I05.md','κ odd central (κ moves left past fermions with a sign)'),
 "c_K":q(r,'docs/issues/I08.md','- **(E) extended**: ∃ odd f: g → g ⊕ ℂK with δf = λγ (λ absorbed into f).'),
 "note":"No discussion of the commuting vs Grassmann-odd reading of gb in I05/I08 beyond the label 'parity 1'; I08 lists A1 (E_{±2δ} normalization) and A2 (H_1 includes so(2) part, K = 1 identification) as assumptions."},
"test_range":{"class":"joint + profiles: all_plus, all_minus, zero, sigma_p_only, sigma_m_only, alternating, unit_first + K-only (exact rank of gb->gamma^K)",
 "summary":"Layer 3 vs Layer 4 compared for 7 profiles per n (closed-form f_gb); numerical solve of [delta | -gamma] (SVD) gives the dimension of {gb : gamma(gb) in im delta} in each version (E: 4/8/12, S: 0).",
 "evidence":q(r,'docs/issues/I08.md','Numerical solve of the full linear system [δ | −γ] (SVD), dimension of {gb : γ(gb) ∈ im δ}:')},
"computation":{"code":["src/C_triviality.py (profile comparison, K_obstruction exact rank, SVD solve)","src/C_coboundary.py (closed-form f_gb, strict variant)","src/C_gamma.py","src/C_evaluate.py","src/C_generators.py","src/_explore.py (leftover scratch script, repurposed per final reflection)","src/verify_C_structure.py"],
 "rank_computation":"src/C_triviality.py (SVD tol 1e-9; exact rank over Q for K map)",
 "hardcoded_or_placeholder":"none found"},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','n=1: #gb=4   (S) f:g->g -> 0    (E) f:g->g+CK -> 4    (S) vs g-part of gamma only -> 4'),
 "vs_reference_and_g_summary":"'#φ − rank δ = 4, 8, 12'; K_obstruction rank 4/8/12. Delta ranks not printed. "+gs(r)},
"rerun":"not done",
"argument_issues":[],
"consistency_with_data":"Headline (E) 'all gb trivial' matches data_implies 'all gb trivial' (K dropped); (S) 'trivial iff gb=0' matches data_implies (K kept). Declared K: kept in gamma and compared in two versions. Test (b): headline is K-dependent (strict K-kept flips it).",
"notes":[NOTURN2,DEN.format(r=r,n=7),"src/_explore.py left in the repo (could not be deleted per final reflection); final reflection says the I05 commit was amended once.","Final reflection says 'a status ping asked me to say what I was doing' (not found in the log)."],
"quote_convention":QC})
out.append(d)

# ---------- sonnet55-b10
r='thm01-R-sonnet55-b10-G'
d=base(r)
a=q(r,'docs/issues/I08.md','- The extended-map kernel is trivial (rank(δ ext) = number of unknowns), i.e. f is unique in reading B;')
d.update({
"stated_conclusion":q(r,'docs/issues/I08.md','- (A, B) The g-valued part of the deformation is trivial for **every** gb ∈ C^{4n}: no condition on gb'),
"stated_conclusion_class":CLS_COND,
"stated_conclusion_note":[q(r,'docs/issues/I08.md','- (C) With f restricted to g and the κK residue included, the deformation is trivial **iff gb = 0**'),q(r,'docs/issues/I08.md','A human decision is needed on the reading before this is cited.')],
"scope":{"n123":q(r,'docs/issues/I08.md','verified for n = 1,2,3; the mechanism in §2 is n-independent'),
 "general_n":q(r,'docs/issues/I08.md','so I expect it in general but have not written a proof for all n')},
"declared_reading":{
 "a_parity_gb":q(r,'docs/issues/I05.md','Assumption adopted: gb are ordinary commuting scalars;'),
 "b_sign_handling":q(r,'docs/issues/I05.md','κ central odd, κ²=0, κ moved to the front with the graded sign'),
 "c_K":q(r,'docs/issues/I08.md','| C | g | full κ-part incl. γ_K | "strict" |'),
 "c_K_2":q(r,'docs/issues/I08.md','I judge **B** the natural one')},
"test_range":{"class":"joint + profiles: 5 per n (plus/minus/alt/zero/single) + K-only (rank gb->kappa K)",
 "summary":"Search over all odd f: dimension of the trivial gb-subspace {gb : gamma_gb in Im delta} computed jointly (float SVD) in readings A/B/C, plus rank of gb->gamma_K (4n).",
 "evidence":q(r,'docs/issues/I08.md','trivial gb-subspace dim (of 4):  g-part=4  strict=0  extended=4   rank(gb→κK)=4')},
"computation":{"code":["src/triviality_search.py (compare_layers, build_system, search, trivial_dim: numpy SVD/lstsq/matrix_rank)","src/C_coboundary.py","src/C_gamma.py","src/C_evaluate.py","src/C_generators.py","src/verify_C_structure.py"],
 "rank_computation":"src/triviality_search.py search / trivial_dim (float; tol in code)",
 "hardcoded_or_placeholder":"none found"},
"reported_numbers":{"reported":q(r,'docs/issues/I08.md','n=1: unknowns=32  rank(δ strict)=28  rank(δ ext)=32'),
 "vs_reference_and_g_summary":"rank(δ strict) 28/168/516 and rank(δ ext) 32/176/528 equal reference (K dropped / K kept). "+gs(r)},
"rerun":"not done",
"argument_issues":[{"quote":a['quote'],"loc":a['loc'],"contradicts":"src/triviality_search.py build_system returns columns nA (=32 phi unknowns, printed as 'unknowns=32') + nK (= len(odd) = 4 K constants) = 36 for n=1 (A_full = np.zeros((nrows, nA + nK))), and the same run prints rank(δ ext)=32; by the code, kernel of the extended map = 36 - 32 = 4 (not 0). Same pattern n=2: 176+8 vs 176; n=3: 528+12 vs 528 (from code and printed numbers; not rerun)."}],
"consistency_with_data":"Headline (A,B) 'all gb trivial' matches data_implies 'all gb trivial' (K dropped); (C) 'trivial iff gb=0' matches data_implies (K kept). Declared K: kept as separate central component and compared in three readings. Test (b): headline is K-dependent in that the strict K-kept reading flips it.",
"notes":[NOTURN2,DEN.format(r=r,n=9)],
"quote_convention":QC})
out.append(d)
pickle.dump(out,open('s55.pkl','wb')); print(len(out)); print(ERR)
