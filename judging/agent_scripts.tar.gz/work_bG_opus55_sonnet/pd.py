import gzip,json,sys
R='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/runs/batch/'
r=sys.argv[1]
for t in (1,2):
    try: m=[json.loads(l) for l in gzip.open(f'{R}{r}/turn{t}.jsonl.gz')]
    except Exception as e: print(t,'none',e); continue
    last=m[-1]
    print('turn',t,'n',len(m),'denials',json.dumps(last.get('permission_denials'))[:700])
