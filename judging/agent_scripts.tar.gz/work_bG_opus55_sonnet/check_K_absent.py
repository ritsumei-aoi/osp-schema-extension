import json,sys
J='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/'
for r in ['thm01-R-sonnet46-b01-G','thm01-R-sonnet46-b02-G','thm01-R-sonnet46-b04-G','thm01-R-sonnet46-b07-G','thm01-R-sonnet46-b11-G']:
    for n in (1,2,3):
        s=json.dumps(json.load(open(f'{J}{r}/data/C_{n}_gamma.json')))
        print(r,n,'K-labelled entries in gamma json:', s.count('"K"'))
