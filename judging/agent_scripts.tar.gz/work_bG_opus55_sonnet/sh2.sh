#!/bin/bash
J=/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final
cd $J/$1
echo "== I05 grep"; grep -n -i "parity\|commut\|sign conv\|scalar\|odd\|supercomm" docs/issues/I05.md | cut -c1-420 | head -${2:-14}
echo "== I07 grep"; grep -n -i " K\b\|central\|scalar" docs/issues/I07.md | cut -c1-350 | head -8
echo "== FR"; cat -n docs/issues/final_reflection.md | grep -i "blocked\|denied\|trivial\|scalar\|parity\|honest\|wall\|time\|human\|intervention\|gb" | cut -c1-500 | head -25
