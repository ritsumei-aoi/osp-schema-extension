from math import comb
for n in (1,2,3):
    m=2*n*n+n+1; q=4*n
    print('n',n,'m',m,'q',q,'total',m+q,
      '| (2n^2+n+1)*4n =',m*4*n,'| 8n(2n^2+n+1) =',8*n*m,'| 4n^2+2n =',4*n*n+2*n,'| 2n(2n^2+n+1) =',2*n*m,
      '| 2mq =',2*m*q,'| 2mq+1 =',2*m*q+1,
      '| luna-b07 cochain dim q(C(m,2)+C(q+1,2))+m^2 q =',q*(comb(m,2)+comb(q+1,2))+m*m*q)
