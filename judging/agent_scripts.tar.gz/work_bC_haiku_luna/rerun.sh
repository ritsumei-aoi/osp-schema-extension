#!/bin/bash
# usage: rerun.sh <run> <final|first>
S=/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad
run=$1; which=$2
W=$S/work_bC_haiku_luna/rr/$run-$which
rm -rf $W; mkdir -p $S/work_bC_haiku_luna/rr; cp -R $S/jroot/$which/$run $W
cd $W
find . -type f -not -path './.git/*' | sort | xargs shasum -a 256 > $S/work_bC_haiku_luna/rr/$run-$which.before
python3 --version; python3 -c "import sympy;print('sympy',sympy.__version__)"
for f in $(ls *.py docs/issues/*.py 2>/dev/null); do
  echo "### RUN $f"; timeout 600 python3 -I -c "import sys,runpy,os; sys.path.insert(0,os.path.dirname(os.path.abspath('$f')) or '.'); runpy.run_path('$f', run_name='__main__')" > $S/work_bC_haiku_luna/rr/$run-$which.$(basename $f).out 2>&1
  echo "exit $?"; 
done
find . -type f -not -path './.git/*' | sort | xargs shasum -a 256 > $S/work_bC_haiku_luna/rr/$run-$which.after
diff $S/work_bC_haiku_luna/rr/$run-$which.before $S/work_bC_haiku_luna/rr/$run-$which.after && echo "files unchanged (byte-identical)"
