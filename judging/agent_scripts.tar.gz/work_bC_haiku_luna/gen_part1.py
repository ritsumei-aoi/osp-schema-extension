import json,os,sys
S='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad'
FIN=S+'/jroot/final/'
_cache={}
def _lines(run,path):
    k=(run,path)
    if k not in _cache: _cache[k]=open(FIN+run+'/'+path,encoding='utf-8').read().split('\n')
    return _cache[k]
def _ok(txt,snip):
    pos=0
    for piece in snip.split('...'):
        piece=piece.strip()
        if not piece: continue
        i=txt.find(piece,pos)
        if i<0: return False
        pos=i+len(piece)
    return True
def Q(run,path,line,snip):
    L=_lines(run,path)
    for d in (0,1,-1,2,-2,3,-3):
        n=line+d
        if 1<=n<=len(L) and _ok(L[n-1],snip):
            return "'%s' (%s:%d)"%(snip,path,n)
    raise AssertionError("QUOTE NOT FOUND %s %s:%d %r ACTUAL: %r"%(run[-12:],path,line,snip[:70],L[line-1][:200]))
P='docs/issues/mathematical_proof.md'
