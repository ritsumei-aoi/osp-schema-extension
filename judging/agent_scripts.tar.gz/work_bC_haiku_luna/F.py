import sys
S='/private/tmp/claude-501/-<home>-notebook-git-ai-workflow-evaluation/5f641591-e209-4556-85bf-00c128d1c344/scratchpad/jroot/final/'
run,path,sub=sys.argv[1],sys.argv[2],sys.argv[3]
for i,l in enumerate(open(S+'thm01-R-'+run+'-C/'+path,encoding='utf-8'),1):
    if sub in l: print(i, l.rstrip()[:240])
