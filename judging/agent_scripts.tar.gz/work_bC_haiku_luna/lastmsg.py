import gzip,json,sys
R='<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/runs/batch/'
run,turn=sys.argv[1],sys.argv[2]
rows=[json.loads(l) for l in gzip.open(R+run+'/turn%s.jsonl.gz'%turn,'rt')]
print(len(rows),'rows; types',set(r.get('type') for r in rows))
last=None
for i,r in enumerate(rows):
    if r.get('type')=='assistant':
        c=r['message']['content']
        t=''.join(b.get('text','') for b in c if isinstance(b,dict) and b.get('type')=='text') if isinstance(c,list) else str(c)
        if t.strip(): last=(i,t)
print('LAST assistant text idx',last[0]); print(last[1])
