import json,sys
for f in sys.argv[1:]:
    for r in json.load(open(f)):
        rows=r['equations_count']; cols=r['f_vars_count']; ns=r['nullspace_dim']
        print(f"n={r['n']} dim_g={r['dim_g']} rows={rows} f_cols={cols} left_nullity={ns} rank_A={rows-ns} n_conditions={len(r['conditions'])} solution={r['solution']}")
