# agent computation: derive ranks from the rerun stdout of thm01-R-gemini31p-b05-C algebra.py
import re,sys
txt=open(sys.argv[1]).read()
for m in re.finditer(r"n=(\d): Variables = (\d+), Equations = (\d+)\nNullspace dimension: (\d+)", txt):
    n,V,E,d=map(int,m.groups())
    print(f"n={n}: columns(f+gb)={V}, rows={E}, nullity([A|-G])={d}, rank([A|-G])={V-d}, f_columns={V-4*n}, nullity==4n:{d==4*n}")
