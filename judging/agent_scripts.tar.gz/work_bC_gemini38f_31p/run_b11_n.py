# agent script: call the committed solve_cohomology.solve_for_n for a given n (committed __main__ only runs n=1)
import sys
sys.path.insert(0, '.')
import solve_cohomology
solve_cohomology.solve_for_n(int(sys.argv[1]))
