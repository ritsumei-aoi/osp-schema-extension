# agent computation: evaluate the det formula stated at thm01-R-gemini38f-b12-C docs/issues/mathematical_proof.md:89
from fractions import Fraction
from math import comb
for n in (1,2,3):
    print(n, Fraction((-1)**comb(n,2), 2**(n+1)))
