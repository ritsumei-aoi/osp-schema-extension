import json,sys
# agent computation: number of gamma_terms per n; distinct gamma_coeff values; fraction with Z==Y
root,run=sys.argv[1:3]
for n in (1,2,3):
    d=json.load(open(f"{root}/{run}/data/C_{n}_gamma.json"))
    t=d['inhomogeneous_deformation']['gamma_terms']
    print(run,n,'gamma_terms',len(t),'Z==Y',sum(1 for x in t if x['Z']==x['Y']),'Z==kappa',sum(1 for x in t if x['Z'] in('kappa','κ')),'distinct coeffs',len({x['gamma_coeff'] for x in t}))
