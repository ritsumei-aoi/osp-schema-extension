import json,sys
from fractions import Fraction
# agent computation: K-rows of gamma for luna-b10: coefficient of each gb at the witness pairs claimed in I08.md:63-70
root='%s/thm01-R-luna-b10-G/data'%sys.argv[1]
for n in (1,2,3):
    d=json.load(open(f'{root}/C_{n}_gamma.json'))
    rows={}
    for r in d['inhomogeneous_deformation']['gamma_coefficients']:
        if r['Z']=='K':
            rows.setdefault((r['X'],r['Y']),{}); rows[(r['X'],r['Y'])][r['gb_parameter']]=rows[(r['X'],r['Y'])].get(r['gb_parameter'],0)+Fraction(r['coeff'])
    print('n',n,'K rows',len(rows))
    for k in range(1,n+1):
        for pair,par in [((f'E_eps1_del{k}_pm',f'E_2del{k}_p'),f'gb_a_1_p_b_{k}_p'),((f'E_eps1_del{k}_pp',f'E_2del{k}_m'),f'gb_a_1_p_b_{k}_m'),((f'E_eps1_del{k}_mm',f'E_2del{k}_p'),f'gb_a_1_m_b_{k}_p')]:
            print(' ',k,pair,par,{a:str(b) for a,b in rows.get(pair,{}).items()})
        hs=[p for p in rows if p[0]==f'E_eps1_del{k}_mm' and p[1].startswith('H_')]
        for p in hs: print('   mm-H',k,p,{a:str(b) for a,b in rows[p].items()})
