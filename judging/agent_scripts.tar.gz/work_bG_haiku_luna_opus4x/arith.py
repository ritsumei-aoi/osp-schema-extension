# agent computation: dimension of cokernel of Delta (R^n_eqs / col(Delta)) = n_eqs - rank(Delta), from numbers in opus47-b02 I08.md:53-56
for n,eq,r in ((1,212,28),(2,2748,168)): print('opus47-b02 n',n,'n_eqs',eq,'rank',r,'cokernel dim',eq-r)
