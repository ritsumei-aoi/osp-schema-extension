import os,re,sys,glob,json
W=sys.argv[1]; J=sys.argv[2]; B=sys.argv[3]
def norm(t): return re.sub(r'\s+',' ',t).strip()
bad=0
for f in sorted(glob.glob(W+'/rec/*.py')):
    ns={}; exec(open(f).read(),ns); R=ns['R']; run=R['run']
    sys.path.insert(0,W); import patches; R=patches.patch2(run,patches.patch(run,R))
    root=f'{J}/{run}'
    corpus=''
    for dp,dn,fn in os.walk(root):
        for x in fn:
            if x.endswith(('.md','.py','.json','.txt')):
                try: corpus+=' '+open(os.path.join(dp,x),errors='ignore').read()
                except: pass
    corpus+=' '+open(f'{B}/{run}/run.json').read()
    corpus+=' '+open('<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/judging/g_summary.csv').read()+' '+open('<home>/notebook/git/ai-workflow-evaluation/case_studies/osp-schema-extension/t1-schema-extension/revision-ipsj-r1/judging/extract_spec.md').read()
    corpus_n=norm(corpus)
    quotes=[]
    def walk(o):
        if isinstance(o,dict):
            for k,v in o.items():
                if k=='quote' and isinstance(v,str): quotes.append(v)
                else: walk(v)
        elif isinstance(o,list):
            for v in o: walk(v)
    walk(R)
    # inline single-quoted segments in all strings
    def strs(o):
        if isinstance(o,str): yield o
        elif isinstance(o,dict):
            for v in o.values(): yield from strs(v)
        elif isinstance(o,list):
            for v in o: yield from strs(v)
    for t in strs(R):
        for m in re.finditer(r"'([^']{25,})'",t):
            quotes.append('INLINE:'+m.group(1))
    for q in quotes:
        inl=q.startswith('INLINE:'); q=q[7:] if inl else q
        parts=[norm(x) for x in re.split(r'\.\.\.|…',q) if norm(x)]
        for part in parts:
            if part not in corpus_n and part.replace('**','') not in corpus_n.replace('**',''):
                bad+=1; print('MISSING','INL' if inl else 'Q',run,'|',part[:160])
print('bad',bad)
