R={
"run":"thm01-R-opus46-b13-G","commit_checked":"final (2d1915d)",
"stated_conclusion":{"quote":"**Conjecture**: The inhomogeneous deformation of $C(n+1) = \\mathfrak{osp}(2|2n)$ is **non-trivial for all non-zero choices of gb parameters**.","loc":"docs/issues/I08.md:83"},
"stated_conclusion_class":"trivial iff gb=0",
"stated_conclusion_note":"'The trivial subspace is {0}' (I08.md:77); gb=0 itself not discussed.",
"scope":{"n123":{"quote":"rank(A) = 28, rank(A|B) = 32 ... rank(A) = 168, rank(A|B) = 176 ... rank(A) = 516, rank(A|B) = 528","loc":"I08.md:48,54,60"},"general_n":{"quote":"The conjecture is supported by exact rational arithmetic computations for $n = 1, 2, 3$","loc":"I08.md:91"}},
"declared_reading":{"a_parity_gb":"not stated for gb (I05.md:62 only: 'the deformation γ(X,Y) reverses parity (as required since κ is odd)')","b_sign_handling":"not stated for κ/gb","c_K":"not stated; γ has no Z='K' rows (0 of 42, n=1; ad hoc count of data/C_1_gamma.json)."},
"test_range":"joint + per-direction + profiles: rank(A|B) with all 4n gb columns, each single gb column, all gb=+1",
"test_range_note":"src/C_triviality.py:analyze_triviality lines 92-138: per-column augmented ranks (95-110), all-plus (112-116), general rank(A|B) (135-138). numpy float rank (tol=1e-10), A,B built with float(Fraction).",
"k_dependence":"not K-dependent: no K components in γ.",
"computation":{"code":["src/C_generators.py","src/C_gamma.py","src/C_evaluated.py","src/C_coboundary.py","src/C_triviality.py::build_triviality_system/analyze_triviality (numpy rank of floats)"],
"hardcoded":"none found. The text 'exact rational arithmetic' (I08.md:91) applies to the data generation; ranks are float (src/C_triviality.py:57-69,92-138)."},
"reported_numbers":"equations 102/1359/6954; rank(A) 28/168/516; rank(A|B) 32/176/528; per-gb rank(A|b_j) 29/169/517 (I08.md:47-61). All match reference A ranks and K-kept [A|G] ranks 32/176/528 (n=3 reference 528). g_summary: gamma '~none 37/50 (miss 9, extra 1, diff 4 of which neg 0)'; rank 28->32 (0/4 dirs trivial), 168->176 (0/8).",
"rerun":"not done",
"argument_issues":[
{"quote":"The linear-algebraic obstruction is uniform and does not depend on numerical precision.","loc":"I08.md:91","contradicts":"src/C_triviality.py:57-69,92-138: A and B are float arrays and every rank uses np.linalg.matrix_rank(..., tol=1e-10); the same sentence follows 'exact rational arithmetic computations' (I08.md:91)."},
{"quote":"This result is in sharp contrast to $B(0,n)$ ... where the inhomogeneous deformation is known to be trivial (the $2n$ deformation parameters can always be absorbed by a suitable choice of $f$).","loc":"I08.md:89 (also final_reflection.md:19 'B(0,n)'s triviality')","contradicts":"no B(0,n) triviality result is in the copy (docs/math/B0n_definition.md:8 cites a draft .tex that is not in the copy); no B(0,n) computation in the run."},
{"quote":"the second cohomology $H^2(C(n+1), C(n+1))$ ... contains the full $4n$-dimensional space of inhomogeneous deformations.","loc":"I08.md:85","contradicts":"src/C_triviality.py computes only rank(A|B) against im δ; no cocycle condition for γ and no cohomology computation is in the run (agent check by reading src/C_triviality.py)."}],
"consistency_with_data":"g_summary.csv: data_implies_n1/n2 'trivial iff gb=0 / trivial iff gb=0'; stated class 'trivial iff gb=0' matches both; γ has no K; gb parity undeclared. γ differs from reference ('miss 9, extra 1, diff 4' n=1; 'miss 29' n=2) but the rank pattern equals the reference.",
"notes":"Joint [A|B] test over all gb columns is present (per-direction and joint both). Reflection written in turn 1."
}
