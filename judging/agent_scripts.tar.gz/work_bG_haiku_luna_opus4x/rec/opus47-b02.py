R={
"run":"thm01-R-opus47-b02-G","commit_checked":"final (1d7827f)",
"stated_conclusion":{"quote":"the inhomogeneous deformation defined by `[b_j^s, a_1^σ] = −gb_{σ,j,s} · κ` is **trivial if and only if the entire 4n-vector of gb parameters vanishes**.","loc":"docs/issues/I08.md:101-103"},
"stated_conclusion_class":"trivial iff gb=0",
"scope":{"n123":{"quote":"Verified by direct rank computation for n = 1 and n = 2; the pattern (nullity(Δ) = 4n, rank(Δ) + 4n = n_φ) extends to n = 3 by the uniform combinatorics of the triple space.","loc":"I08.md:112-114"},"general_n":{"quote":"Based on the identical structural pattern for n = 1 and n = 2 ... the conjecture extends uniformly.","loc":"I08.md:147-149"}},
"declared_reading":{"a_parity_gb":{"quote":"4n total, parity 1. Schema labels: `gb_a1{σ}_b{j}{s}`.","loc":"docs/issues/I05.md:50-51"},"b_sign_handling":{"quote":"`a_1^σ · b_j^s - b_j^s · a_1^σ = gb_{σ,j,s} · κ`, with κ odd central and κ² = 0.","loc":"I05.md:41-43"},"c_K":"not stated; γ has no Z='K' rows (0 of 46, n=1; ad hoc count of data/C_1_gamma.json)."},
"test_range":"joint + per-direction (n=1,2 only; exact sympy): rank([Δ|Γ]) vs rank(Δ), and per-gb-column extended rank",
"test_range_note":"src/C_triviality.py:obstruction_analysis lines 140-163: Delta.rank(), Delta.row_join(Gamma).rank(), per-column check Delta.row_join(col).rank() > r_D. n=3 was not completed ('left as a background run', I08.md:145-147).",
"k_dependence":"not K-dependent: no K components in γ.",
"computation":{"code":["src/C_oscillator.py","src/C_generators.py","src/C_gamma.py (κ-branch on swapped boson-fermion pair)","src/C_evaluate.py","src/C_coboundary.py","src/C_triviality.py::collect_pairs/build_matrices/obstruction_analysis (sympy exact rank)"],
"hardcoded":"none found."},
"reported_numbers":"n=1: n_eqs 212, φ 32, rank(Δ) 28, rank([Δ|Γ]) 32; n=2: 2748, 176, 168, 176 (I08.md:55-56,133,140). Match reference A ranks 28/168 and K-kept [A|G] ranks 32/176. n=3 not computed. g_summary: gamma '~none 41/50 (miss 5, extra 1, diff 4 of which neg 0)'; rank 28->32 (0/4 dirs trivial), 168->176 (0/8).",
"rerun":"not done",
"argument_issues":[
{"quote":"Thus the obstruction cokernel has dimension 4n — exactly the number of gb parameters","loc":"I08.md:59-60","contradicts":"the cokernel of Δ (R^n_eqs / col(Δ)) has dimension n_eqs - rank(Δ) = 184 (n=1), 2580 (n=2) from the report's own numbers I08.md:55-56 (agent computation: work_bG_haiku_luna_opus4x/arith.py); 4n is rank([Δ|Γ]) - rank(Δ)."},
{"quote":"the pattern (nullity(Δ) = 4n, rank(Δ) + 4n = n_φ) extends to n = 3 by the uniform combinatorics of the triple space.","loc":"I08.md:113-114","contradicts":"I08.md:145-147 'The n=3 case was computationally attempted ... left as a background run' (no n=3 rank in the report or src/C_triviality.py output)."},
{"quote":"are linearly independent and inject into H², so the obstruction space has dimension 4n (full rank).","loc":"I08.md:111-112","contradicts":"src/C_triviality.py computes ranks of Δ and [Δ|Γ] only (no cocycle condition for γ, no H² computation); final_reflection.md:77 lists exact symbolic computation for n=3 as 'Not done in this run'."},
{"quote":"consistent with the standard super-cocycle interpretation (gauge freedom in f dual to the deformation parameters)","loc":"I08.md:66-67","contradicts":"no reference or derivation in the copy (docs/math, handover) for this interpretation; nullity(Δ)=4n is stated to match 'the dimension of gb' without a computed relation."}],
"consistency_with_data":"g_summary.csv: data_implies_n1/n2 'trivial iff gb=0 / trivial iff gb=0'; stated class 'trivial iff gb=0' matches both. Odd gb (parity 1), no K in γ.",
"notes":"n=3 not computed (data/C_3_*.json exist; analysis only for n=1,2). γ lacks 5 (n=1) / 32 (n=2) reference entries (g_summary 'miss 5/32', 'extra 22' at n=2). Reflection written in turn 1."
}
