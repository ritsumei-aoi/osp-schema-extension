import json,sys,glob,os
# agent computation: entry counts of top-level list/dict fields in data/C_<n>_structure.json and gamma files
for run in sys.argv[2:]:
    for n in (1,2,3):
        p=f"{sys.argv[1]}/{run}/data/C_{n}_structure.json"
        if not os.path.exists(p): print(run,n,'missing');continue
        d=json.load(open(p))
        sc=d.get('structure_constants')
        print(run,n,'structure_constants',type(sc).__name__,len(sc) if sc is not None else None)
