import gzip,json,sys
for f in sys.argv[1:]:
    last=None;n=0
    for l in gzip.open(f,'rt'):
        try:o=json.loads(l)
        except: continue
        n+=1
        m=o.get('message') or {}
        if o.get('type')=='assistant' or m.get('role')=='assistant':
            c=m.get('content')
            if isinstance(c,list):
                t=''.join(x.get('text','') for x in c if isinstance(x,dict) and x.get('type')=='text')
            else: t=c or ''
            if t.strip(): last=(n,t)
    print('##',f,'lines',n,'lastidx',last[0] if last else None); print(last[1] if last else '')
