import json,sys
# agent computation: Z components of delta_f at (X,Y)=(E_eps1_del1_mp,H_1) in opus48-b02 data/C_1_coboundary.json
root=sys.argv[1]
c=json.load(open(f'{root}/thm01-R-opus48-b02-G/data/C_1_coboundary.json'))
d=c['delta_f']
print(type(d), (list(d)[:5] if isinstance(d,dict) else d[:1]))
rows=[r for r in (d if isinstance(d,list) else d.get('entries',[])) if r.get('X')=='E_eps1_del1_mp' and r.get('Y')=='H_1']
print(sorted({r.get('Z') for r in rows}))
