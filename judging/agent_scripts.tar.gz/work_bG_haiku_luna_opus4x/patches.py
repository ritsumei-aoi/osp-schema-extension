def patch(run,R):
    if run=='thm01-R-haiku45-b02-G':
        R['computation']['hardcoded'][2]={"quote":"\"b_{self.n}_p\",","loc":"data/C_1_structure.json:129-130 (unformatted f-string text in generator_realization of H_2); source src/C_generators.py:101"}
        R['computation']['hardcoded'][3]={"quote":"\"result\": \"to be determined\"","loc":"data/C_1_coboundary_trivial.json (triviality_verification)"}
        a=R['argument_issues']
        a[2]['quote']="Proved all three algebras are trivial"; a[2]['loc']="run.json turns[0].result (final chat report)"
        a[3]['quote']="All checks pass (structure constants correctly deferred to Schema 2)"; a[3]['loc']="run.json turns[0].result (final chat report)"
        a[4]['quote']="Rigorous proof that the trivial case (gb=0) is trivial"; a[4]['loc']="docs/issues/final_reflection.md:31"
    if run=='thm01-R-haiku45-b04-G':
        R['scope']['general_n']['quote']="Conjecture (Evidence-Based) ... gb parameters exhibit specific sign patterns that cancel coboundary terms"
        R['computation']['hardcoded'][2]={"fact":"structure_constants: list with 0 entries for n=1,2,3 (agent computation: work_bG_haiku_luna_opus4x/count_sc.py)","loc":"data/C_<n>_structure.json"}
    if run=='thm01-R-haiku45-b06-G':
        R['computation']['hardcoded'][1]={"quote":"f = 0 (prototype: trivial map)","loc":"src/C_coboundary_generator.py:119"}
    if run=='thm01-R-haiku45-b08-G':
        R['declared_reading']['c_K']['quote']="`central_elements`: κ and K"
        R['computation']['hardcoded'][0]={"quote":"# This is a simplified implementation","loc":"src/C_coboundary_generator.py:91 (next line :92 '# Full computation would require accessing all brackets')"}
    if run=='thm01-R-haiku45-b10-G':
        R['declared_reading']['a_parity_gb']={"quote":"\"parity\": 1,","loc":"data/C_1_gamma.json gamma_structure.deformation_parameters (each entry)"}
        R['computation']['hardcoded'][0]={"quote":"\"Z\": \"K\", \"coeff\": \"gb_a1_p_b1_p * gb_a1_m_b1_m\"","loc":"data/C_1_gamma.json:324-325 (only gamma row for n=1; g_summary: n=1 1 row, n=2 4 rows)"}
    if run=='thm01-R-luna-b02-G':
        R['declared_reading']['b_sign_handling']['quote']="kept the exchange relation and odd central $\\kappa$"
    if run=='thm01-R-luna-b04-G':
        R['declared_reading']['a_parity_gb']['quote']="Chose the latter to honor the fixed definitions and avoid silently changing their assumptions"
        R['computation']['hardcoded'][2]={"quote":"expected = (","loc":"src/C_triviality.py:63 (four hard-coded isolating (pair, parameter, coefficient) rows per j, lines 63-86)"}
        R['argument_issues'][1]['quote']="The comparison verifies these independent rows for $n=1,2,3$, giving central constraint rank $4n$."
        R['argument_issues'][1]['loc']="I08.md:53 (table I08.md:34-38 'Central constraint rank 4/4 8/8 12/12')"
    if run=='thm01-R-opus46-b08-G':
        R['scope']['general_n']['quote']="the inhomogeneous deformation defined by the gb matrix is **non-trivial for all non-zero values of the gb parameters**."
        R['scope']['general_n']['loc']="docs/issues/I08.md:87"
        R['argument_issues'][4]['quote']="The norm of the null-space projection of $b$ grows with $n$: ... This indicates the obstruction is robust and amplifies with rank."
    if run=='thm01-R-opus46-b10-G':
        R['stated_conclusion']['quote']="the inhomogeneous deformation defined by any non-zero set of gb parameters $\\{\\mathrm{gb}_{\\sigma,j,s}\\}$ is **non-trivial**."
    if run=='thm01-R-opus46-b12-G':
        R['scope']['n123']['quote']="the RREF of $[A|b]$ produces a row $[0\\ 0\\ \\cdots\\ 0\\ |\\ 1]$, meaning the system reduces to the impossible equation $1 = 0$."
        R['argument_issues'][1]['quote']="**Non-trivial case**: For ANY nonzero gb assignment, including:"
    if run=='thm01-R-opus46-b13-G':
        R['scope']['n123']['quote']="$\\mathrm{rank}(A) = 28$, $\\mathrm{rank}(A|B) = 32$. ... $\\mathrm{rank}(A) = 516$, $\\mathrm{rank}(A|B) = 528$."
        R['argument_issues'][1]['quote']="This result is in sharp contrast to $B(0,n) = \\mathfrak{osp}(1|2n)$, where the inhomogeneous deformation is known to be trivial"
    if run=='thm01-R-opus48-b02-G':
        R['stated_conclusion']['quote']="the inhomogeneous (gb) deformation is trivial ... **if and only if all $4n$ gb parameters vanish**."
        R['scope']['general_n']['quote']="the inhomogeneous (gb) deformation is trivial ... **if and only if all $4n$ gb parameters vanish**."
        R['argument_issues'][3]['quote']="in the odd deformation cohomology $H^2(\\mathfrak g,\\mathfrak g)_{\\bar 1}$"
    if run=='thm01-R-opus5-b02-G':
        R['stated_conclusion']['quote']="**Every inhomogeneous deformation of $C(n+1)$ is trivial.** ... on the gb parameters is **vacuous**: there is no condition."
    return R

def patch2(run,R):
    import re
    def sub_all(o,a,b):
        if isinstance(o,str): return o.replace(a,b)
        if isinstance(o,dict): return {k:sub_all(v,a,b) for k,v in o.items()}
        if isinstance(o,list): return [sub_all(v,a,b) for v in o]
        return o
    subs=[
     ("(there exist obstructions in H^2)","(there exist obstructions in $H^2$)"),
     ("'Compute the second cohomology group H^2 ... ' (listed as open)","'Compute the second cohomology group' (listed as open, I08.md:163)"),
          ("'specific LINEAR CONSTRAINTS'","'specific LINEAR CONSTRAINTS'"),
     ("'GB parameters: 4/8/12 (all +1)'","GB parameters 4/8/12 (all +1) as listed"),
     ("I also corrected the gb parity note: the stated exchange relation with odd κ requires even gb parameters.","I also corrected the gb parity note"),
     ("'K even identified with the scalar identity, neither included in the independent algebra basis'","'`K` even identified with the scalar identity, neither included in the independent algebra basis'"),
     ("'K and κ remain excluded from the domain and codomain basis'","'`K` and `κ` remain excluded from the domain and codomain basis'"),
     ("'no Layer 4 coboundary term can produce K'","'no Layer 4 coboundary term can produce `K`'"),
     ("Since `f:g->g`, none","Since `f:g->g`, none"),
     ("'closure_with_central_identity_K is true'","'`closure_with_central_identity_K` is true'"),
     ("'Necessary and sufficient condition for triviality: gb = 0'","'**Necessary and sufficient condition for triviality**: $\\text{gb} = 0$'"),
     ("'non-trivial for any non-zero gb'","non-trivial for any non-zero gb (paraphrase)"),
     ("'Aoi (2026), docs/drafts/aoi2026_triviality_osp1_2n.tex'","'Aoi (2026), `docs/drafts/aoi2026_triviality_osp1_2n.tex`'"),
     ("'gb = 0 (zero deformation) is always consistent with φ = 0'","'gb = 0 (zero deformation) is always consistent with'"),
     ("'The trivial subspace is {0}'","'**The trivial subspace is $\\{0\\}$**'"),
     ("'δf lands on the Layer-1 basis ∪ {K}'","'$\\delta f$ lands on the Layer-1 basis $\\cup\\{K\\}$'"),
     ("'Drop the K-components of γ (work modulo K)'","'Drop the $K$-components of $\\gamma$ (\"work modulo $K$\")'"),
     ("'in the restricted setting the condition for triviality is gb = 0'","'in the restricted setting the condition for triviality is'"),
     ("'If one insists on f:g→g, then γ_gb is trivial iff gb = 0'","'If one insists on $f:\\mathfrak g\\to\\mathfrak g$, then $\\gamma_{\\mathrm{gb}}$ is trivial'"),
    ]
    for a,b in subs: R=sub_all(R,a,b)
    return R
